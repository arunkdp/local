import { z } from "zod";

export const offerInputSchema = z.object({
  businessId: z.string().uuid(),
  productId: z.string().uuid().optional(),
  title: z.string().trim().min(3).max(120),
  description: z.string().trim().min(10).max(5000),
  imageUrl: z.string().regex(/^\/uploads\/offers\/[0-9a-f-]{36}-[0-9a-f-]{36}\.(jpg|png|webp)$/i, "Upload an offer image first.").optional(),
  type: z.enum(["PERCENTAGE", "FIXED_AMOUNT", "PROMOTIONAL_PRICE", "BOGO", "SEASONAL", "PRODUCT_LAUNCH", "SERVICE_PROMOTION", "ANNOUNCEMENT"]),
  discountPercent: z.number().positive().max(100).optional(),
  discountMinor: z.number().int().positive().optional(),
  originalMinor: z.number().int().nonnegative().optional(),
  promotionalMinor: z.number().int().nonnegative().optional(),
  startsAt: z.coerce.date(),
  endsAt: z.coerce.date(),
  terms: z.string().max(5000).optional(),
}).superRefine((offer, ctx) => {
  if (offer.endsAt <= offer.startsAt) {
    ctx.addIssue({ code: "custom", path: ["endsAt"], message: "End time must be after the start time." });
  }
  if (offer.type === "PERCENTAGE" && (!offer.discountPercent || offer.discountPercent > 100)) {
    ctx.addIssue({ code: "custom", path: ["discountPercent"], message: "Percentage offers need a discount from 0 to 100." });
  }
  if (offer.type === "FIXED_AMOUNT" && !offer.discountMinor) {
    ctx.addIssue({ code: "custom", path: ["discountMinor"], message: "Fixed discounts must use a positive amount in minor units." });
  }
  if (offer.type === "PROMOTIONAL_PRICE" && (offer.promotionalMinor === undefined || offer.originalMinor === undefined || offer.promotionalMinor >= offer.originalMinor)) {
    ctx.addIssue({ code: "custom", path: ["promotionalMinor"], message: "Promotional price must be lower than the original price." });
  }
});

export const businessRegistrationSchema = z.object({
  name: z.string().trim().min(2).max(100),
  description: z.string().trim().min(20).max(5000),
  categoryId: z.string().uuid(),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().max(30).optional(),
  address: z.string().trim().min(3).max(200),
  city: z.string().trim().min(2).max(100),
  postalCode: z.string().max(20).optional(),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
});
