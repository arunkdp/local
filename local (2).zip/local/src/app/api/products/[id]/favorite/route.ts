import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

const idSchema = z.string().min(1).max(100);

export async function PUT(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to save products." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Product favorites require database configuration." }, { status: 503 });
  const { id } = await context.params;
  if (!idSchema.safeParse(id).success) return NextResponse.json({ error: "Invalid product." }, { status: 400 });
  try {
    const product = await prisma.product.findFirst({ where: { OR: /^[0-9a-f-]{36}$/i.test(id) ? [{ id }, { slug: id }] : [{ slug: id }], available: true, business: { status: "APPROVED" } }, select: { id: true } });
    if (!product) return NextResponse.json({ error: "This product isn't available." }, { status: 404 });
    await prisma.favoriteProduct.upsert({ where: { userId_productId: { userId: user.id, productId: product.id } }, update: {}, create: { userId: user.id, productId: product.id } });
    return NextResponse.json({ favorited: true, productId: product.id });
  } catch (error) {
    console.error("Product favorite failed", error);
    return NextResponse.json({ error: "Couldn't save this product." }, { status: 503 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to manage product favorites." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Product favorites require database configuration." }, { status: 503 });
  const { id } = await context.params;
  if (!idSchema.safeParse(id).success) return NextResponse.json({ error: "Invalid product." }, { status: 400 });
  try {
    const product = await prisma.product.findFirst({ where: { OR: /^[0-9a-f-]{36}$/i.test(id) ? [{ id }, { slug: id }] : [{ slug: id }] }, select: { id: true } });
    if (product) await prisma.favoriteProduct.deleteMany({ where: { userId: user.id, productId: product.id } });
    return NextResponse.json({ favorited: false });
  } catch (error) {
    console.error("Product unfavorite failed", error);
    return NextResponse.json({ error: "Couldn't update your favorites." }, { status: 503 });
  }
}
