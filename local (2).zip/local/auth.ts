import NextAuth from "next-auth";
import type { NextAuthConfig } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { compare } from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const credentialsSchema = z.object({
  email: z.string().trim().email().max(254),
  password: z.string().min(1).max(72),
});

export const authConfig = {
  session: { strategy: "jwt", maxAge: 60 * 60 * 24 * 7 },
  pages: { signIn: "/sign-in" },
  providers: [
    Credentials({
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(rawCredentials: Record<string, unknown>) {
        const parsed = credentialsSchema.safeParse(rawCredentials);
        if (!parsed.success) return null;

        const user = await prisma.user.findUnique({
          where: { email: parsed.data.email.toLowerCase() },
          select: { id: true, email: true, name: true, passwordHash: true, role: true, disabledAt: true },
        });
        if (!user?.passwordHash || user.disabledAt || !(await compare(parsed.data.password, user.passwordHash))) return null;

        return { id: user.id, email: user.email, name: user.name, role: user.role };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }: Parameters<NonNullable<NextAuthConfig["callbacks"]>["jwt"]>[0]) {
      if (user) {
        token.sub = user.id;
      }
      if (!token.sub) return token;

      const currentUser = await prisma.user.findFirst({
        where: { id: token.sub, disabledAt: null },
        select: { role: true },
      });
      if (!currentUser) {
        token.sub = undefined;
        delete token.role;
        return token;
      }
      token.role = currentUser.role;
      return token;
    },
    session({ session, token }: Parameters<NonNullable<NextAuthConfig["callbacks"]>["session"]>[0]) {
      if (session.user && token.sub) {
        session.user.id = token.sub;
        session.user.role = token.role;
      }
      return session;
    },
  },
} satisfies NextAuthConfig;

export const { handlers, auth, signIn, signOut } = NextAuth(authConfig);
