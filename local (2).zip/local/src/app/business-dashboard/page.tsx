import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, ArrowRight, Package, Store, Tag } from "lucide-react";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function BusinessDashboardIndex() {
  const user = await getCurrentUser();
  if (!user) redirect("/sign-in");
  if (user.role !== "ADMIN" && user.role !== "SUPER_ADMIN") redirect("/");
  if (!process.env.DATABASE_URL) return <main className="p-10 text-center">Business dashboard requires database configuration.</main>;

  const businesses = await prisma.business.findMany({
    where: user.role === "SUPER_ADMIN" ? {} : { memberships: { some: { userId: user.id } } },
    select: { id: true, name: true, slug: true, status: true, description: true, _count: { select: { products: true, offers: true } } },
    orderBy: { createdAt: "desc" },
  });

  return <main className="min-h-screen bg-paper px-5 py-8 text-ink sm:px-8">
    <div className="mx-auto max-w-5xl">
      <Link href="/" className="inline-flex items-center gap-2 text-sm text-ink/55 hover:text-moss"><ArrowLeft size={15} /> Marketplace</Link>
      <header className="mt-7 flex flex-wrap items-end justify-between gap-5">
        <div><p className="eyebrow">BUSINESS WORKSPACE</p><h1 className="mt-2 font-display text-3xl font-semibold">Your businesses</h1><p className="mt-2 text-sm text-ink/55">Manage your shop, team, followers, products, and offers.</p></div>
        <Link href="/business" className="inline-flex items-center gap-2 rounded-full bg-moss px-5 py-3 text-sm font-semibold text-white hover:bg-ink"><Store size={16} /> Add a business</Link>
      </header>
      {businesses.length ? <div className="mt-8 grid gap-4 sm:grid-cols-2">{businesses.map((business) => <article key={business.id} className="flex flex-col rounded-3xl border border-ink/5 bg-white p-6 shadow-sm sm:p-7">
        <div className="flex items-start justify-between gap-3"><div className="grid h-12 w-12 place-items-center rounded-2xl bg-moss/10 text-moss"><Store size={22} /></div><span className={`rounded-full px-3 py-1.5 text-[11px] font-bold uppercase tracking-wide ${business.status === "APPROVED" ? "bg-emerald-50 text-emerald-800" : "bg-amber-50 text-amber-800"}`}>{business.status.toLowerCase()}</span></div>
        <h2 className="mt-5 font-display text-xl font-semibold">{business.name}</h2><p className="mt-2 line-clamp-2 text-sm leading-6 text-ink/55">{business.description}</p>
        <div className="mt-5 flex gap-4 border-t border-ink/5 pt-4 text-xs font-medium text-ink/55"><span className="inline-flex items-center gap-1.5"><Package size={14} />{business._count.products} products</span><span className="inline-flex items-center gap-1.5"><Tag size={14} />{business._count.offers} offers</span></div>
        <Link href={`/business-dashboard/${business.id}`} className="mt-5 inline-flex items-center gap-2 self-start rounded-full bg-moss px-4 py-2.5 text-sm font-semibold text-white hover:bg-ink">Manage shop <ArrowRight size={15} /></Link>
      </article>)}</div> : <div className="mt-8 rounded-3xl border border-ink/5 bg-white p-8 text-center"><span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-moss/10 text-moss"><Store size={24} /></span><h2 className="mt-4 font-display text-xl font-semibold">No business connected yet</h2><p className="mt-2 text-sm text-ink/55">Submit your shop for review to get started.</p><Link href="/business" className="mt-5 inline-flex items-center gap-2 rounded-full bg-moss px-5 py-2.5 text-sm font-semibold text-white">Add a business <ArrowRight size={15} /></Link></div>}
    </div>
  </main>;
}
