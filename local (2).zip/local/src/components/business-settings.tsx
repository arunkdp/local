"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { LoaderCircle, MapPin, Pencil } from "lucide-react";

type Business = {
  id: string; name: string; description: string; categoryId: string; coverUrl: string | null;
  email: string | null; phone: string | null; website: string | null; status: string;
  location: { address: string; city: string; postalCode: string | null; latitude: number; longitude: number } | null;
};

type Category = { id: string; name: string };

export function BusinessSettings({ business, categories }: { business: Business; categories: Category[] }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    const initial = {
      name: business.name, description: business.description, categoryId: business.categoryId,
      coverUrl: business.coverUrl, email: business.email, phone: business.phone, website: business.website,
      address: business.location?.address, city: business.location?.city, postalCode: business.location?.postalCode,
      latitude: business.location?.latitude, longitude: business.location?.longitude,
    };
    const current = {
      name: String(values.get("name") ?? "").trim(), description: String(values.get("description") ?? "").trim(),
      categoryId: String(values.get("categoryId") ?? ""), coverUrl: String(values.get("coverUrl") ?? "").trim() || null,
      email: String(values.get("email") ?? "").trim() || null, phone: String(values.get("phone") ?? "").trim() || null,
      website: String(values.get("website") ?? "").trim() || null, address: String(values.get("address") ?? "").trim(),
      city: String(values.get("city") ?? "").trim(), postalCode: String(values.get("postalCode") ?? "").trim() || null,
      latitude: Number(values.get("latitude")), longitude: Number(values.get("longitude")),
    };
    const changes = Object.fromEntries(Object.entries(current).filter(([key, value]) => value !== initial[key as keyof typeof initial]));
    if (!Object.keys(changes).length) { setMessage("No changes to save."); return; }

    setPending(true);
    setError("");
    setMessage("");
    try {
      const response = await fetch(`/api/businesses/${business.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(changes) });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Couldn't save your business details.");
      setMessage("Business details saved.");
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Couldn't save your business details.");
    } finally {
      setPending(false);
    }
  }

  return <details className="mb-6 rounded-3xl border border-ink/5 bg-white p-5 sm:p-7"><summary className="flex cursor-pointer list-none items-center gap-2 font-display text-xl font-semibold"><Pencil size={18} className="text-moss" /> Edit business profile <span className="ml-auto text-sm font-medium text-moss">Open</span></summary>
    <p className="mt-3 text-sm leading-6 text-ink/55">Your business profile updates immediately after the initial shop approval.</p>
    <form onSubmit={submit} className="mt-5 space-y-4">
      <div className="grid gap-4 sm:grid-cols-2"><label className="text-sm font-medium">Business name<input name="name" required minLength={2} maxLength={100} defaultValue={business.name} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="text-sm font-medium">Category<select name="categoryId" defaultValue={business.categoryId} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 bg-white px-3">{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></label></div>
      <label className="block text-sm font-medium">Description<textarea name="description" required minLength={20} maxLength={5000} defaultValue={business.description} className="mt-1.5 min-h-28 w-full rounded-xl border border-ink/10 p-3" /></label>
      <div className="grid gap-4 sm:grid-cols-3"><label className="text-sm font-medium">Email<input name="email" type="email" defaultValue={business.email ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="text-sm font-medium">Phone<input name="phone" type="tel" maxLength={30} defaultValue={business.phone ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="text-sm font-medium">Website (HTTPS)<input name="website" type="url" pattern="https://.*" defaultValue={business.website ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label></div>
      <label className="block text-sm font-medium">Cover image URL (HTTPS)<input name="coverUrl" type="url" pattern="https://.*" defaultValue={business.coverUrl ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label>
      <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-moss"><MapPin size={14} /> Primary location</div>
      <div className="grid gap-4 sm:grid-cols-2"><label className="text-sm font-medium">Street address<input name="address" required minLength={3} maxLength={200} defaultValue={business.location?.address ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="text-sm font-medium">City<input name="city" required minLength={2} maxLength={100} defaultValue={business.location?.city ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label></div>
      <div className="grid gap-4 sm:grid-cols-3"><label className="text-sm font-medium">Postal code<input name="postalCode" maxLength={20} defaultValue={business.location?.postalCode ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="text-sm font-medium">Latitude<input name="latitude" required type="number" min="-90" max="90" step="any" defaultValue={business.location?.latitude ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="text-sm font-medium">Longitude<input name="longitude" required type="number" min="-180" max="180" step="any" defaultValue={business.location?.longitude ?? ""} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label></div>
      {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}{message && <p role="status" className="rounded-xl bg-moss/10 p-3 text-sm text-moss">{message}</p>}
      <button disabled={pending} className="inline-flex h-11 items-center gap-2 rounded-full bg-moss px-5 text-sm font-semibold text-white disabled:opacity-60">{pending && <LoaderCircle size={15} className="animate-spin" />}Save profile</button>
    </form>
  </details>;
}