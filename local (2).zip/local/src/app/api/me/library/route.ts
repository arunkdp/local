import { NextResponse } from "next/server";
import { auth } from "../../../../../auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Sign in to view your saved places." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Account storage is not configured yet." }, { status: 503 });

  try {
    const [offers, businesses, products] = await Promise.all([
      prisma.savedOffer.findMany({ where: { userId: session.user.id }, select: { offerId: true, offer: { select: { slug: true } } } }),
      prisma.businessFollow.findMany({ where: { userId: session.user.id }, select: { businessId: true, business: { select: { slug: true } } } }),
      prisma.favoriteProduct.findMany({ where: { userId: session.user.id }, select: { productId: true } }),
    ]);
    return NextResponse.json({ savedOfferIds: offers.map((item) => item.offerId), savedOfferSlugs: offers.map((item) => item.offer.slug), followedBusinessIds: businesses.map((item) => item.businessId), followedBusinessSlugs: businesses.map((item) => item.business.slug), favoriteProductIds: products.map((item) => item.productId) });
  } catch (error) {
    console.error("Customer library could not be loaded", error);
    return NextResponse.json({ error: "Your saved places couldn't be loaded." }, { status: 503 });
  }
}
