"use client";

import { useCallback, useEffect, useState, type FormEvent } from "react";
import Image from "next/image";
import { LoaderCircle, PackagePlus, RefreshCw, Tag } from "lucide-react";

type Product = { id: string; name: string; description: string; priceMinor: number | null; promotionalMinor: number | null; available: boolean; images: Array<{ url: string }> };
type Offer = { id: string; title: string; description: string; imageUrl: string | null; status: string; discountPercent: string | number | null; startsAt: string; endsAt: string; terms: string | null };

function localDateTime(value: string) {
  const date = new Date(value);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
}

export function BusinessWorkspace({ businessId, status }: { businessId: string; status: string }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState("");
  const [editingProduct, setEditingProduct] = useState<string | null>(null);
  const [editingOffer, setEditingOffer] = useState<string | null>(null);
  const [offerType, setOfferType] = useState("PERCENTAGE");

  const load = useCallback(async () => {
    try {
      const [productResponse, offerResponse] = await Promise.all([
        fetch(`/api/businesses/${businessId}/products`, { cache: "no-store" }),
        fetch(`/api/businesses/${businessId}/offers`, { cache: "no-store" }),
      ]);
      const [productBody, offerBody] = await Promise.all([productResponse.json(), offerResponse.json()]);
      if (!productResponse.ok || !offerResponse.ok) throw new Error(productBody.error ?? offerBody.error ?? "Workspace data is unavailable.");
      setProducts(productBody.products);
      setOffers(offerBody.offers);
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Workspace data is unavailable.");
    }
  }, [businessId]);

  useEffect(() => { void load(); }, [load]);

  async function send(path: string, method: string, body: object, message: string) {
    setPending(path);
    setError("");
    try {
      const response = await fetch(path, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error ?? "The change could not be saved.");
      setNotice(message);
      await load();
      return true;
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "The change could not be saved.");
      return false;
    } finally {
      setPending("");
    }
  }

  async function createProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = new FormData(form);
    const success = await send(`/api/businesses/${businessId}/products`, "POST", {
      name: values.get("name"), description: values.get("description"),
      priceMinor: values.get("price") ? Math.round(Number(values.get("price")) * 100) : null,
      promotionalMinor: values.get("promotion") ? Math.round(Number(values.get("promotion")) * 100) : null,
      imageUrl: values.get("imageUrl") || null,
    }, "Product added to your catalog.");
    if (success) form.reset();
  }

  async function uploadOfferImage(file: FormDataEntryValue | null) {
    if (!(file instanceof File) || file.size === 0) return null;
    if (file.size > 5 * 1024 * 1024) throw new Error("Choose an image up to 5 MB.");
    const form = new FormData();
    form.set("image", file);
    const response = await fetch(`/api/businesses/${businessId}/offers/image`, { method: "POST", body: form });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error ?? "Image upload failed.");
    return result.imageUrl as string;
  }

  async function createOffer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = new FormData(form);
    if (new Date(values.get("endsAt") as string) <= new Date(values.get("startsAt") as string)) { setError("End date must be after start date."); return; }
    setPending("upload-offer");
    let imageUrl: string | null;
    try { imageUrl = await uploadOfferImage(values.get("image")); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Image upload failed."); setPending(""); return; }
    const success = await send(`/api/businesses/${businessId}/offers`, "POST", {
      title: values.get("title"), description: values.get("description"), type: offerType,
      ...(imageUrl ? { imageUrl } : {}),
      ...(offerType === "PERCENTAGE" ? { discountPercent: Number(values.get("discount")) } : {}),
      startsAt: new Date(values.get("startsAt") as string).toISOString(),
      endsAt: new Date(values.get("endsAt") as string).toISOString(),
      terms: values.get("terms") || undefined,
    }, status === "APPROVED" ? "Offer published. It will appear when its start time arrives." : "Draft saved. Submit after your shop is approved.");
    if (success) form.reset();
  }

  async function saveProduct(event: FormEvent<HTMLFormElement>, product: Product) {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    const success = await send(`/api/products/${product.id}`, "PATCH", {
      name: values.get("name"), description: values.get("description"),
      priceMinor: values.get("price") ? Math.round(Number(values.get("price")) * 100) : null,
      promotionalMinor: values.get("promotion") ? Math.round(Number(values.get("promotion")) * 100) : null,
      imageUrl: values.get("imageUrl") || null,
    }, "Product updated.");
    if (success) setEditingProduct(null);
  }

  async function saveOffer(event: FormEvent<HTMLFormElement>, offer: Offer) {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    if (new Date(values.get("endsAt") as string) <= new Date(values.get("startsAt") as string)) { setError("End date must be after start date."); return; }
    setPending("upload-offer");
    let imageUrl: string | null;
    try { imageUrl = await uploadOfferImage(values.get("image")); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Image upload failed."); setPending(""); return; }
    const success = await send(`/api/offers/${offer.id}`, "PATCH", {
      action: "edit", title: values.get("title"), description: values.get("description"),
      ...(imageUrl ? { imageUrl } : {}),
      startsAt: new Date(values.get("startsAt") as string).toISOString(),
      endsAt: new Date(values.get("endsAt") as string).toISOString(),
      terms: values.get("terms") || null,
      ...(offer.discountPercent ? { discountPercent: Number(values.get("discount")) } : {}),
    }, "Offer updated.");
    if (success) setEditingOffer(null);
  }

  return <div className="space-y-6">
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-moss/5 p-4 text-sm text-ink/70"><p>Business status: <strong className="capitalize">{status.toLowerCase()}</strong>. {status === "APPROVED" ? "Your offers publish directly." : "Offers remain drafts until your shop is approved."}</p><button onClick={() => void load()} className="inline-flex items-center gap-1.5 font-semibold text-moss"><RefreshCw size={14} /> Refresh</button></div>
    {notice && <p role="status" className="rounded-xl bg-moss/10 p-3 text-sm text-moss">{notice}</p>}
    {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}

    <div className="grid gap-6 lg:grid-cols-2">
      <form onSubmit={createProduct} className="space-y-4 rounded-3xl border border-ink/5 bg-white p-5 sm:p-6">
        <h2 className="flex items-center gap-2 font-display text-xl font-semibold"><PackagePlus size={18} className="text-moss" /> Add a product</h2>
        <label className="block text-sm font-medium">Name<input required name="name" minLength={2} maxLength={120} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label>
        <label className="block text-sm font-medium">Description<textarea required name="description" minLength={5} maxLength={5000} className="mt-1.5 min-h-24 w-full rounded-xl border border-ink/10 p-3" /></label>
        <div className="grid grid-cols-2 gap-3"><label className="block text-sm font-medium">Price<input name="price" type="number" min="0" step="0.01" className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="block text-sm font-medium">Promo price<input name="promotion" type="number" min="0" step="0.01" className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label></div>
        <label className="block text-sm font-medium">Image URL (HTTPS)<input name="imageUrl" type="url" pattern="https://.*" placeholder="https://..." className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label>
        <button disabled={Boolean(pending)} className="inline-flex h-11 items-center gap-2 rounded-full bg-moss px-5 text-sm font-semibold text-white disabled:opacity-60">{pending && <LoaderCircle size={15} className="animate-spin" />}Save product</button>
      </form>
      <form onSubmit={createOffer} className="space-y-4 rounded-3xl border border-ink/5 bg-white p-5 sm:p-6">
        <h2 className="flex items-center gap-2 font-display text-xl font-semibold"><Tag size={18} className="text-moss" /> Create an offer</h2>
        <div className="grid gap-3 sm:grid-cols-2"><label className="block text-sm font-medium">Offer title<input required name="title" minLength={3} maxLength={120} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="block text-sm font-medium">Type<select value={offerType} onChange={(event) => setOfferType(event.target.value)} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 bg-white px-3"><option value="PERCENTAGE">Percentage discount</option><option value="ANNOUNCEMENT">Shop announcement</option></select></label></div>
        <label className="block text-sm font-medium">Description<textarea required name="description" minLength={10} maxLength={5000} className="mt-1.5 min-h-24 w-full rounded-xl border border-ink/10 p-3" /></label>
        <div className="grid gap-3 sm:grid-cols-3">{offerType === "PERCENTAGE" && <label className="block text-sm font-medium">Discount %<input required name="discount" type="number" min="0.01" max="100" step="0.01" className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label>}<label className="block text-sm font-medium">Starts<input required name="startsAt" type="datetime-local" className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="block text-sm font-medium">Ends<input required name="endsAt" type="datetime-local" className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label></div>
        <label className="block text-sm font-medium">Offer image (JPG, PNG, or WebP; up to 5 MB)<input name="image" type="file" accept="image/jpeg,image/png,image/webp" className="mt-1.5 block w-full rounded-xl border border-ink/10 bg-white p-3 text-sm" /></label>
        <label className="block text-sm font-medium">Terms (optional)<textarea name="terms" maxLength={5000} className="mt-1.5 min-h-16 w-full rounded-xl border border-ink/10 p-3" /></label>
        <button disabled={Boolean(pending)} className="inline-flex h-11 items-center gap-2 rounded-full bg-moss px-5 text-sm font-semibold text-white disabled:opacity-60">{pending && <LoaderCircle size={15} className="animate-spin" />}Create offer</button>
      </form>
    </div>

    <div className="grid gap-6 lg:grid-cols-2">
      <section className="rounded-3xl border border-ink/5 bg-white p-5 sm:p-6"><h2 className="font-display text-xl font-semibold">Products <span className="text-sm font-normal text-ink/45">({products.length})</span></h2>
        <div className="mt-4 space-y-3">{products.map((product) => <article key={product.id} className="rounded-2xl border border-ink/10 p-4">
          <div className="flex items-start justify-between gap-3"><div><h3 className="font-semibold">{product.name}</h3><p className="mt-1 line-clamp-2 text-xs text-ink/55">{product.description}</p><p className="mt-2 text-xs text-ink/45">{product.priceMinor === null ? "Price on request" : `$${(product.priceMinor / 100).toFixed(2)}`} · {product.available ? "Visible" : "Hidden"}</p></div><div className="flex shrink-0 gap-2"><button onClick={() => setEditingProduct(editingProduct === product.id ? null : product.id)} className="text-xs font-semibold text-moss">Edit</button><button disabled={Boolean(pending)} onClick={() => void send(`/api/products/${product.id}`, "PATCH", { available: !product.available }, product.available ? "Product hidden." : "Product visible.")} className="text-xs font-semibold text-moss">{product.available ? "Hide" : "Show"}</button></div></div>
          {editingProduct === product.id && <form onSubmit={(event) => void saveProduct(event, product)} className="mt-4 space-y-3 border-t border-ink/10 pt-4"><label className="block text-xs font-semibold">Name<input name="name" required defaultValue={product.name} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label><label className="block text-xs font-semibold">Description<textarea name="description" required defaultValue={product.description} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label><div className="grid grid-cols-2 gap-2"><label className="block text-xs font-semibold">Price<input name="price" type="number" min="0" step="0.01" defaultValue={product.priceMinor === null ? "" : (product.priceMinor / 100).toFixed(2)} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label><label className="block text-xs font-semibold">Promo price<input name="promotion" type="number" min="0" step="0.01" defaultValue={product.promotionalMinor === null ? "" : (product.promotionalMinor / 100).toFixed(2)} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label></div><label className="block text-xs font-semibold">Image URL<input name="imageUrl" type="url" pattern="https://.*" defaultValue={product.images[0]?.url ?? ""} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label><button disabled={Boolean(pending)} className="rounded-full bg-moss px-4 py-2 text-xs font-semibold text-white">Save changes</button></form>}
        </article>)}{!products.length && <p className="text-sm text-ink/50">Your catalog is empty. Add a product above.</p>}</div>
      </section>
      <section className="rounded-3xl border border-ink/5 bg-white p-5 sm:p-6"><h2 className="font-display text-xl font-semibold">Offers <span className="text-sm font-normal text-ink/45">({offers.length})</span></h2>
        <div className="mt-4 space-y-3">{offers.map((offer) => <article key={offer.id} className="rounded-2xl border border-ink/10 p-4"><div className="flex items-start justify-between gap-3"><div className="flex min-w-0 items-start gap-3">{offer.imageUrl && <Image unoptimized src={offer.imageUrl} alt="" width={64} height={64} className="h-16 w-16 shrink-0 rounded-xl object-cover" />}<div><h3 className="font-semibold">{offer.title}</h3><p className="mt-1 line-clamp-2 text-xs text-ink/55">{offer.description}</p><p className="mt-2 text-xs font-semibold capitalize text-moss">{offer.status.toLowerCase()} · {new Date(offer.startsAt).toLocaleDateString()} to {new Date(offer.endsAt).toLocaleDateString()}</p></div></div><button onClick={() => setEditingOffer(editingOffer === offer.id ? null : offer.id)} className="text-xs font-semibold text-moss">Edit</button></div>
          {offer.status !== "ARCHIVED" && <div className="mt-3 flex flex-wrap gap-3 text-xs font-semibold text-moss">{offer.status === "PUBLISHED" && <button disabled={Boolean(pending)} onClick={() => void send(`/api/offers/${offer.id}`, "PATCH", { action: "pause" }, "Offer paused.")}>Pause</button>}{["DRAFT", "PAUSED", "REJECTED", "PENDING"].includes(offer.status) && <button disabled={Boolean(pending)} onClick={() => void send(`/api/offers/${offer.id}`, "PATCH", { action: "publish" }, "Offer published.")}>Publish offer</button>}<button disabled={Boolean(pending)} onClick={() => { if (window.confirm("Archive this offer? It will no longer appear publicly.")) void send(`/api/offers/${offer.id}`, "PATCH", { action: "archive" }, "Offer archived."); }}>Archive</button></div>}
          {editingOffer === offer.id && offer.status !== "ARCHIVED" && <form onSubmit={(event) => void saveOffer(event, offer)} className="mt-4 space-y-3 border-t border-ink/10 pt-4"><p className="text-xs text-ink/50">Saving changes updates the offer without another review.</p><label className="block text-xs font-semibold">Title<input name="title" required defaultValue={offer.title} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label><label className="block text-xs font-semibold">Description<textarea name="description" required minLength={10} maxLength={5000} defaultValue={offer.description} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label><label className="block text-xs font-semibold">Replace image (optional)<input name="image" type="file" accept="image/jpeg,image/png,image/webp" className="mt-1 block w-full rounded-lg border border-ink/10 p-2 text-sm" /></label>{offer.discountPercent && <label className="block text-xs font-semibold">Discount %<input name="discount" type="number" min="0.01" max="100" step="0.01" defaultValue={Number(offer.discountPercent)} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label>}<div className="grid grid-cols-2 gap-2"><label className="block text-xs font-semibold">Starts<input name="startsAt" required type="datetime-local" defaultValue={localDateTime(offer.startsAt)} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label><label className="block text-xs font-semibold">Ends<input name="endsAt" required type="datetime-local" defaultValue={localDateTime(offer.endsAt)} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label></div><label className="block text-xs font-semibold">Terms<textarea name="terms" defaultValue={offer.terms ?? ""} className="mt-1 w-full rounded-lg border border-ink/10 p-2 text-sm" /></label><button disabled={Boolean(pending)} className="rounded-full bg-moss px-4 py-2 text-xs font-semibold text-white">Save offer</button></form>}
        </article>)}{!offers.length && <p className="text-sm text-ink/50">No offers yet. Create one above.</p>}</div>
      </section>
    </div>
  </div>;
}