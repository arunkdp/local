import { beforeEach, describe, expect, it, vi } from "vitest";
import { POST } from "./route";

const createUser = vi.hoisted(() => vi.fn());

vi.mock("@/lib/prisma", () => ({
  prisma: { user: { create: createUser } },
}));

function request(body: unknown) {
  return new Request("http://localhost/api/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("customer registration", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.DATABASE_URL = "postgresql://test:test@localhost/test";
    createUser.mockResolvedValue({ id: "aaf20e26-6ef0-4cda-83a1-cf037d451f79" });
  });

  it("always creates a customer, ignoring a client-supplied administrator role", async () => {
    const response = await POST(
      request({
        name: "Jamie Parker",
        email: "Jamie@Example.com",
        password: "StrongPassword123",
        role: "SUPER_ADMIN",
      }),
    );

    expect(response.status).toBe(201);
    expect(createUser).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          email: "jamie@example.com",
          role: "CUSTOMER",
          profile: { create: {} },
        }),
        select: { id: true },
      }),
    );
  });

  it("creates a shop-scoped admin only when shop owner is explicitly selected", async () => {
    const response = await POST(
      request({
        name: "Taylor Owner",
        email: "owner@example.com",
        password: "StrongPassword123",
        accountType: "SHOP_OWNER",
        role: "SUPER_ADMIN",
      }),
    );

    expect(response.status).toBe(201);
    expect(createUser).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          email: "owner@example.com",
          role: "ADMIN",
        }),
      }),
    );
  });
  it("rejects passwords that don't meet the registration policy", async () => {
    const response = await POST(
      request({
        name: "Jamie Parker",
        email: "jamie@example.com",
        password: "short",
      }),
    );

    expect(response.status).toBe(400);
    expect(createUser).not.toHaveBeenCalled();
  });
});
