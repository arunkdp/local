import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  preferredLocationLabel: z.string().trim().max(120).optional().nullable(),
  preferredLatitude: z.number().min(-90).max(90).optional().nullable(),
  preferredLongitude: z.number().min(-180).max(180).optional().nullable(),
  searchRadiusKm: z.number().int().min(1).max(100).optional(),
  emailOffers: z.boolean().optional(),
  inAppNotifications: z.boolean().optional(),
  privacyMode: z.boolean().optional(),
  interests: z.array(z.string().trim().min(1).max(80)).max(30).optional(),
}).refine((value) => (value.preferredLatitude == null) === (value.preferredLongitude == null), { message: "Provide both location coordinates or neither." });

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Preferences require database configuration." }, { status: 503 });
  try {
    const profile = await prisma.customerProfile.findUnique({ where: { userId: user.id }, include: { user: { select: { interests: { select: { category: true } } } } } });
    return NextResponse.json({ profile, interests: profile?.user.interests.map((item) => item.category) ?? [] }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    console.error("Preferences query failed", error);
    return NextResponse.json({ error: "Preferences are unavailable." }, { status: 503 });
  }
}

export async function PUT(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Preferences require database configuration." }, { status: 503 });
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check your preferences." }, { status: 400 });
  const { interests, ...profile } = parsed.data;
  try {
    await prisma.$transaction(async (tx) => {
      await tx.customerProfile.upsert({ where: { userId: user.id }, create: { userId: user.id, ...profile }, update: profile });
      if (interests) {
        await tx.customerInterest.deleteMany({ where: { userId: user.id } });
        if (interests.length) await tx.customerInterest.createMany({ data: [...new Set(interests.map((category) => category.toLowerCase()))].map((category) => ({ userId: user.id, category })) });
      }
    });
    return NextResponse.json({ updated: true });
  } catch (error) {
    console.error("Preferences update failed", error);
    return NextResponse.json({ error: "Couldn't save your preferences." }, { status: 503 });
  }
}
