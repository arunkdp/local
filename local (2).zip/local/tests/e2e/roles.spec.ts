import { expect, test } from "@playwright/test";
import { unlink } from "node:fs/promises";
import path from "node:path";
import { prisma } from "../../src/lib/prisma";

const password = process.env.DEMO_ACCOUNT_PASSWORD;

test.skip(!password, "Run the local demo seed and set DEMO_ACCOUNT_PASSWORD to verify all roles.");
test.setTimeout(90000);
test.use({ trace: "off" });

async function signIn(page: import("@playwright/test").Page, email: string) {
  await page.goto("/sign-in");
  await page.getByLabel("Email address").fill(email);
  await page.getByLabel("Password").fill(password!);
  await page.getByRole("button", { name: "Sign in" }).click();
  await expect(page).toHaveURL(/\/(account|business-dashboard|admin)(\/|$)/, { timeout: 45000 });
}

test("customer sees saved content but cannot open platform administration", async ({ page }) => {
  await signIn(page, "customer@locallink.test");
  await expect(page.getByRole("heading", { name: "Saved offers" })).toBeVisible();
  await expect(page.getByText("Your new morning ritual")).toBeVisible();
  await page.goto("/admin");
  await expect(page).toHaveURL("/");
});

test("shop admin sees only their assigned shop", async ({ page }) => {
  await signIn(page, "coffee@locallink.test");
  await expect(page.getByRole("heading", { name: "Your businesses" })).toBeVisible();
  await expect(page.getByText("Daybreak Coffee")).toBeVisible();
  await expect(page.getByText("Form & Fold")).toHaveCount(0);
});

test("super admin opens platform operations", async ({ page }) => {
  await signIn(page, "super@locallink.test");
  await expect(page.getByRole("heading", { name: "Admin dashboard" })).toBeVisible();
});
test("shop manager can update own product but cannot update another shop's", async ({ page }) => {
  await signIn(page, "coffee@locallink.test");
  const discovery = await (await page.request.get("/api/discovery?city=Brooklyn")).json();
  const coffeeId = discovery.shops.find((shop: { name: string }) => shop.name === "Daybreak Coffee").id;
  const fashionId = discovery.shops.find((shop: { name: string }) => shop.name === "Form & Fold").id;
  const coffeeProducts = await (await page.request.get(`/api/businesses/${coffeeId}/products`)).json();
  const fashionProducts = await (await page.request.get(`/api/businesses/${fashionId}/products`)).json();
  const own = coffeeProducts.products[0];
  const foreign = fashionProducts.products[0];
  expect(own).toBeTruthy();
  expect(foreign).toBeTruthy();

  try {
    const ownUpdate = await page.request.patch(`/api/products/${own.id}`, { data: { available: false } });
    expect(ownUpdate.status()).toBe(200);
    const foreignUpdate = await page.request.patch(`/api/products/${foreign.id}`, { data: { available: false } });
    expect(foreignUpdate.status()).toBe(403);
  } finally {
    await page.request.patch(`/api/products/${own.id}`, { data: { available: own.available } });
  }
});
test("shop manager edits contact details without changing approval and cannot edit another shop", async ({ page }) => {
  await signIn(page, "coffee@locallink.test");
  const discovery = await (await page.request.get("/api/discovery?city=Brooklyn")).json();
  const coffeeId = discovery.shops.find((shop: { name: string }) => shop.name === "Daybreak Coffee").id;
  const fashionId = discovery.shops.find((shop: { name: string }) => shop.name === "Form & Fold").id;
  const original = await (await page.request.get(`/api/businesses/${coffeeId}`)).json();

  try {
    const ownUpdate = await page.request.patch(`/api/businesses/${coffeeId}`, { data: { phone: "+1 555 0100" } });
    expect(ownUpdate.status()).toBe(200);
    expect((await ownUpdate.json()).needsReview).toBe(false);
    const foreignUpdate = await page.request.patch(`/api/businesses/${fashionId}`, { data: { phone: "+1 555 0100" } });
    expect(foreignUpdate.status()).toBe(403);
  } finally {
    await page.request.patch(`/api/businesses/${coffeeId}`, { data: { phone: original.business.phone } });
  }
});

test("shop manager uploads an offer image and updates its dates", async ({ page }) => {
  await signIn(page, "coffee@locallink.test");
  const discovery = await (await page.request.get("/api/discovery?city=Brooklyn")).json();
  const businessId = discovery.shops.find((shop: { name: string }) => shop.name === "Daybreak Coffee").id;
  const image = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Z4u8AAAAASUVORK5CYII=", "base64");
  const upload = await page.request.post(`/api/businesses/${businessId}/offers/image`, {
    multipart: { image: { name: "offer.png", mimeType: "image/png", buffer: image } },
  });
  expect(upload.status()).toBe(201);
  const { imageUrl } = await upload.json();
  expect(imageUrl).toMatch(/^\/uploads\/offers\//);
  const imageResponse = await page.request.get(imageUrl);
  expect(imageResponse.status()).toBe(200);
  const startsAt = new Date(Date.now() + 3600_000).toISOString();
  const endsAt = new Date(Date.now() + 3 * 86400_000).toISOString();
  const created = await page.request.post(`/api/businesses/${businessId}/offers`, {
    data: { title: "Local image upload test", description: "Fresh local offer with a shop image.", type: "PERCENTAGE", discountPercent: 12, startsAt, endsAt, imageUrl },
  });
  expect(created.status()).toBe(201);
  const { offer } = await created.json();
  try {
    const revisedEnd = new Date(Date.now() + 5 * 86400_000).toISOString();
    const updated = await page.request.patch(`/api/offers/${offer.id}`, {
      data: { action: "edit", description: "Updated offer description and dates.", startsAt, endsAt: revisedEnd },
    });
    expect(updated.status()).toBe(200);
    const listing = await (await page.request.get(`/api/businesses/${businessId}/offers`)).json();
    const saved = listing.offers.find((item: { id: string }) => item.id === offer.id);
    expect(saved.imageUrl).toBe(imageUrl);
    expect(new Date(saved.endsAt).toISOString()).toBe(revisedEnd);
    expect(saved.description).toBe("Updated offer description and dates.");
  } finally {
    await prisma.offer.delete({ where: { id: offer.id } });
    await unlink(path.join(process.cwd(), "public", imageUrl)).catch(() => {});
  }
});



test("shop dashboard shows customer interest and owner team access", async ({ page }) => {
  await signIn(page, "coffee@locallink.test");
  const discovery = await (await page.request.get("/api/discovery?city=Brooklyn")).json();
  const businessId = discovery.shops.find((shop: { name: string }) => shop.name === "Daybreak Coffee").id;
  await page.goto(`/business-dashboard/${businessId}`);
  await expect(page.getByRole("heading", { name: "Most liked products" })).toBeVisible();
  await expect(page.getByRole("heading", { name: "Most saved offers" })).toBeVisible();
  await expect(page.getByText("Shop followers")).toBeVisible();
  const staff = await (await page.request.get(`/api/businesses/${businessId}/staff`)).json();
  expect(staff.canManageStaff).toBe(true);
  expect(staff.members.some((member: { role: string }) => member.role === "OWNER")).toBe(true);
});

test("shop owner can add and remove an approved manager", async ({ page, browser }) => {
  await signIn(page, "coffee@locallink.test");
  const discovery = await (await page.request.get("/api/discovery?city=Brooklyn")).json();
  const businessId = discovery.shops.find((shop: { name: string }) => shop.name === "Daybreak Coffee").id;
  const managerEmail = "fashion@locallink.test";
  const current = await (await page.request.get(`/api/businesses/${businessId}/staff`)).json();
  test.skip(current.members.some((member: { user: { email: string } }) => member.user.email === managerEmail), "Demo manager already assigned to this shop.");
  const added = await page.request.post(`/api/businesses/${businessId}/staff`, { data: { email: managerEmail } });
  expect(added.status()).toBe(201);
  const assigned = await (await page.request.get(`/api/businesses/${businessId}/staff`)).json();
  const manager = assigned.members.find((member: { user: { email: string } }) => member.user.email === managerEmail);
  expect(manager.role).toBe("MANAGER");
  const managerContext = await browser.newContext({ baseURL: "http://localhost:3000" });
  try {
    const managerPage = await managerContext.newPage();
    await signIn(managerPage, managerEmail);
    await managerPage.goto(`/business-dashboard/${businessId}`);
    await expect(managerPage.getByRole("heading", { name: "Daybreak Coffee" })).toBeVisible();
    const denied = await managerPage.request.post(`/api/businesses/${businessId}/staff`, { data: { email: "super@locallink.test" } });
    expect(denied.status()).toBe(403);
  } finally {
    await managerContext.close();
    const removed = await page.request.delete(`/api/businesses/${businessId}/staff`, { data: { userId: manager.userId } });
    expect(removed.status()).toBe(200);
  }
});



test("customer likes a shop product and can undo it", async ({ page }) => {
  await signIn(page, "customer@locallink.test");
  const business = await (await page.request.get("/api/businesses/daybreak-coffee")).json();
  const productId = business.business.products.find((product: { name: string }) => product.name === "House blend coffee").id;
  const library = await (await page.request.get("/api/me/library")).json();
  const wasLiked = library.favoriteProductIds.includes(productId);
  await page.goto("/business/daybreak-coffee");
  const like = page.getByRole("button", { name: "Like House blend coffee" });
  const unlike = page.getByRole("button", { name: "Unlike House blend coffee" });
  await expect(wasLiked ? unlike : like).toBeVisible();
  try {
    if (wasLiked) {
      await unlike.click();
      await expect(like).toBeVisible();
    } else {
      await like.click();
      await expect(unlike).toBeVisible();
    }
  } finally {
    await page.request[wasLiked ? "put" : "delete"](`/api/products/${productId}/favorite`);
  }
});



test("business registration explains account approval and shows the form only to shop admins", async ({ browser }) => {
  const customerContext = await browser.newContext({ baseURL: "http://localhost:3000" });
  const adminContext = await browser.newContext({ baseURL: "http://localhost:3000" });
  try {
    const customerPage = await customerContext.newPage();
    await signIn(customerPage, "customer@locallink.test");
    await customerPage.goto("/business");
    await expect(customerPage.getByRole("heading", { name: "Shop admin approval needed" })).toBeVisible();
    await expect(customerPage.getByRole("button", { name: "Submit for verification" })).toHaveCount(0);

    const adminPage = await adminContext.newPage();
    await signIn(adminPage, "coffee@locallink.test");
    await adminPage.goto("/business");
    await expect(adminPage.getByRole("button", { name: "Submit for verification" })).toBeVisible();
  } finally {
    await customerContext.close();
    await adminContext.close();
  }
});

