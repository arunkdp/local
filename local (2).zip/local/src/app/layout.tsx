﻿import type { Metadata } from "next";
import { Providers } from "@/components/providers";
import "./globals.css";

export const metadata: Metadata = {
  title: "LocalLink | Discover shops and offers nearby",
  description: "Discover independent neighborhood shops, local offers, and the people who make your corner of the world feel like yours.",
  openGraph: {
    title: "LocalLink | Your neighborhood, a little more rewarding",
    description: "Find lovely local shops and good deals around your neighborhood.",
    type: "website",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><Providers>{children}</Providers></body></html>;
}

