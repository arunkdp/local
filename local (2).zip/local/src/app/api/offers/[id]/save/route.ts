import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "../../../../../../auth";
import { prisma } from "@/lib/prisma";

const routeIdSchema = z.string().min(1).max(100);

export async function PUT(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Sign in to save offers." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Offer saving is not configured yet." }, { status: 503 });
  const { id } = await context.params;
  if (!routeIdSchema.safeParse(id).success) return NextResponse.json({ error: "Invalid offer." }, { status: 400 });

  try {
    const offer = await prisma.offer.findFirst({
      where: { ...(id.match(/^[0-9a-f-]{36}$/i) ? { OR: [{ id }, { slug: id }] } : { slug: id }), status: "PUBLISHED", startsAt: { lte: new Date() }, endsAt: { gt: new Date() }, business: { status: "APPROVED" } },
      select: { id: true },
    });
    if (!offer) return NextResponse.json({ error: "This offer is no longer available." }, { status: 404 });
    await prisma.savedOffer.upsert({ where: { userId_offerId: { userId: session.user.id, offerId: offer.id } }, update: {}, create: { userId: session.user.id, offerId: offer.id } });
    return NextResponse.json({ saved: true, offerId: offer.id });
  } catch (error) {
    console.error("Offer save failed", error);
    return NextResponse.json({ error: "Couldn't save this offer right now." }, { status: 503 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Sign in to manage saved offers." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Offer saving is not configured yet." }, { status: 503 });
  const { id } = await context.params;
  if (!routeIdSchema.safeParse(id).success) return NextResponse.json({ error: "Invalid offer." }, { status: 400 });

  try {
    const offer = await prisma.offer.findFirst({ where: { ...(id.match(/^[0-9a-f-]{36}$/i) ? { OR: [{ id }, { slug: id }] } : { slug: id }), business: { status: "APPROVED" } }, select: { id: true } });
    if (offer) await prisma.savedOffer.deleteMany({ where: { userId: session.user.id, offerId: offer.id } });
    return NextResponse.json({ saved: false, offerId: offer?.id });
  } catch (error) {
    console.error("Offer removal failed", error);
    return NextResponse.json({ error: "Couldn't update your saved offers right now." }, { status: 503 });
  }
}
