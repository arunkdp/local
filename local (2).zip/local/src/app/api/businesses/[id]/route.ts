import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser, canManageBusiness } from "@/lib/authorization";

export const dynamic = "force-dynamic";
const schema = z.string().min(1).max(100);

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!schema.safeParse(id).success) return NextResponse.json({ error: "Invalid business." }, { status: 400 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Business profiles require database configuration." }, { status: 503 });
  try {
    const user = await getCurrentUser();
    const manager = user && z.string().uuid().safeParse(id).success ? await canManageBusiness(user.id, id) : false;
    const business = await prisma.business.findFirst({
      where: { ...(z.string().uuid().safeParse(id).success ? { OR: [{ id }, { slug: id }] } : { slug: id }), ...(manager ? {} : { status: "APPROVED" }) },
      include: {
        category: true,
        locations: { orderBy: { isPrimary: "desc" } },
        products: { where: manager ? {} : { available: true }, include: { images: { orderBy: { position: "asc" } }, category: true, _count: { select: { favorites: true } } }, orderBy: { createdAt: "desc" }, take: 50 },
        offers: { where: manager ? {} : { status: "PUBLISHED", startsAt: { lte: new Date() }, endsAt: { gt: new Date() } }, orderBy: { endsAt: "asc" }, take: 30 },
        _count: { select: { followers: true } },
      },
    });
    if (!business) return NextResponse.json({ error: "Business not found." }, { status: 404 });
    return NextResponse.json({ business }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    console.error("Business profile query failed", error);
    return NextResponse.json({ error: "Business profile is unavailable." }, { status: 503 });
  }
}

const updateSchema = z.object({
  name: z.string().trim().min(2).max(100).optional(),
  description: z.string().trim().min(20).max(5000).optional(),
  categoryId: z.string().uuid().optional(),
  coverUrl: z.string().url().refine((url) => url.startsWith("https://"), "Cover images must use HTTPS.").nullable().optional(),
  email: z.string().email().nullable().optional(),
  phone: z.string().trim().max(30).nullable().optional(),
  website: z.string().url().refine((url) => url.startsWith("https://"), "Websites must use HTTPS.").nullable().optional(),
  address: z.string().trim().min(3).max(200).optional(),
  city: z.string().trim().min(2).max(100).optional(),
  postalCode: z.string().trim().max(20).nullable().optional(),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
}).refine((data) => Object.keys(data).length > 0, "Choose a business field to update.");

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to manage your business." }, { status: 401 });
  const { id } = await context.params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid business." }, { status: 400 });
  if (!(await canManageBusiness(user.id, id))) return NextResponse.json({ error: "You don't have access to this business." }, { status: 403 });
  const parsed = updateSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check the business details." }, { status: 400 });

  try {
    const existing = await prisma.business.findUnique({ where: { id }, select: { status: true } });
    if (!existing) return NextResponse.json({ error: "Business not found." }, { status: 404 });
    if (parsed.data.categoryId && !(await prisma.businessCategory.findUnique({ where: { id: parsed.data.categoryId }, select: { id: true } }))) {
      return NextResponse.json({ error: "Choose a valid business category." }, { status: 400 });
    }

    const { address, city, postalCode, latitude, longitude, ...businessFields } = parsed.data;
    const locationFields = { address, city, postalCode, latitude, longitude };
    const updated = await prisma.$transaction(async (tx) => {
      const business = await tx.business.update({ where: { id }, data: businessFields, select: { id: true, name: true, status: true } });
      if (Object.values(locationFields).some((value) => value !== undefined)) {
        await tx.businessLocation.updateMany({ where: { businessId: id, isPrimary: true }, data: locationFields });
      }
      await tx.adminAuditLog.create({ data: { actorId: user.id, action: "BUSINESS_UPDATED", entityType: "Business", entityId: id, metadata: { fields: Object.keys(parsed.data) } } });
      return business;
    });
    return NextResponse.json({ business: updated });
  } catch (error) {
    console.error("Business update failed", error);
    return NextResponse.json({ error: "Couldn't update this business." }, { status: 503 });
  }
}