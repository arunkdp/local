import { ReportTarget } from "@prisma/client";
import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  targetType: z.nativeEnum(ReportTarget),
  targetId: z.string().uuid(),
  reason: z.string().trim().min(3).max(120),
  details: z.string().trim().max(2000).optional(),
});

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to submit a report." }, { status: 401 });
  if (!process.env.DATABASE_URL) {
    return NextResponse.json({ error: "Reporting requires database configuration." }, { status: 503 });
  }

  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Check the report details." },
      { status: 400 },
    );
  }

  const { targetType, targetId, reason, details } = parsed.data;
  try {
    let offerId: string | null = null;
    let targetExists = false;

    switch (targetType) {
      case ReportTarget.BUSINESS:
        targetExists = Boolean(
          await prisma.business.findUnique({ where: { id: targetId }, select: { id: true } }),
        );
        break;
      case ReportTarget.PRODUCT:
        targetExists = Boolean(
          await prisma.product.findUnique({ where: { id: targetId }, select: { id: true } }),
        );
        break;
      case ReportTarget.OFFER:
        offerId = targetId;
        targetExists = Boolean(
          await prisma.offer.findUnique({ where: { id: targetId }, select: { id: true } }),
        );
        break;
      case ReportTarget.USER:
        if (targetId === user.id) {
          return NextResponse.json({ error: "You can't report your own account." }, { status: 400 });
        }
        targetExists = Boolean(
          await prisma.user.findUnique({ where: { id: targetId }, select: { id: true } }),
        );
        break;
    }

    if (!targetExists) return NextResponse.json({ error: "The reported item could not be found." }, { status: 404 });

    const report = await prisma.userReport.create({
      data: { authorId: user.id, targetType, targetId, offerId, reason, details: details || null },
      select: { id: true, status: true, createdAt: true },
    });
    return NextResponse.json({ report }, { status: 201 });
  } catch (error) {
    console.error("Report submission failed", error);
    return NextResponse.json({ error: "Couldn't submit this report." }, { status: 503 });
  }
}
