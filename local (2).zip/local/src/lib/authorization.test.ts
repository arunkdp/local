import { beforeEach, describe, expect, it, vi } from "vitest";
import { canManageBusiness } from "./authorization";

const mocks = vi.hoisted(() => ({
  findUser: vi.fn(),
  findMembership: vi.fn(),
}));

vi.mock("../../auth", () => ({ auth: vi.fn() }));
vi.mock("@/lib/prisma", () => ({
  prisma: {
    user: { findFirst: mocks.findUser },
    businessMembership: { findUnique: mocks.findMembership },
  },
}));

describe("business authorization", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("allows a super admin to manage any business", async () => {
    mocks.findUser.mockResolvedValue({ role: "SUPER_ADMIN" });

    await expect(canManageBusiness("admin-id", "business-id")).resolves.toBe(true);
    expect(mocks.findMembership).not.toHaveBeenCalled();
  });

  it("allows an admin to manage an assigned business", async () => {
    mocks.findUser.mockResolvedValue({ role: "ADMIN" });
    mocks.findMembership.mockResolvedValue({ id: "membership-id" });

    await expect(canManageBusiness("admin-id", "business-id")).resolves.toBe(true);
    expect(mocks.findMembership).toHaveBeenCalledWith({
      where: { userId_businessId: { userId: "admin-id", businessId: "business-id" } },
      select: { id: true },
    });
  });

  it("denies admins access to businesses they are not assigned", async () => {
    mocks.findUser.mockResolvedValue({ role: "ADMIN" });
    mocks.findMembership.mockResolvedValue(null);

    await expect(canManageBusiness("admin-id", "business-id")).resolves.toBe(false);
  });

  it("denies customers business management even if a stale membership exists", async () => {
    mocks.findUser.mockResolvedValue({ role: "CUSTOMER" });

    await expect(canManageBusiness("customer-id", "business-id")).resolves.toBe(false);
    expect(mocks.findMembership).not.toHaveBeenCalled();
  });

  it("denies disabled accounts", async () => {
    mocks.findUser.mockResolvedValue(null);

    await expect(canManageBusiness("disabled-id", "business-id")).resolves.toBe(false);
    expect(mocks.findMembership).not.toHaveBeenCalled();
  });
});
