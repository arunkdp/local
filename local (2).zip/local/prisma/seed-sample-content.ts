import { PrismaClient, OfferStatus, OfferType, BusinessStatus } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const food = await prisma.businessCategory.upsert({
    where: { slug: "food-drink" },
    update: {},
    create: { name: "Food & drink", slug: "food-drink" },
  });
  const fashion = await prisma.businessCategory.upsert({
    where: { slug: "fashion" },
    update: {},
    create: { name: "Fashion", slug: "fashion" },
  });

  const cafe = await prisma.business.upsert({
    where: { slug: "daybreak-coffee" },
    update: { status: BusinessStatus.APPROVED, coverUrl: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=85" },
    create: {
      name: "Daybreak Coffee",
      slug: "daybreak-coffee",
      description: "Small-batch coffee and warm pastries for slow Brooklyn mornings.",
      coverUrl: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=85",
      categoryId: food.id,
      status: BusinessStatus.APPROVED,
      locations: { create: { address: "125 Berry Street", city: "Brooklyn", region: "NY", postalCode: "11249", latitude: 40.7188, longitude: -73.9575 } },
    },
  });
  const shop = await prisma.business.upsert({
    where: { slug: "form-and-fold" },
    update: { status: BusinessStatus.APPROVED, coverUrl: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=85" },
    create: {
      name: "Form & Fold",
      slug: "form-and-fold",
      description: "Thoughtful everyday layers, made to last beyond the season.",
      coverUrl: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1200&q=85",
      categoryId: fashion.id,
      status: BusinessStatus.APPROVED,
      locations: { create: { address: "48 Wythe Avenue", city: "Brooklyn", region: "NY", postalCode: "11249", latitude: 40.7211, longitude: -73.9582 } },
    },
  });

  const now = new Date();
  const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  await prisma.offer.upsert({
    where: { businessId_slug: { businessId: cafe.id, slug: "morning-ritual" } },
    update: { startsAt: now, endsAt: nextWeek },
    create: {
      businessId: cafe.id,
      slug: "morning-ritual",
      title: "Your new morning ritual",
      description: "Any small-batch coffee and pastry, made for slow mornings.",
      type: OfferType.PERCENTAGE,
      discountPercent: 25,
      status: OfferStatus.PUBLISHED,
      sponsored: true,
      startsAt: now,
      endsAt: nextWeek,
    },
  });
  await prisma.offer.upsert({
    where: { businessId_slug: { businessId: shop.id, slug: "soft-structure" } },
    update: { startsAt: now, endsAt: nextWeek },
    create: {
      businessId: shop.id,
      slug: "soft-structure",
      title: "A little more room to roam",
      description: "Thoughtful everyday layers, made to last beyond the season.",
      type: OfferType.PERCENTAGE,
      discountPercent: 30,
      status: OfferStatus.PUBLISHED,
      startsAt: now,
      endsAt: nextWeek,
    },
  });
  await prisma.product.upsert({
    where: { businessId_slug: { businessId: cafe.id, slug: "house-blend" } },
    update: { available: true, priceMinor: 650 },
    create: { businessId: cafe.id, slug: "house-blend", name: "House blend coffee", description: "Freshly brewed small-batch coffee, roasted for a smooth morning.", priceMinor: 650, images: { create: { url: "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1000&q=85", alt: "Cup of coffee" } } },
  });
  await prisma.product.upsert({
    where: { businessId_slug: { businessId: shop.id, slug: "everyday-layer" } },
    update: { available: true, priceMinor: 6900 },
    create: { businessId: shop.id, slug: "everyday-layer", name: "Everyday layer", description: "An easy piece for everyday wear, made to last beyond the season.", priceMinor: 6900, images: { create: { url: "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1000&q=85", alt: "Clothing on a rack" } } },
  });
  console.log("Seeded local businesses, products, and sample offers.");
}

main().finally(() => prisma.$disconnect());
