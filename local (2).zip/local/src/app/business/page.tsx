import Link from "next/link";
import { ArrowLeft, ArrowRight, Store, ShieldCheck } from "lucide-react";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";
import { BusinessRegistrationForm } from "@/components/business-registration-form";

export const dynamic = "force-dynamic";

export default async function BusinessRegistrationPage() {
  const user = await getCurrentUser();
  const memberships = user?.role === "ADMIN" ? await prisma.businessMembership.findMany({ where: { userId: user.id }, select: { role: true } }) : [];
  const managerOnly = memberships.length > 0 && memberships.every((membership) => membership.role === "MANAGER");
  const canSubmit = (user?.role === "ADMIN" || user?.role === "SUPER_ADMIN") && !managerOnly;

  return <main className="min-h-screen bg-paper px-5 py-8 text-ink sm:px-8"><div className="mx-auto max-w-3xl">
    <Link href="/" className="inline-flex items-center gap-2 text-sm text-ink/55"><ArrowLeft size={15} /> Marketplace</Link>
    <header className="mb-7 mt-7"><p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[.14em] text-moss"><Store size={15} /> SELL LOCAL</p><h1 className="mt-2 font-display text-3xl font-semibold">Bring your business to LocalLink.</h1><p className="mt-2 max-w-xl text-sm leading-6 text-ink/55">Create your shop account, submit your listing, and manage offers in one place.</p></header>
    {!user ? <section className="rounded-3xl border border-ink/5 bg-white p-6 shadow-sm sm:p-8"><h2 className="font-display text-xl font-semibold">Start with your own account</h2><p className="mt-2 text-sm leading-6 text-ink/60">Choose Shop owner when you create your account. Then sign in and submit your shop for platform review. You can prepare draft offers while the shop is reviewed, then publish them directly after approval.</p><div className="mt-5 flex flex-wrap gap-3"><Link href="/register?type=shop" className="inline-flex items-center gap-2 rounded-full bg-moss px-5 py-2.5 text-sm font-semibold text-white">Create account <ArrowRight size={15} /></Link><Link href="/sign-in?type=shop" className="inline-flex items-center rounded-full border border-ink/10 px-5 py-2.5 text-sm font-semibold text-moss">Shop sign in</Link></div></section> : managerOnly ? <section className="rounded-3xl border border-ink/5 bg-white p-6 shadow-sm sm:p-8"><ShieldCheck size={25} className="text-moss" /><h2 className="mt-4 font-display text-xl font-semibold">Manage your assigned shop</h2><p className="mt-2 text-sm leading-6 text-ink/60">Manager accounts can update the shops they are assigned to. Ask the platform super admin if you need to register a new shop as an owner.</p><Link href="/business-dashboard" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-moss">Open your dashboard <ArrowRight size={15} /></Link></section> : !canSubmit ? <section className="rounded-3xl border border-ink/5 bg-white p-6 shadow-sm sm:p-8"><ShieldCheck size={25} className="text-moss" /><h2 className="mt-4 font-display text-xl font-semibold">Shop admin approval needed</h2><p className="mt-2 text-sm leading-6 text-ink/60">This account was created for shopping. To use this email as a shop owner, ask a platform admin to enable shop access. New owners can choose Shop owner during registration.</p><Link href="/account" className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-moss">Your account <ArrowRight size={15} /></Link></section> : <><div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-moss/5 p-4 text-sm text-ink/65"><span>Signed in as <strong>{user.email}</strong></span><Link href="/business-dashboard" className="font-semibold text-moss">Your shops →</Link></div><BusinessRegistrationForm /></>}
  </div></main>;
}
