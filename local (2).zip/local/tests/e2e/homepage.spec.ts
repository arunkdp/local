import { expect, test } from "@playwright/test";

test("visitor can discover local offers without an account", async ({ page }) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /your neighborhood/i })).toBeVisible();
  await expect(page.getByRole("heading", { name: /worth stepping out for/i })).toBeVisible();
  await expect(page.getByText("Daybreak Coffee").first()).toBeVisible();
});

test("visitor can open customer registration", async ({ page }) => {
  await page.goto("/register");
  await expect(page.getByRole("heading", { name: /find your local/i })).toBeVisible();
  await expect(page.getByLabel("Email address")).toBeVisible();
  await expect(page.getByLabel("Create a password")).toHaveAttribute("minlength", "12");
});

test("visitor can open sign-in", async ({ page }) => {
  await page.goto("/sign-in");
  await expect(page.getByRole("heading", { name: /welcome back/i })).toBeVisible();
  await expect(page.getByLabel("Email address")).toBeVisible();
});
