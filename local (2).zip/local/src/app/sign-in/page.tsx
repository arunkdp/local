"use client";

import Link from "next/link";
import { getSession, signIn, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { ArrowLeft, Compass, LoaderCircle, ShieldCheck, Store, UserRound } from "lucide-react";

type SignInType = "customer" | "shop" | "admin";

export default function SignInPage() {
  const router = useRouter();
  const [accountType, setAccountType] = useState<SignInType>("customer");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    const type = new URLSearchParams(window.location.search).get("type");
    if (type === "shop" || type === "admin") setAccountType(type);
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setPending(true);
    try {
      const values = new FormData(event.currentTarget);
      const result = await signIn("credentials", {
        email: values.get("email"),
        password: values.get("password"),
        redirect: false,
      });
      if (result?.error) {
        setError("We couldn't sign you in with those details. Check your email and password.");
        return;
      }
      if (accountType === "admin") {
        const session = await getSession();
        if (session?.user.role !== "SUPER_ADMIN") {
          await signOut({ redirect: false });
          setError("This account does not have platform admin access.");
          return;
        }
      }
      router.push(accountType === "admin" ? "/admin" : "/dashboard");
      router.refresh();
    } catch {
      setError("We couldn't reach sign-in services. Check your connection and try again.");
    } finally {
      setPending(false);
    }
  }

  const shop = accountType === "shop";
  const admin = accountType === "admin";
  const registerHref = shop ? "/register?type=shop" : "/register";

  return <main className="grid min-h-screen place-items-center bg-paper px-5 py-10"><div className="w-full max-w-[500px]">
    <Link href="/" className="mb-8 inline-flex items-center gap-2 text-sm text-ink/55 hover:text-moss"><ArrowLeft size={16} /> Back to discovery</Link>
    <div className="rounded-[28px] border border-ink/5 bg-white p-7 shadow-soft sm:p-9">
      <Link href="/" className="mb-7 flex items-center gap-2.5"><span className="grid h-9 w-9 place-items-center rounded-[13px] bg-moss text-lime"><Compass size={20} /></span><span className="font-display text-xl font-semibold">local<span className="text-moss">link</span></span></Link>
      <div className="grid grid-cols-3 gap-1 rounded-2xl bg-paper p-1" aria-label="Sign in as">
        <button type="button" aria-pressed={accountType === "customer"} onClick={() => { setAccountType("customer"); setError(""); }} className={`flex min-h-12 flex-col items-center justify-center gap-1 rounded-xl px-1 text-xs font-semibold transition sm:flex-row sm:gap-2 sm:text-sm ${accountType === "customer" ? "bg-white text-moss shadow-sm" : "text-ink/55 hover:text-ink"}`}><UserRound size={16} /> Customer</button>
        <button type="button" aria-pressed={shop} onClick={() => { setAccountType("shop"); setError(""); }} className={`flex min-h-12 flex-col items-center justify-center gap-1 rounded-xl px-1 text-xs font-semibold transition sm:flex-row sm:gap-2 sm:text-sm ${shop ? "bg-white text-moss shadow-sm" : "text-ink/55 hover:text-ink"}`}><Store size={16} /> Shop owner</button>
        <button type="button" aria-pressed={admin} onClick={() => { setAccountType("admin"); setError(""); }} className={`flex min-h-12 flex-col items-center justify-center gap-1 rounded-xl px-1 text-xs font-semibold transition sm:flex-row sm:gap-2 sm:text-sm ${admin ? "bg-white text-moss shadow-sm" : "text-ink/55 hover:text-ink"}`}><ShieldCheck size={16} /> Platform admin</button>
      </div>
      <p className="eyebrow mt-7">{admin ? "PLATFORM OPERATIONS" : shop ? "YOUR BUSINESS WORKSPACE" : "GOOD TO SEE YOU AGAIN"}</p>
      <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight">{admin ? "Review your community." : shop ? "Welcome back to your shop." : "Welcome back."}</h1>
      <p className="mt-2 text-sm leading-6 text-ink/55">{admin ? "Sign in with a platform admin account to review pending shops and offers." : shop ? "Owners and managers sign in with their own email and password. Your assigned shop opens after sign in." : "Sign in to save offers, follow shops, and explore what's nearby."}</p>
      <form onSubmit={submit} className="mt-7 space-y-4">
        <label className="block text-sm font-medium">Email address<input name="email" type="email" autoComplete="email" required maxLength={254} className="mt-1.5 h-12 w-full rounded-xl border border-ink/10 px-4 text-sm outline-none focus:border-moss" placeholder="you@example.com" /></label>
        <label className="block text-sm font-medium">Password<input name="password" type="password" autoComplete="current-password" required className="mt-1.5 h-12 w-full rounded-xl border border-ink/10 px-4 text-sm outline-none focus:border-moss" placeholder="Your password" /></label>
        {error && <p role="alert" className="rounded-xl bg-red-50 px-3.5 py-3 text-sm text-red-700">{error}</p>}
        <button disabled={pending} className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-moss text-sm font-semibold text-white transition hover:bg-ink disabled:opacity-60">{pending && <LoaderCircle size={16} className="animate-spin" />}Sign in</button>
      </form>
      {admin ? <details className="mt-6 rounded-2xl bg-paper p-4 text-sm text-ink/65"><summary className="cursor-pointer font-semibold text-moss">Setting up the first platform admin</summary><ol className="mt-3 list-decimal space-y-2 pl-5 text-xs leading-5"><li><Link href="/register" className="font-semibold text-moss underline">Create your own account</Link> using the Customer option.</li><li>Set <code>BOOTSTRAP_SUPER_ADMIN_EMAIL</code> in the local <code>.env</code> file to that account&apos;s email.</li><li>Run <code>npm run db:bootstrap-super-admin</code> once in the project folder, then sign in here. Never share your password.</li></ol></details> : <p className="mt-6 text-center text-sm text-ink/55">{shop ? "New shop owner?" : "New around here?"} <Link href={registerHref} className="font-semibold text-moss hover:underline">{shop ? "Create a shop account" : "Create a free account"}</Link></p>}
      {shop && <p className="mt-3 text-center text-xs text-ink/45">Managers use the account assigned by their shop owner.</p>}
      <p className="mt-5 text-xs leading-5 text-ink/40">Password recovery and email verification will be added when an email delivery provider is configured.</p>
    </div>
  </div></main>;
}