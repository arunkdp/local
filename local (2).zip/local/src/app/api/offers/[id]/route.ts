import { NextResponse } from "next/server";
import { z } from "zod";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getCurrentUser, canManageBusiness } from "@/lib/authorization";


export const dynamic = "force-dynamic";

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!z.string().min(1).max(100).safeParse(id).success) return NextResponse.json({ error: "Invalid offer." }, { status: 400 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Offer details require database configuration." }, { status: 503 });
  try {
    const offer = await prisma.offer.findFirst({ where: { ...(z.string().uuid().safeParse(id).success ? { OR: [{ id }, { slug: id }] } : { slug: id }), status: "PUBLISHED", startsAt: { lte: new Date() }, endsAt: { gt: new Date() }, business: { status: "APPROVED" } }, include: { business: { include: { category: true, locations: { where: { isPrimary: true }, take: 1 } } }, product: true } });
    if (!offer) return NextResponse.json({ error: "Offer not found." }, { status: 404 });
    return NextResponse.json({ offer }, { headers: { "Cache-Control": "public, max-age=30, stale-while-revalidate=120" } });
  } catch (error) {
    console.error("Offer detail query failed", error);
    return NextResponse.json({ error: "Offer details are unavailable." }, { status: 503 });
  }
}

const updateSchema = z.object({
  action: z.enum(["edit", "pause", "publish", "submit", "archive"]),
  title: z.string().trim().min(3).max(120).optional(),
  description: z.string().trim().min(10).max(5000).optional(),
  imageUrl: z.string().regex(/^\/uploads\/offers\/[0-9a-f-]{36}-[0-9a-f-]{36}\.(jpg|png|webp)$/i, "Upload an offer image first.").nullable().optional(),
  startsAt: z.coerce.date().optional(),
  endsAt: z.coerce.date().optional(),
  terms: z.string().trim().max(5000).nullable().optional(),
  discountPercent: z.number().positive().max(100).optional(),
});

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to manage offers." }, { status: 401 });
  const { id } = await context.params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid offer." }, { status: 400 });
  const parsed = updateSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check the offer details." }, { status: 400 });

  try {
    const offer = await prisma.offer.findUnique({ where: { id }, select: { businessId: true, status: true, startsAt: true, endsAt: true, type: true, business: { select: { status: true } } } });
    if (!offer) return NextResponse.json({ error: "Offer not found." }, { status: 404 });
    if (!(await canManageBusiness(user.id, offer.businessId))) return NextResponse.json({ error: "You don't have access to this offer." }, { status: 403 });
    const { action, ...fields } = parsed.data;
    if (offer.status === "ARCHIVED") return NextResponse.json({ error: "Archived offers cannot be changed." }, { status: 409 });

    let data: Prisma.OfferUpdateInput;
    if (action === "edit") {
      if (!Object.keys(fields).length) return NextResponse.json({ error: "Choose an offer field to update." }, { status: 400 });
      if ((fields.endsAt ?? offer.endsAt) <= (fields.startsAt ?? offer.startsAt)) return NextResponse.json({ error: "End time must be after the start time." }, { status: 400 });
      if (fields.imageUrl && !fields.imageUrl.startsWith(`/uploads/offers/${offer.businessId}-`)) return NextResponse.json({ error: "This image does not belong to this business." }, { status: 400 });
      if (fields.discountPercent !== undefined && offer.type !== "PERCENTAGE") return NextResponse.json({ error: "This offer does not use a percentage discount." }, { status: 400 });
      const status = offer.business.status !== "APPROVED" ? "DRAFT" as const : offer.status === "PAUSED" || offer.status === "DRAFT" ? offer.status : "PUBLISHED" as const;
      data = { ...fields, status, submittedAt: null, publishedAt: status === "PUBLISHED" ? new Date() : null };
    } else if (action === "pause") {
      if (offer.status !== "PUBLISHED") return NextResponse.json({ error: "Only a published offer can be paused." }, { status: 409 });
      data = { status: "PAUSED" as const };
    } else if (action === "publish" || action === "submit") {
      if (offer.business.status !== "APPROVED") return NextResponse.json({ error: "The business must be approved first." }, { status: 409 });
      if (!["DRAFT", "REJECTED", "PAUSED", "PENDING"].includes(offer.status)) return NextResponse.json({ error: "This offer cannot be published now." }, { status: 409 });
      if (offer.endsAt <= new Date()) return NextResponse.json({ error: "Extend the offer end date before publishing." }, { status: 409 });
      data = { status: "PUBLISHED" as const, submittedAt: null, publishedAt: new Date() };
    } else {
      data = { status: "ARCHIVED" as const, publishedAt: null };
    }

    const updated = await prisma.$transaction(async (tx) => {
      const result = await tx.offer.update({ where: { id }, data, select: { id: true, title: true, status: true } });
      await tx.adminAuditLog.create({ data: { actorId: user.id, action: `OFFER_${action.toUpperCase()}`, entityType: "Offer", entityId: id, metadata: { fields: Object.keys(fields) } } });
      return result;
    });
    return NextResponse.json({ offer: updated });
  } catch (error) {
    console.error("Offer update failed", error);
    return NextResponse.json({ error: "Couldn't update this offer." }, { status: 503 });
  }
}
