﻿import Link from "next/link";
import { OfferDetail } from "@/components/offer-detail";

export default async function OfferPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <main className="min-h-screen bg-paper px-5 py-8 text-ink sm:px-8"><div className="mx-auto mb-7 max-w-5xl"><Link href="/" className="text-sm font-semibold text-moss">← LocalLink</Link></div><div className="mx-auto max-w-5xl"><OfferDetail id={id} /></div></main>;
}

