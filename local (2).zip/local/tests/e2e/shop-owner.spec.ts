import { expect, test } from "@playwright/test";
import { unlink } from "node:fs/promises";
import path from "node:path";
import { prisma } from "../../src/lib/prisma";

test("a new shop owner signs up, submits a shop, and manages an offer image and dates", async ({ page }) => {
  test.setTimeout(180000);
  const email = `owner-${crypto.randomUUID()}@example.test`;
  const password = "ShopOwnerPass123";
  let userId: string | undefined;
  let businessId: string | undefined;
  let imageUrl: string | undefined;

  try {
    await page.goto("/register?type=shop", { waitUntil: "domcontentloaded" });
    await expect(page.getByRole("button", { name: "Shop owner" })).toHaveAttribute("aria-pressed", "true");
    await page.getByLabel("Your name").fill("Local Shop Owner");
    await page.getByLabel("Email address").fill(email);
    await page.getByLabel("Create a password").fill(password);
    await page.getByRole("button", { name: "Create shop account" }).click();
    await expect(page).toHaveURL(/\/business$/, { timeout: 45000 });
    await expect(page.getByRole("button", { name: "Submit for verification" })).toBeVisible();
    userId = (await prisma.user.findUniqueOrThrow({ where: { email }, select: { id: true, role: true } })).id;

    await page.getByLabel("Business name").fill("New Local Shop");
    await page.getByLabel("Category").selectOption({ label: "Food & drink" });
    await page.getByLabel("Description").fill("A local shop created to verify owner onboarding.");
    await page.getByLabel("Street address").fill("1 Market Street");
    await page.getByLabel("City").fill("Colombo");
    await page.getByLabel("Latitude").fill("6.9271");
    await page.getByLabel("Longitude").fill("79.8612");
    await page.getByRole("button", { name: "Submit for verification" }).click();
    await expect(page).toHaveURL(/\/business-dashboard$/, { timeout: 45000 });

    const business = await prisma.business.findFirstOrThrow({
      where: { memberships: { some: { userId } } },
      select: { id: true, status: true },
    });
    businessId = business.id;
    expect(business.status).toBe("PENDING");

    const image = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Z4u8AAAAASUVORK5CYII=", "base64");
    const upload = await page.request.post(`/api/businesses/${businessId}/offers/image`, {
      multipart: { image: { name: "offer.png", mimeType: "image/png", buffer: image } },
    });
    expect(upload.status()).toBe(201);
    imageUrl = (await upload.json()).imageUrl;

    const startsAt = new Date(Date.now() + 3600_000).toISOString();
    const endsAt = new Date(Date.now() + 3 * 86400_000).toISOString();
    const created = await page.request.post(`/api/businesses/${businessId}/offers`, {
      data: { title: "Welcome discount", description: "A local discount with an uploaded image.", type: "PERCENTAGE", discountPercent: 15, startsAt, endsAt, imageUrl },
    });
    expect(created.status()).toBe(201);
    const { offer } = await created.json();
    expect(offer.status).toBe("DRAFT");

    const revisedEnd = new Date(Date.now() + 5 * 86400_000).toISOString();
    const updated = await page.request.patch(`/api/offers/${offer.id}`, {
      data: { action: "edit", endsAt: revisedEnd },
    });
    expect(updated.status()).toBe(200);
    const saved = await prisma.offer.findUniqueOrThrow({ where: { id: offer.id } });
    expect(saved.imageUrl).toBe(imageUrl);
    expect(saved.endsAt.toISOString()).toBe(revisedEnd);

    const blockedPublish = await page.request.patch(`/api/offers/${offer.id}`, { data: { action: "publish" } });
    expect(blockedPublish.status()).toBe(409);

    await prisma.business.update({ where: { id: businessId }, data: { status: "APPROVED" } });
    const publishedDraft = await page.request.patch(`/api/offers/${offer.id}`, { data: { action: "publish" } });
    expect(publishedDraft.status()).toBe(200);
    expect((await publishedDraft.json()).offer.status).toBe("PUBLISHED");

    const activeStart = new Date(Date.now() - 3600_000).toISOString();
    const directOffer = await page.request.post(`/api/businesses/${businessId}/offers`, {
      data: { title: "Direct discount", description: "This approved shop publishes without review.", type: "PERCENTAGE", discountPercent: 20, startsAt: activeStart, endsAt, imageUrl },
    });
    expect(directOffer.status()).toBe(201);
    const direct = (await directOffer.json()).offer;
    expect(direct.status).toBe("PUBLISHED");
    const publicOffer = await page.request.get(`/api/offers/${direct.id}`);
    expect(publicOffer.status()).toBe(200);

    const changed = await page.request.patch(`/api/offers/${direct.id}`, { data: { action: "edit", description: "An updated direct discount for local customers." } });
    expect(changed.status()).toBe(200);
    expect((await changed.json()).offer.status).toBe("PUBLISHED");

    const profileUpdated = await page.request.patch(`/api/businesses/${businessId}`, { data: { description: "A local shop with an updated profile and direct offers." } });
    expect(profileUpdated.status()).toBe(200);
    expect((await profileUpdated.json()).business.status).toBe("APPROVED");

    await page.goto(`/business-dashboard/${businessId}`);
    await expect(page.getByRole("heading", { name: "New Local Shop" })).toBeVisible();
    await page.goto("/sign-in?type=admin");
    await expect(page.getByRole("button", { name: "Platform admin" })).toHaveAttribute("aria-pressed", "true");
    await page.getByLabel("Email address").fill(email);
    await page.getByLabel("Password").fill(password);
    await page.getByRole("button", { name: "Sign in", exact: true }).click();
    await expect(page.getByText("This account does not have platform admin access.")).toBeVisible();
  } finally {
    if (userId) await prisma.adminAuditLog.deleteMany({ where: { actorId: userId } });
    if (businessId) await prisma.business.delete({ where: { id: businessId } }).catch(() => {});
    if (userId) await prisma.user.delete({ where: { id: userId } }).catch(() => {});
    if (imageUrl) await unlink(path.join(process.cwd(), "public", imageUrl.replace(/^\//, ""))).catch(() => {});
  }
});