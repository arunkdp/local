"use client";

import { useCallback, useEffect, useState } from "react";
import { Check, LoaderCircle, ShieldAlert, Users } from "lucide-react";

type Queue = {
  businesses: Array<{
    id: string;
    name: string;
    description: string;
    category: { name: string };
    memberships: Array<{ user: { name: string | null; email: string } }>;
  }>;
  reports: Array<{
    id: string;
    targetType: "BUSINESS" | "PRODUCT" | "OFFER" | "USER";
    targetId: string;
    reason: string;
    details: string | null;
    status: "OPEN" | "REVIEWING";
    createdAt: string;
    author: { name: string | null; email: string };
    offer: { title: string } | null;
  }>;
  stats: { users: number; businesses: number; pendingBusinesses: number };
  audit: Array<{
    id: string;
    action: string;
    entityType: string;
    createdAt: string;
    actor: { name: string | null; email: string };
  }>;
};

type AdminUser = {
  id: string;
  name: string | null;
  email: string;
  role: "CUSTOMER" | "ADMIN" | "SUPER_ADMIN";
  disabledAt: string | null;
  createdAt: string;
};

type ModerationDecision = "approve" | "reject" | "suspend" | "reinstate" | "review" | "resolve" | "dismiss";

export function AdminConsole() {
  const [queue, setQueue] = useState<Queue | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [error, setError] = useState("");
  const [pending, setPending] = useState("");
  const [notice, setNotice] = useState("");

  const load = useCallback(async () => {
    try {
      const [queueResponse, usersResponse] = await Promise.all([
        fetch("/api/admin/queue", { cache: "no-store" }),
        fetch("/api/admin/users", { cache: "no-store" }),
      ]);
      const [queueBody, usersBody] = await Promise.all([
        queueResponse.json().catch(() => ({})),
        usersResponse.json().catch(() => ({})),
      ]);
      if (!queueResponse.ok || !usersResponse.ok) {
        setError(
          !queueResponse.ok
            ? queueBody.error ?? "Admin data is unavailable."
            : usersBody.error ?? "User data is unavailable.",
        );
        return;
      }
      setQueue(queueBody);
      setUsers(usersBody.users);
      setError("");
    } catch {
      setError("Couldn't reach administrator services. Check your connection and retry.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function moderate(
    target: "business" | "report",
    id: string,
    decision: ModerationDecision,
  ) {
    setPending(id);
    setNotice("");
    try {
      const response = await fetch("/api/admin/moderate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target, id, decision }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        setNotice(body.error ?? "Moderation failed.");
        return;
      }
      setNotice(`Updated ${target} status.`);
      await load();
    } catch {
      setNotice("Couldn't reach moderation services. Check your connection and retry.");
    } finally {
      setPending("");
    }
  }

  async function setUserDisabled(user: AdminUser) {
    setPending(user.id);
    setNotice("");
    try {
      const response = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: user.id, disabled: !user.disabledAt }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        setNotice(body.error ?? "Couldn't update this account.");
        return;
      }
      setNotice(user.disabledAt ? "Account reinstated." : "Account suspended.");
      await load();
    } catch {
      setNotice("Couldn't reach user management. Check your connection and retry.");
    } finally {
      setPending("");
    }
  }

  async function setUserRole(user: AdminUser, role: "CUSTOMER" | "ADMIN" | "SUPER_ADMIN") {
    setPending(user.id);
    setNotice("");
    try {
      const response = await fetch("/api/admin/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: user.id, role }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        setNotice(body.error ?? "Couldn't update this user's role.");
        return;
      }
      setNotice(`Updated ${user.email} to ${role.toLowerCase().replace("_", " ")}.`);
      await load();
    } catch {
      setNotice("Couldn't reach user management. Check your connection and retry.");
    } finally {
      setPending("");
    }
  }

  return (
    <div className="space-y-7">
      <div className="grid gap-3 sm:grid-cols-3">
        {[
          ["Members", queue?.stats.users],
          ["Businesses", queue?.stats.businesses],
          ["Business reviews", queue?.stats.pendingBusinesses],
        ].map(([label, value]) => (
          <div key={label} className="rounded-2xl border border-ink/5 bg-white p-4">
            <p className="text-xs text-ink/50">{label}</p>
            <p className="mt-1 font-display text-2xl font-semibold">{value ?? "—"}</p>
          </div>
        ))}
      </div>
      {error && (
        <div role="alert" className="rounded-2xl bg-amber-50 p-4 text-sm text-amber-900">
          {error}
        </div>
      )}
      {notice && (
        <div role="status" className="rounded-2xl bg-moss/10 p-3 text-sm text-moss">
          {notice}
        </div>
      )}

      <section className="rounded-3xl border border-ink/5 bg-white p-5 sm:p-6">
        <div className="flex items-center gap-2">
          <ShieldAlert size={18} className="text-moss" />
          <h2 className="font-display text-xl font-semibold">Business verification</h2>
        </div>
        <div className="mt-4 space-y-3">
          {queue?.businesses.map((business) => (
            <article key={business.id} className="rounded-2xl bg-paper p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="font-semibold">{business.name}</h3>
                  <p className="mt-1 text-xs text-ink/55">
                    {business.category.name} · {business.memberships[0]?.user.email}
                  </p>
                  <p className="mt-2 max-w-2xl text-sm text-ink/65">{business.description}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    disabled={pending === business.id}
                    onClick={() => moderate("business", business.id, "reject")}
                    className="rounded-full border border-ink/10 px-3 py-2 text-xs font-semibold hover:border-red-300 hover:text-red-700"
                  >
                    Reject
                  </button>
                  <button
                    disabled={pending === business.id}
                    onClick={() => moderate("business", business.id, "approve")}
                    className="flex items-center gap-1 rounded-full bg-moss px-3 py-2 text-xs font-semibold text-white hover:bg-ink"
                  >
                    {pending === business.id ? (
                      <LoaderCircle size={13} className="animate-spin" />
                    ) : (
                      <Check size={13} />
                    )}
                    Approve
                  </button>
                </div>
              </div>
            </article>
          ))}
          {queue && queue.businesses.length === 0 && (
            <p className="rounded-2xl bg-paper p-5 text-sm text-ink/55">
              No businesses are awaiting review.
            </p>
          )}
        </div>
      </section>

      <section className="rounded-3xl border border-ink/5 bg-white p-5 sm:p-6">
        <div className="flex items-center gap-2">
          <ShieldAlert size={18} className="text-moss" />
          <h2 className="font-display text-xl font-semibold">User reports</h2>
        </div>
        <div className="mt-4 space-y-3">
          {queue?.reports.map((report) => (
            <article key={report.id} className="rounded-2xl bg-paper p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-moss">
                    {report.targetType.toLowerCase()} report · {report.status.toLowerCase()}
                  </p>
                  <h3 className="mt-1 font-semibold">{report.reason}</h3>
                  <p className="mt-1 text-xs text-ink/55">
                    Submitted by {report.author.name ?? report.author.email}
                    {report.offer ? ` · ${report.offer.title}` : ` · Reference ${report.targetId}`}
                  </p>
                  {report.details && (
                    <p className="mt-2 max-w-2xl text-sm text-ink/65">{report.details}</p>
                  )}
                  <time className="mt-2 block text-xs text-ink/45">
                    {new Date(report.createdAt).toLocaleString()}
                  </time>
                </div>
                <div className="flex flex-wrap gap-2">
                  {report.status === "OPEN" && (
                    <button
                      disabled={pending === report.id}
                      onClick={() => moderate("report", report.id, "review")}
                      className="rounded-full border border-ink/10 px-3 py-2 text-xs font-semibold hover:border-moss/40"
                    >
                      Mark reviewing
                    </button>
                  )}
                  <button
                    disabled={pending === report.id}
                    onClick={() => moderate("report", report.id, "dismiss")}
                    className="rounded-full border border-ink/10 px-3 py-2 text-xs font-semibold hover:border-red-300 hover:text-red-700"
                  >
                    Dismiss
                  </button>
                  <button
                    disabled={pending === report.id}
                    onClick={() => moderate("report", report.id, "resolve")}
                    className="rounded-full bg-moss px-3 py-2 text-xs font-semibold text-white hover:bg-ink"
                  >
                    Resolve
                  </button>
                </div>
              </div>
            </article>
          ))}
          {queue && queue.reports.length === 0 && (
            <p className="rounded-2xl bg-paper p-5 text-sm text-ink/55">
              No reports are awaiting review.
            </p>
          )}
        </div>
      </section>

      <section className="rounded-3xl border border-ink/5 bg-white p-5 sm:p-6">
        <div className="flex items-center gap-2">
          <Users size={18} className="text-moss" />
          <h2 className="font-display text-xl font-semibold">User management</h2>
        </div>
        <p className="mt-2 text-xs leading-5 text-ink/55">For a shop owner or manager login, have the person register their own account, then set its role to Admin here. Owners submit shops and add approved managers from their shop dashboard.</p>
        <ul className="mt-4 divide-y divide-ink/5">
          {users.map((user) => (
            <li
              key={user.id}
              className="flex flex-wrap items-center justify-between gap-3 py-3"
            >
              <div>
                <p className="font-semibold">{user.name ?? user.email}</p>
                <p className="mt-1 text-xs text-ink/55">
                  {user.email} · {user.role.toLowerCase().replace("_", " ")}
                  {user.disabledAt ? " · suspended" : ""}
                </p>
              </div>
              {user.role !== "SUPER_ADMIN" && (
                <div className="flex flex-wrap items-center gap-2">
                  <label className="sr-only" htmlFor={`role-${user.id}`}>
                    Role for {user.email}
                  </label>
                  <select
                    id={`role-${user.id}`}
                    value={user.role}
                    disabled={pending === user.id}
                    onChange={(event) => {
                      const role = event.currentTarget.value;
                      if (role === "CUSTOMER" || role === "ADMIN" || role === "SUPER_ADMIN") {
                        void setUserRole(user, role);
                      }
                    }}
                    className="rounded-full border border-ink/10 bg-white px-3 py-2 text-xs font-semibold"
                  >
                    <option value="CUSTOMER">Customer</option>
                    <option value="ADMIN">Admin</option>
                    <option value="SUPER_ADMIN">Super admin</option>
                  </select>
                  <button
                    disabled={pending === user.id}
                    onClick={() => void setUserDisabled(user)}
                    className={
                      user.disabledAt
                        ? "rounded-full bg-moss px-3 py-2 text-xs font-semibold text-white hover:bg-ink"
                        : "rounded-full border border-ink/10 px-3 py-2 text-xs font-semibold hover:border-red-300 hover:text-red-700"
                    }
                  >
                    {user.disabledAt ? "Reinstate" : "Suspend"}
                  </button>
                </div>
              )}
            </li>
          ))}
          {users.length === 0 && !error && (
            <li className="py-4 text-sm text-ink/55">No users found.</li>
          )}
        </ul>
      </section>

      <section className="rounded-3xl border border-ink/5 bg-white p-5 sm:p-6">
        <div className="flex items-center gap-2">
          <Users size={18} className="text-moss" />
          <h2 className="font-display text-xl font-semibold">Recent administrator audit</h2>
        </div>
        <ul className="mt-4 divide-y divide-ink/5">
          {queue?.audit.map((entry) => (
            <li
              key={entry.id}
              className="flex flex-wrap justify-between gap-2 py-3 text-sm"
            >
              <span>
                <strong>{entry.action}</strong>
                <span className="ml-2 text-ink/50">
                  by {entry.actor.name ?? entry.actor.email}
                </span>
              </span>
              <time className="text-xs text-ink/45">
                {new Date(entry.createdAt).toLocaleString()}
              </time>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
