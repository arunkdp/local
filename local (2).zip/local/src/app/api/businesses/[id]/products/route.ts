import { NextResponse } from "next/server";
import { z } from "zod";
import { canManageBusiness, getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

const paramsSchema = z.string().uuid();
const productSchema = z.object({
  name: z.string().trim().min(2).max(120),
  description: z.string().trim().min(5).max(5000),
  categoryId: z.string().uuid().optional().nullable(),
  priceMinor: z.number().int().nonnegative().optional().nullable(),
  promotionalMinor: z.number().int().nonnegative().optional().nullable(),
  imageUrl: z.string().url().refine((url) => url.startsWith("https://"), "Images must use HTTPS.").optional().nullable(),
}).refine((data) => data.promotionalMinor == null || data.priceMinor != null && data.promotionalMinor < data.priceMinor, { path: ["promotionalMinor"], message: "Promotional price must be lower than the regular price." });
const slugify = (value: string) => value.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 80);

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!paramsSchema.safeParse(id).success) return NextResponse.json({ error: "Invalid business." }, { status: 400 });
  try {
    const user = await getCurrentUser();
    const manager = user ? await canManageBusiness(user.id, id) : false;
    const products = await prisma.product.findMany({ where: { businessId: id, ...(manager ? {} : { available: true, business: { status: "APPROVED" } }) }, include: { images: { orderBy: { position: "asc" } }, category: true }, orderBy: { createdAt: "desc" }, take: 100 });
    return NextResponse.json({ products });
  } catch (error) {
    console.error("Public product list failed", error);
    return NextResponse.json({ error: "Products are unavailable." }, { status: 503 });
  }
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to manage products." }, { status: 401 });
  const { id } = await context.params;
  if (!paramsSchema.safeParse(id).success || !(await canManageBusiness(user.id, id))) return NextResponse.json({ error: "You don't have access to this business." }, { status: 403 });
  const parsed = productSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check the product details." }, { status: 400 });

  try {
    if (parsed.data.categoryId && !(await prisma.productCategory.findUnique({ where: { id: parsed.data.categoryId }, select: { id: true } }))) return NextResponse.json({ error: "Choose a valid product category." }, { status: 400 });
    const product = await prisma.product.create({
      data: {
        businessId: id,
        name: parsed.data.name,
        slug: `${slugify(parsed.data.name) || "product"}-${crypto.randomUUID().slice(0, 8)}`,
        description: parsed.data.description,
        categoryId: parsed.data.categoryId,
        priceMinor: parsed.data.priceMinor,
        promotionalMinor: parsed.data.promotionalMinor,
        images: parsed.data.imageUrl ? { create: [{ url: parsed.data.imageUrl, alt: parsed.data.name }] } : undefined,
      },
      select: { id: true, slug: true, name: true },
    });
    return NextResponse.json({ product }, { status: 201 });
  } catch (error) {
    console.error("Product creation failed", error);
    return NextResponse.json({ error: "Couldn't create this product." }, { status: 503 });
  }
}
