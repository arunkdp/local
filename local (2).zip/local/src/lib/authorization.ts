import type { UserRole } from "@prisma/client";
import { auth } from "../../auth";
import { prisma } from "@/lib/prisma";

export async function getCurrentUser() {
  const session = await auth();
  if (!session?.user?.id || !process.env.DATABASE_URL) return null;
  return prisma.user.findFirst({
    where: { id: session.user.id, disabledAt: null },
    select: { id: true, name: true, email: true, role: true },
  });
}

export async function hasRole(allowed: UserRole[]) {
  const user = await getCurrentUser();
  return user && allowed.includes(user.role) ? user : null;
}

export async function canManageBusiness(userId: string, businessId: string) {
  const user = await prisma.user.findFirst({
    where: { id: userId, disabledAt: null },
    select: { role: true },
  });
  if (!user || user.role === "CUSTOMER") return false;
  if (user.role === "SUPER_ADMIN") return true;

  const membership = await prisma.businessMembership.findUnique({
    where: { userId_businessId: { userId, businessId } },
    select: { id: true },
  });
  return Boolean(membership);
}
