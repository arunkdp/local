import { hash } from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const registrationSchema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(254),
  accountType: z.enum(["CUSTOMER", "SHOP_OWNER"]).default("CUSTOMER"),
  password: z.string().min(12).max(64)
    .regex(/[a-z]/, "Use a lowercase letter.")
    .regex(/[A-Z]/, "Use an uppercase letter.")
    .regex(/[0-9]/, "Use a number."),
});

export async function POST(request: Request) {
  if (!process.env.DATABASE_URL) {
    return NextResponse.json({ error: "Account creation is not configured yet. Set up the database first." }, { status: 503 });
  }
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  const parsed = registrationSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check your details." }, { status: 400 });
  }

  const email = parsed.data.email.toLowerCase();
  try {
    await prisma.user.create({
      data: {
        name: parsed.data.name,
        email,
        passwordHash: await hash(parsed.data.password, 12),
        role: parsed.data.accountType === "SHOP_OWNER" ? "ADMIN" : "CUSTOMER",
        profile: { create: {} },
      },
      select: { id: true },
    });
    return NextResponse.json({ created: true }, { status: 201 });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "P2002") {
      return NextResponse.json({ error: "An account with this email already exists." }, { status: 409 });
    }
    console.error("Customer registration failed", error);
    return NextResponse.json({ error: "We couldn't create your account right now." }, { status: 503 });
  }
}
