import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Notifications require database configuration." }, { status: 503 });
  try {
    const notifications = await prisma.notification.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 50 });
    return NextResponse.json({ notifications }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    console.error("Notifications query failed", error);
    return NextResponse.json({ error: "Notifications are unavailable." }, { status: 503 });
  }
}

export async function PATCH(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Notifications require database configuration." }, { status: 503 });
  const parsed = z.object({ id: z.string().uuid() }).safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid notification." }, { status: 400 });
  try {
    await prisma.notification.updateMany({ where: { id: parsed.data.id, userId: user.id }, data: { readAt: new Date() } });
    return NextResponse.json({ read: true });
  } catch (error) {
    console.error("Notification update failed", error);
    return NextResponse.json({ error: "Couldn't update the notification." }, { status: 503 });
  }
}
