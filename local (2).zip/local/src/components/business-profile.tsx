"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { Heart, MapPin, Tag } from "lucide-react";

type BusinessData = {
  id: string;
  name: string;
  slug: string;
  description: string;
  category: { name: string };
  coverUrl: string | null;
  phone: string | null;
  _count: { followers: number };
  locations: Array<{ address: string; city: string; region: string | null; postalCode: string | null; latitude: number; longitude: number }>;
  products: Array<{ id: string; name: string; description: string; priceMinor: number | null; promotionalMinor: number | null; images: Array<{ url: string; alt: string | null }>; _count: { favorites: number } }>;
  offers: Array<{ id: string; title: string; description: string; imageUrl: string | null; discountPercent: string | number | null; discountMinor: number | null; endsAt: string }>;
};

export function BusinessProfile({ slug }: { slug: string }) {
  const { data: session } = useSession();
  const [business, setBusiness] = useState<BusinessData | null>(null);
  const [following, setFollowing] = useState(false);
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [busyProductId, setBusyProductId] = useState<string | null>(null);
  const [busyFollow, setBusyFollow] = useState(false);
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/businesses/${encodeURIComponent(slug)}`, { cache: "no-store" })
      .then((response) => response.ok ? response.json() : null)
      .then((data) => setBusiness(data?.business ?? null))
      .catch(() => setBusiness(null))
      .finally(() => setLoading(false));
  }, [slug]);

  const businessId = business?.id;
  useEffect(() => {
    if (!session?.user?.id || !businessId) return;
    fetch("/api/me/library", { cache: "no-store" })
      .then((response) => response.ok ? response.json() : null)
      .then((data) => {
        if (!data) return;
        setFollowing((data.followedBusinessIds ?? []).includes(businessId));
        setFavoriteIds(new Set(data.favoriteProductIds ?? []));
      })
      .catch(() => {});
  }, [session?.user?.id, businessId]);

  async function toggleFollow() {
    if (!business || busyFollow) return;
    if (!session) { window.location.href = "/sign-in"; return; }
    setBusyFollow(true); setNotice("");
    try {
      const response = await fetch(`/api/businesses/${business.id}/follow`, { method: following ? "DELETE" : "PUT" });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error ?? "Couldn't update follow state.");
      setFollowing(!following);
      setBusiness((current) => current ? { ...current, _count: { followers: Math.max(0, current._count.followers + (following ? -1 : 1)) } } : current);
      setNotice(following ? "Unfollowed this shop." : "Following this shop.");
    } catch (cause) {
      setNotice(cause instanceof Error ? cause.message : "Couldn't update follow state.");
    } finally { setBusyFollow(false); }
  }

  async function toggleFavorite(productId: string) {
    if (busyProductId) return;
    if (!session) { window.location.href = "/sign-in"; return; }
    const wasFavorite = favoriteIds.has(productId);
    setBusyProductId(productId); setNotice("");
    try {
      const response = await fetch(`/api/products/${productId}/favorite`, { method: wasFavorite ? "DELETE" : "PUT" });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error ?? "Couldn't update this product.");
      setFavoriteIds((current) => { const next = new Set(current); if (wasFavorite) next.delete(productId); else next.add(productId); return next; });
      setBusiness((current) => current ? { ...current, products: current.products.map((product) => product.id === productId ? { ...product, _count: { favorites: Math.max(0, product._count.favorites + (wasFavorite ? -1 : 1)) } } : product) } : current);
      setNotice(wasFavorite ? "Product removed from your likes." : "Product added to your likes.");
    } catch (cause) {
      setNotice(cause instanceof Error ? cause.message : "Couldn't update this product.");
    } finally { setBusyProductId(null); }
  }

  if (loading) return <div className="mx-auto max-w-5xl rounded-3xl bg-white p-8 text-sm text-ink/55">Loading this local business…</div>;
  if (!business) return <div className="mx-auto max-w-5xl rounded-3xl bg-white p-8 text-sm text-ink/55">This shop is unavailable.</div>;

  const location = business.locations[0];
  return <div className="mx-auto max-w-5xl">
    <header className="relative overflow-hidden rounded-[28px] bg-moss p-7 text-white sm:p-10">
      {business.coverUrl && <Image unoptimized src={business.coverUrl} alt="" fill className="object-cover opacity-30" />}
      <div className="relative">
        <p className="text-xs font-bold uppercase tracking-wider text-lime">{business.category.name}</p>
        <h1 className="mt-2 font-display text-4xl font-semibold">{business.name}</h1>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-white/75">{business.description}</p>
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button onClick={() => void toggleFollow()} disabled={busyFollow} aria-pressed={following} className="inline-flex items-center gap-2 rounded-full bg-lime px-4 py-2.5 text-sm font-semibold text-ink disabled:opacity-60"><Heart size={15} fill={following ? "currentColor" : "none"} />{following ? "Following" : "Follow shop"}</button>
          <span className="text-xs text-white/65">{business._count.followers} followers</span>
          {location && <a target="_blank" rel="noreferrer" href={`https://www.google.com/maps/dir/?api=1&destination=${location.latitude},${location.longitude}`} className="inline-flex items-center gap-1 text-xs text-white/80"><MapPin size={13} />Directions</a>}
        </div>
        {notice && <p role="status" className="mt-3 text-sm text-lime">{notice}</p>}
      </div>
    </header>
    {location && <p className="mt-4 text-sm text-ink/60"><MapPin className="mr-1 inline" size={14} />{location.address}, {location.city}{location.region ? `, ${location.region}` : ""}{location.postalCode ? ` ${location.postalCode}` : ""}{business.phone ? ` · ${business.phone}` : ""}</p>}

    <section className="mt-8"><h2 className="font-display text-2xl font-semibold">Current offers</h2><div className="mt-4 grid gap-3 sm:grid-cols-2">{business.offers.map((offer) => <article key={offer.id} className="overflow-hidden rounded-2xl border border-ink/5 bg-white">{offer.imageUrl && <div className="relative h-40"><Image unoptimized src={offer.imageUrl} alt="" fill sizes="(max-width: 640px) 100vw, 50vw" className="object-cover" /></div>}<div className="p-5"><p className="flex items-center gap-2 text-xs font-semibold uppercase text-moss"><Tag size={14} />{offer.discountPercent ? `${offer.discountPercent}% off` : offer.discountMinor ? `$${(offer.discountMinor / 100).toFixed(2)} off` : "Local offer"}</p><h3 className="mt-2 font-semibold">{offer.title}</h3><p className="mt-1 text-sm text-ink/55">{offer.description}</p><p className="mt-3 text-xs text-ink/45">Ends {new Date(offer.endsAt).toLocaleDateString()}</p></div></article>)}{!business.offers.length && <p className="text-sm text-ink/50">No active offers right now.</p>}</div></section>

    <section className="mt-8"><h2 className="font-display text-2xl font-semibold">Products & services</h2><p className="mt-1 text-sm text-ink/50">Like the products you want to see more of.</p><div className="mt-4 grid gap-3 sm:grid-cols-2">{business.products.map((product) => <article key={product.id} className="flex gap-4 rounded-2xl border border-ink/5 bg-white p-4"><div className="relative h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-paper">{product.images[0] && <Image unoptimized src={product.images[0].url} alt={product.images[0].alt ?? product.name} fill sizes="96px" className="object-cover" />}</div><div className="min-w-0 flex-1"><h3 className="font-semibold">{product.name}</h3><p className="mt-1 line-clamp-2 text-xs leading-5 text-ink/55">{product.description}</p>{product.priceMinor != null && <p className="mt-2 text-sm font-semibold">{product.promotionalMinor != null ? <><span className="text-ink/40 line-through">$${(product.priceMinor / 100).toFixed(2)}</span> <span className="text-moss">$${(product.promotionalMinor / 100).toFixed(2)}</span></> : `$${(product.priceMinor / 100).toFixed(2)}`}</p>}<button type="button" onClick={() => void toggleFavorite(product.id)} disabled={busyProductId === product.id} aria-pressed={favoriteIds.has(product.id)} aria-label={favoriteIds.has(product.id) ? `Unlike ${product.name}` : `Like ${product.name}`} className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-moss disabled:opacity-50"><Heart size={15} fill={favoriteIds.has(product.id) ? "currentColor" : "none"} />{favoriteIds.has(product.id) ? "Liked" : "Like"} · {product._count.favorites}</button></div></article>)}{!business.products.length && <p className="text-sm text-ink/50">The catalog is coming soon.</p>}</div></section>
    <Link href="/" className="mt-8 inline-block text-sm font-semibold text-moss">← Back to discovery</Link>
  </div>;
}
