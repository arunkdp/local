import { NextResponse } from "next/server";
import { z } from "zod";
import { canManageBusiness, getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

async function access(businessId: string) {
  const user = await getCurrentUser();
  if (!user || !(await canManageBusiness(user.id, businessId))) return null;
  if (user.role === "SUPER_ADMIN") return { user, canManageStaff: true };
  const membership = await prisma.businessMembership.findUnique({ where: { userId_businessId: { userId: user.id, businessId } }, select: { role: true } });
  return { user, canManageStaff: membership?.role === "OWNER" };
}

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid business." }, { status: 400 });
  const actor = await access(id);
  if (!actor) return NextResponse.json({ error: "Shop staff access required." }, { status: 403 });
  try {
    const members = await prisma.businessMembership.findMany({ where: { businessId: id }, select: { userId: true, role: true, createdAt: true, user: { select: { name: true, email: true } } }, orderBy: { createdAt: "asc" } });
    return NextResponse.json({ members, canManageStaff: actor.canManageStaff }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    console.error("Shop staff list failed", error);
    return NextResponse.json({ error: "Staff list is unavailable." }, { status: 503 });
  }
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid business." }, { status: 400 });
  const actor = await access(id);
  if (!actor?.canManageStaff) return NextResponse.json({ error: "Only the shop owner can add managers." }, { status: 403 });
  const parsed = z.object({ email: z.string().trim().email().max(254) }).safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Enter a valid account email." }, { status: 400 });
  try {
    const target = await prisma.user.findUnique({ where: { email: parsed.data.email.toLowerCase() }, select: { id: true, role: true, disabledAt: true, passwordHash: true } });
    if (!target || target.role !== "ADMIN" || target.disabledAt || !target.passwordHash) return NextResponse.json({ error: "The manager must create a shop account before you can add them." }, { status: 404 });
    const existing = await prisma.businessMembership.findUnique({ where: { userId_businessId: { userId: target.id, businessId: id } }, select: { id: true } });
    if (existing) return NextResponse.json({ error: "This account already belongs to the shop." }, { status: 409 });
    await prisma.$transaction(async (tx) => {
      await tx.businessMembership.create({ data: { userId: target.id, businessId: id, role: "MANAGER" } });
      await tx.adminAuditLog.create({ data: { actorId: actor.user.id, action: "SHOP_MANAGER_ADDED", entityType: "Business", entityId: id, metadata: { userId: target.id } } });
      await tx.notification.create({ data: { userId: target.id, type: "SECURITY", title: "Shop access added", body: "You can now manage this shop from your business dashboard.", href: "/business-dashboard" } });
    });
    return NextResponse.json({ added: true }, { status: 201 });
  } catch (error) {
    console.error("Shop manager add failed", error);
    return NextResponse.json({ error: "Couldn't add this manager." }, { status: 503 });
  }
}

export async function DELETE(request: Request, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid business." }, { status: 400 });
  const actor = await access(id);
  if (!actor?.canManageStaff) return NextResponse.json({ error: "Only the shop owner can remove managers." }, { status: 403 });
  const parsed = z.object({ userId: z.string().uuid() }).safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid manager." }, { status: 400 });
  try {
    const membership = await prisma.businessMembership.findUnique({ where: { userId_businessId: { userId: parsed.data.userId, businessId: id } }, select: { id: true, role: true } });
    if (!membership || membership.role !== "MANAGER") return NextResponse.json({ error: "Manager not found." }, { status: 404 });
    await prisma.$transaction(async (tx) => {
      await tx.businessMembership.delete({ where: { id: membership.id } });
      await tx.adminAuditLog.create({ data: { actorId: actor.user.id, action: "SHOP_MANAGER_REMOVED", entityType: "Business", entityId: id, metadata: { userId: parsed.data.userId } } });
    });
    return NextResponse.json({ removed: true });
  } catch (error) {
    console.error("Shop manager removal failed", error);
    return NextResponse.json({ error: "Couldn't remove this manager." }, { status: 503 });
  }
}
