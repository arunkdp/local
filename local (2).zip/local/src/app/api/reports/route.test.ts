import { beforeEach, describe, expect, it, vi } from "vitest";
import { getCurrentUser } from "@/lib/authorization";
import { POST } from "./route";

const mocks = vi.hoisted(() => ({
  findBusiness: vi.fn(),
  findProduct: vi.fn(),
  findOffer: vi.fn(),
  findUser: vi.fn(),
  createReport: vi.fn(),
}));

vi.mock("@/lib/authorization", () => ({ getCurrentUser: vi.fn() }));
vi.mock("@/lib/prisma", () => ({
  prisma: {
    business: { findUnique: mocks.findBusiness },
    product: { findUnique: mocks.findProduct },
    offer: { findUnique: mocks.findOffer },
    user: { findUnique: mocks.findUser },
    userReport: { create: mocks.createReport },
  },
}));

const customer = {
  id: "aaf20e26-6ef0-4cda-83a1-cf037d451f79",
  name: "Customer",
  email: "customer@example.com",
  role: "CUSTOMER" as const,
};

function request(body: unknown) {
  return new Request("http://localhost/api/reports", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("report submission", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.DATABASE_URL = "postgresql://test:test@localhost/test";
    vi.mocked(getCurrentUser).mockResolvedValue(customer);
  });

  it("requires a signed-in customer", async () => {
    vi.mocked(getCurrentUser).mockResolvedValue(null);
    const response = await POST(
      request({
        targetType: "OFFER",
        targetId: "98aa8d75-0f7a-4c88-99f8-847cad221b38",
        reason: "Incorrect promotion",
      }),
    );

    expect(response.status).toBe(401);
    expect(mocks.createReport).not.toHaveBeenCalled();
  });

  it("creates a report only for an existing offer", async () => {
    mocks.findOffer.mockResolvedValue({ id: "98aa8d75-0f7a-4c88-99f8-847cad221b38" });
    mocks.createReport.mockResolvedValue({
      id: "3740c96f-ea4d-4abe-a5c2-955ec14da0aa",
      status: "OPEN",
      createdAt: new Date(),
    });

    const response = await POST(
      request({
        targetType: "OFFER",
        targetId: "98aa8d75-0f7a-4c88-99f8-847cad221b38",
        reason: "Incorrect promotion",
        details: "The listed price is misleading.",
      }),
    );

    expect(response.status).toBe(201);
    expect(mocks.createReport).toHaveBeenCalledWith({
      data: {
        authorId: customer.id,
        targetType: "OFFER",
        targetId: "98aa8d75-0f7a-4c88-99f8-847cad221b38",
        offerId: "98aa8d75-0f7a-4c88-99f8-847cad221b38",
        reason: "Incorrect promotion",
        details: "The listed price is misleading.",
      },
      select: { id: true, status: true, createdAt: true },
    });
  });

  it("rejects reports for missing items", async () => {
    mocks.findOffer.mockResolvedValue(null);
    const response = await POST(
      request({
        targetType: "OFFER",
        targetId: "98aa8d75-0f7a-4c88-99f8-847cad221b38",
        reason: "Incorrect promotion",
      }),
    );

    expect(response.status).toBe(404);
    expect(mocks.createReport).not.toHaveBeenCalled();
  });
});
