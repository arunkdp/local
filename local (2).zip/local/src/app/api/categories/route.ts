import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Categories require database configuration." }, { status: 503 });
  try {
    const [businessCategories, productCategories] = await Promise.all([
      prisma.businessCategory.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, slug: true } }),
      prisma.productCategory.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true, slug: true } }),
    ]);
    return NextResponse.json({ categories: businessCategories, productCategories }, { headers: { "Cache-Control": "public, max-age=300" } });
  } catch (error) {
    console.error("Category list failed", error);
    return NextResponse.json({ error: "Categories are unavailable." }, { status: 503 });
  }
}
