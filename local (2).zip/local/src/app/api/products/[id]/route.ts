import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser, canManageBusiness } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  description: z.string().trim().min(5).max(5000).optional(),
  priceMinor: z.number().int().nonnegative().nullable().optional(),
  promotionalMinor: z.number().int().nonnegative().nullable().optional(),
  available: z.boolean().optional(),
  imageUrl: z.string().url().refine((url) => url.startsWith("https://"), "Images must use HTTPS.").nullable().optional(),
}).refine((data) => Object.keys(data).length > 0, "Choose a product field to update.");

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to manage products." }, { status: 401 });
  const { id } = await context.params;
  if (!z.string().uuid().safeParse(id).success) return NextResponse.json({ error: "Invalid product." }, { status: 400 });
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check the product details." }, { status: 400 });

  try {
    const existing = await prisma.product.findUnique({ where: { id }, select: { businessId: true, priceMinor: true, promotionalMinor: true } });
    if (!existing) return NextResponse.json({ error: "Product not found." }, { status: 404 });
    if (!(await canManageBusiness(user.id, existing.businessId))) return NextResponse.json({ error: "You don't have access to this product." }, { status: 403 });
    const price = parsed.data.priceMinor === undefined ? existing.priceMinor : parsed.data.priceMinor;
    const promotion = parsed.data.promotionalMinor === undefined ? existing.promotionalMinor : parsed.data.promotionalMinor;
    if (promotion !== null && (price === null || promotion >= price)) {
      return NextResponse.json({ error: "Promotional price must be lower than the regular price." }, { status: 400 });
    }
    const { imageUrl, ...fields } = parsed.data;
    const product = await prisma.$transaction(async (tx) => {
      const updated = await tx.product.update({
        where: { id },
        data: {
          ...fields,
          ...(imageUrl !== undefined ? { images: { deleteMany: {}, ...(imageUrl ? { create: { url: imageUrl, alt: fields.name ?? "Product image" } } : {}) } } : {}),
        },
        select: { id: true, name: true, available: true },
      });
      await tx.adminAuditLog.create({ data: { actorId: user.id, action: "PRODUCT_UPDATED", entityType: "Product", entityId: id, metadata: { fields: Object.keys(parsed.data) } } });
      return updated;
    });
    return NextResponse.json({ product });
  } catch (error) {
    console.error("Product update failed", error);
    return NextResponse.json({ error: "Couldn't update this product." }, { status: 503 });
  }
}