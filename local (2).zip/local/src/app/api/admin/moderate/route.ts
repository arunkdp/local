import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  target: z.enum(["business", "report"]),
  id: z.string().uuid(),
  decision: z.enum(["approve", "reject", "suspend", "reinstate", "review", "resolve", "dismiss"]),
  reason: z.string().trim().max(1000).optional(),
});

export async function POST(request: Request) {
  const admin = await getCurrentUser();
  if (!admin) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (admin.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Administrator access required." }, { status: 403 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Moderation requires database configuration." }, { status: 503 });
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid moderation action." }, { status: 400 });
  const { target, id, decision, reason } = parsed.data;

  if (target === "business" && (decision === "approve" || decision === "reject" || decision === "suspend" || decision === "reinstate")) {
    const status = decision === "approve" || decision === "reinstate" ? "APPROVED" : decision === "suspend" ? "SUSPENDED" : "REJECTED";
    const action = decision === "approve" ? "APPROVE" : decision === "reject" ? "REJECT" : decision === "suspend" ? "SUSPEND" : "REINSTATE";
    try {
      const business = await prisma.business.findUnique({ where: { id }, select: { id: true, name: true, status: true, memberships: { select: { userId: true } } } });
      if (!business) return NextResponse.json({ error: "Business not found." }, { status: 404 });
      await prisma.$transaction(async (tx) => {
        await tx.business.update({ where: { id }, data: { status } });
        await tx.businessVerification.updateMany({ where: { businessId: id }, data: { status, reviewerId: admin.id, reviewedAt: new Date(), notes: reason } });
        await tx.moderationAction.create({ data: { actorId: admin.id, businessId: id, action, reason } });
        await tx.adminAuditLog.create({ data: { actorId: admin.id, action: `BUSINESS_${decision.toUpperCase()}`, entityType: "Business", entityId: id, metadata: { reason: reason ?? null } } });
        if (business.memberships.length) await tx.notification.createMany({ data: business.memberships.map(({ userId }) => ({ userId, type: "BUSINESS_DECISION", title: "Business review update", body: `${business.name}: ${status.toLowerCase()}${reason ? ` — ${reason}` : ""}`, href: "/business-dashboard" })) });
      });
      return NextResponse.json({ updated: true, status });
    } catch (error) {
      console.error("Business moderation failed", error);
      return NextResponse.json({ error: "Couldn't update this business." }, { status: 503 });
    }
  }

  if (
    target === "report" &&
    (decision === "review" || decision === "resolve" || decision === "dismiss")
  ) {
    const status =
      decision === "review"
        ? "REVIEWING"
        : decision === "resolve"
          ? "RESOLVED"
          : "DISMISSED";

    try {
      const report = await prisma.userReport.findUnique({
        where: { id },
        select: { id: true, status: true, targetType: true, targetId: true },
      });
      if (!report) return NextResponse.json({ error: "Report not found." }, { status: 404 });
      if (report.status === "RESOLVED" || report.status === "DISMISSED") {
        return NextResponse.json({ error: "This report has already been closed." }, { status: 409 });
      }

      const updated = await prisma.$transaction(async (tx) => {
        const update = await tx.userReport.updateMany({
          where: { id, status: { in: ["OPEN", "REVIEWING"] } },
          data: { status, resolvedAt: status === "REVIEWING" ? null : new Date() },
        });
        if (update.count !== 1) return false;

        await tx.adminAuditLog.create({
          data: {
            actorId: admin.id,
            action: `REPORT_${decision.toUpperCase()}`,
            entityType: "UserReport",
            entityId: id,
            metadata: {
              targetType: report.targetType,
              targetId: report.targetId,
              reason: reason ?? null,
            },
          },
        });
        return true;
      });
      if (!updated) {
        return NextResponse.json({ error: "This report has already been updated." }, { status: 409 });
      }
      return NextResponse.json({ updated: true, status });
    } catch (error) {
      console.error("Report moderation failed", error);
      return NextResponse.json({ error: "Couldn't update this report." }, { status: 503 });
    }
  }

  return NextResponse.json({ error: "That decision is not available for this content type." }, { status: 400 });
}
