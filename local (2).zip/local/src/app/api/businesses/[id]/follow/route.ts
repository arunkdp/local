import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "../../../../../../auth";
import { prisma } from "@/lib/prisma";

const routeIdSchema = z.string().min(1).max(100);

export async function PUT(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Sign in to follow local businesses." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Following businesses is not configured yet." }, { status: 503 });
  const { id } = await context.params;
  if (!routeIdSchema.safeParse(id).success) return NextResponse.json({ error: "Invalid business." }, { status: 400 });

  try {
    const business = await prisma.business.findFirst({ where: { ...(id.match(/^[0-9a-f-]{36}$/i) ? { OR: [{ id }, { slug: id }] } : { slug: id }), status: "APPROVED" }, select: { id: true } });
    if (!business) return NextResponse.json({ error: "This business isn't available to follow." }, { status: 404 });
    await prisma.businessFollow.upsert({ where: { userId_businessId: { userId: session.user.id, businessId: business.id } }, update: {}, create: { userId: session.user.id, businessId: business.id } });
    return NextResponse.json({ followed: true, businessId: business.id });
  } catch (error) {
    console.error("Business follow failed", error);
    return NextResponse.json({ error: "Couldn't follow this business right now." }, { status: 503 });
  }
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: "Sign in to manage followed businesses." }, { status: 401 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Following businesses is not configured yet." }, { status: 503 });
  const { id } = await context.params;
  if (!routeIdSchema.safeParse(id).success) return NextResponse.json({ error: "Invalid business." }, { status: 400 });

  try {
    const business = await prisma.business.findFirst({ where: { ...(id.match(/^[0-9a-f-]{36}$/i) ? { OR: [{ id }, { slug: id }] } : { slug: id }), status: "APPROVED" }, select: { id: true } });
    if (business) await prisma.businessFollow.deleteMany({ where: { userId: session.user.id, businessId: business.id } });
    return NextResponse.json({ followed: false, businessId: business?.id });
  } catch (error) {
    console.error("Business unfollow failed", error);
    return NextResponse.json({ error: "Couldn't update your followed businesses right now." }, { status: 503 });
  }
}
