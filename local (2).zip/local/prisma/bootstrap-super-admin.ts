import { loadEnvConfig } from "@next/env";
import { UserRole } from "@prisma/client";

loadEnvConfig(process.cwd());

let disconnect: (() => Promise<void>) | undefined;

async function main() {
  const { prisma } = await import("../src/lib/prisma");
  disconnect = () => prisma.$disconnect();
  const email = process.env.BOOTSTRAP_SUPER_ADMIN_EMAIL?.trim().toLowerCase();
  if (!email) {
    throw new Error("Set BOOTSTRAP_SUPER_ADMIN_EMAIL to an existing account before running this command.");
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    throw new Error("BOOTSTRAP_SUPER_ADMIN_EMAIL must be a valid email address.");
  }

  const account = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, role: true, disabledAt: true },
  });
  if (!account) {
    throw new Error("No account exists for BOOTSTRAP_SUPER_ADMIN_EMAIL. Register that account first.");
  }
  if (account.disabledAt) {
    throw new Error("The selected account is disabled. Reinstate it before bootstrapping an administrator.");
  }
  if (account.role === UserRole.SUPER_ADMIN) {
    console.log("The selected account is already a super administrator.");
    return;
  }

  await prisma.$transaction(async (transaction) => {
    await transaction.user.update({
      where: { id: account.id },
      data: { role: UserRole.SUPER_ADMIN },
    });
    await transaction.adminAuditLog.create({
      data: {
        actorId: account.id,
        action: "SUPER_ADMIN_BOOTSTRAPPED",
        entityType: "User",
        entityId: account.id,
        metadata: { email: account.email, method: "local CLI bootstrap" },
      },
    });
  });
  console.log(`Bootstrapped super administrator: ${account.email}`);
}

main()
  .catch((error: unknown) => {
    console.error("Super administrator bootstrap failed", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await disconnect?.();
  });
