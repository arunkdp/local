"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Bell, LoaderCircle, MapPin } from "lucide-react";

export function AccountSettings() {
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [pending, setPending] = useState(false);
  const [location, setLocation] = useState("");
  const [radius, setRadius] = useState(5);
  const [interests, setInterests] = useState("");
  const [emailOffers, setEmailOffers] = useState(false);
  const [inAppNotifications, setInAppNotifications] = useState(true);
  const [privacyMode, setPrivacyMode] = useState(false);

  useEffect(() => {
    fetch("/api/me/preferences", { cache: "no-store" }).then((response) => response.ok ? response.json() : null).then((data) => {
      if (!data?.profile) return;
      setLocation(data.profile.preferredLocationLabel ?? "");
      setRadius(data.profile.searchRadiusKm);
      setInterests((data.interests ?? []).join(", "));
      setEmailOffers(data.profile.emailOffers);
      setInAppNotifications(data.profile.inAppNotifications);
      setPrivacyMode(data.profile.privacyMode);
    }).catch(() => setError("Couldn't load preferences."));
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError("");
    const response = await fetch("/api/me/preferences", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ preferredLocationLabel: location || null, searchRadiusKm: radius, interests: interests.split(",").map((interest) => interest.trim()).filter(Boolean), emailOffers, inAppNotifications, privacyMode }) });
    const result = await response.json().catch(() => ({}));
    setPending(false);
    if (!response.ok) setError(result.error ?? "Couldn't save your settings.");
    else setNotice("Your preferences have been saved.");
  }

  return <form onSubmit={submit} className="space-y-5 rounded-3xl border border-ink/5 bg-white p-6"><label className="block text-sm font-medium">Preferred neighborhood<input value={location} onChange={(event) => setLocation(event.target.value)} maxLength={120} placeholder="Brooklyn, NY" className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="block text-sm font-medium">Search radius <span className="font-normal text-ink/50">{radius} km</span><input type="range" min="1" max="50" value={radius} onChange={(event) => setRadius(Number(event.target.value))} className="mt-2 block w-full accent-moss" /></label><label className="block text-sm font-medium">Interests <span className="font-normal text-ink/50">(comma-separated)</span><input value={interests} onChange={(event) => setInterests(event.target.value)} maxLength={1000} placeholder="Coffee, wellness, fashion" className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><div className="space-y-3 border-t border-ink/5 pt-4"><p className="flex items-center gap-2 text-sm font-semibold"><Bell size={15} className="text-moss" /> Notifications & privacy</p><label className="flex items-center gap-3 text-sm"><input type="checkbox" checked={inAppNotifications} onChange={(event) => setInAppNotifications(event.target.checked)} className="accent-moss" /> In-app updates</label><label className="flex items-center gap-3 text-sm"><input type="checkbox" checked={emailOffers} onChange={(event) => setEmailOffers(event.target.checked)} className="accent-moss" /> Email me about new local offers <span className="text-xs text-ink/40">(email delivery not configured)</span></label><label className="flex items-center gap-3 text-sm"><input type="checkbox" checked={privacyMode} onChange={(event) => setPrivacyMode(event.target.checked)} className="accent-moss" /> Limit personalization using my activity</label></div>{error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}{notice && <p role="status" className="rounded-xl bg-moss/10 p-3 text-sm text-moss">{notice}</p>}<button disabled={pending} className="inline-flex h-11 items-center gap-2 rounded-full bg-moss px-5 text-sm font-semibold text-white disabled:opacity-60">{pending ? <LoaderCircle size={15} className="animate-spin" /> : <MapPin size={15} />}Save preferences</button></form>;
}
