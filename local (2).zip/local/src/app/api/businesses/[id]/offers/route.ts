import { NextResponse } from "next/server";
import { OfferStatus } from "@prisma/client";
import { z } from "zod";
import { canManageBusiness, getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";
import { offerInputSchema } from "@/lib/validation";

const slugify = (value: string) => value.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 80);
const routeIdSchema = z.string().uuid();

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  const { id } = await context.params;
  if (!user || !routeIdSchema.safeParse(id).success || !(await canManageBusiness(user.id, id))) return NextResponse.json({ error: "You don't have access to these offers." }, { status: 403 });
  try {
    const offers = await prisma.offer.findMany({ where: { businessId: id }, orderBy: { createdAt: "desc" }, take: 100 });
    return NextResponse.json({ offers });
  } catch (error) {
    console.error("Business offer list failed", error);
    return NextResponse.json({ error: "Offers are unavailable." }, { status: 503 });
  }
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to manage offers." }, { status: 401 });
  const { id } = await context.params;
  if (!routeIdSchema.safeParse(id).success || !(await canManageBusiness(user.id, id))) return NextResponse.json({ error: "You don't have access to this business." }, { status: 403 });
  const body = await request.json().catch(() => null);
  const parsed = offerInputSchema.safeParse(body && typeof body === "object" ? { ...body, businessId: id } : body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check the offer details." }, { status: 400 });
  if (parsed.data.imageUrl && !parsed.data.imageUrl.startsWith(`/uploads/offers/${id}-`)) return NextResponse.json({ error: "This image does not belong to this business." }, { status: 400 });

  try {
    const [business, product] = await Promise.all([
      prisma.business.findUnique({ where: { id }, select: { status: true } }),
      parsed.data.productId ? prisma.product.findFirst({ where: { id: parsed.data.productId, businessId: id }, select: { id: true } }) : Promise.resolve(null),
    ]);
    if (!business) return NextResponse.json({ error: "Business not found." }, { status: 404 });
    if (parsed.data.productId && !product) return NextResponse.json({ error: "Choose a product owned by this business." }, { status: 400 });

    const status = business.status === "APPROVED" ? OfferStatus.PUBLISHED : OfferStatus.DRAFT;
    const publishedAt = status === OfferStatus.PUBLISHED ? new Date() : null;
    const offer = await prisma.offer.create({
      data: {
        businessId: id,
        productId: parsed.data.productId,
        title: parsed.data.title,
        slug: `${slugify(parsed.data.title) || "offer"}-${crypto.randomUUID().slice(0, 8)}`,
        description: parsed.data.description,
        imageUrl: parsed.data.imageUrl,
        type: parsed.data.type,
        status,
        discountPercent: parsed.data.discountPercent,
        discountMinor: parsed.data.discountMinor,
        originalMinor: parsed.data.originalMinor,
        promotionalMinor: parsed.data.promotionalMinor,
        startsAt: parsed.data.startsAt,
        endsAt: parsed.data.endsAt,
        terms: parsed.data.terms,
        publishedAt,
      },
      select: { id: true, slug: true, title: true, status: true },
    });
    return NextResponse.json({ offer }, { status: 201 });
  } catch (error) {
    console.error("Offer creation failed", error);
    return NextResponse.json({ error: "Couldn't create this offer." }, { status: 503 });
  }
}
