import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (user.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Administrator access required." }, { status: 403 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Admin data requires database configuration." }, { status: 503 });
  try {
    const [businesses, reports, stats, audit] = await Promise.all([
      prisma.business.findMany({ where: { status: "PENDING" }, include: { category: true, locations: { where: { isPrimary: true }, take: 1 }, memberships: { include: { user: { select: { name: true, email: true } } } } }, orderBy: { createdAt: "asc" }, take: 50 }),
      prisma.userReport.findMany({
        where: { status: { in: ["OPEN", "REVIEWING"] } },
        orderBy: { createdAt: "asc" },
        take: 50,
        include: {
          author: { select: { name: true, email: true } },
          offer: { select: { title: true } },
        },
      }),
      Promise.all([prisma.user.count(), prisma.business.count(), prisma.business.count({ where: { status: "PENDING" } })]),
      prisma.adminAuditLog.findMany({ include: { actor: { select: { name: true, email: true } } }, orderBy: { createdAt: "desc" }, take: 30 }),
    ]);
    return NextResponse.json({ businesses, reports, stats: { users: stats[0], businesses: stats[1], pendingBusinesses: stats[2] }, audit }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    console.error("Admin queue query failed", error);
    return NextResponse.json({ error: "Admin data is unavailable." }, { status: 503 });
  }
}
