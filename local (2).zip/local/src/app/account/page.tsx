import { ArrowLeft, Bookmark, Compass, Heart, MapPin, Settings } from "lucide-react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "../../../auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/sign-in");

  if (!process.env.DATABASE_URL) {
    return (
      <main className="grid min-h-screen place-items-center bg-paper px-5 text-center">
        <div>
          <h1 className="font-display text-2xl font-semibold">
            Account storage isn’t configured yet.
          </h1>
          <p className="mt-2 text-sm text-ink/55">
            Set a PostgreSQL DATABASE_URL and run the Prisma migration to use your account library.
          </p>
          <Link href="/" className="mt-5 inline-block text-sm font-semibold text-moss">
            Back to discovery
          </Link>
        </div>
      </main>
    );
  }

  const [saved, follows] = await Promise.all([
    prisma.savedOffer.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: "desc" },
      include: { offer: { include: { business: true } } },
    }),
    prisma.businessFollow.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: "desc" },
      include: {
        business: {
          select: {
            id: true,
            name: true,
            slug: true,
            category: { select: { name: true } },
            locations: { where: { isPrimary: true }, take: 1, select: { city: true } },
          },
        },
      },
    }),
  ]);

  return (
    <main className="min-h-screen bg-paper px-5 py-10 text-ink sm:px-8">
      <div className="mx-auto max-w-4xl">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm text-ink/55 hover:text-moss"
        >
          <ArrowLeft size={16} /> Back to discovery
        </Link>
        <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-moss">
              <Compass size={17} /> YOUR LOCAL LOOP
            </div>
            <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight">
              Hi, {session.user.name?.split(" ")[0] ?? "neighbor"}.
            </h1>
            <p className="mt-1 text-sm text-ink/55">
              Your saved offers and favorite neighborhood shops.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href="/account/settings"
              className="inline-flex items-center gap-2 rounded-full border border-ink/10 bg-white px-4 py-2.5 text-sm font-semibold hover:border-moss/30"
            >
              <Settings size={15} /> Preferences
            </Link>
            <form
              action={async () => {
                "use server";
                const { signOut } = await import("../../../auth");
                await signOut({ redirectTo: "/" });
              }}
            >
              <button className="rounded-full border border-ink/10 bg-white px-4 py-2.5 text-sm font-semibold hover:border-moss/30">
                Sign out
              </button>
            </form>
          </div>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <section className="rounded-3xl border border-ink/5 bg-white p-5 sm:p-6">
            <div className="flex items-center gap-2">
              <Bookmark size={17} className="text-moss" />
              <h2 className="font-display text-xl font-semibold">Saved offers</h2>
              <span className="ml-auto rounded-full bg-paper px-2.5 py-1 text-xs font-semibold text-ink/55">
                {saved.length}
              </span>
            </div>
            {saved.length ? (
              <ul className="mt-4 divide-y divide-ink/5">
                {saved.map(({ offer }) => (
                  <li key={offer.id} className="py-3">
                    <Link href="/#offers" className="block font-semibold hover:text-moss">
                      {offer.title}
                    </Link>
                    <p className="mt-1 text-xs text-ink/50">
                      {offer.business.name} ·{" "}
                      {offer.status === "PUBLISHED" && offer.endsAt > new Date()
                        ? "Active offer"
                        : "No longer active"}
                    </p>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="mt-5 rounded-2xl bg-paper p-5 text-center">
                <p className="text-sm text-ink/55">
                  Nothing saved yet. Keep an eye out for a good local find.
                </p>
                <Link
                  href="/#offers"
                  className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-moss"
                >
                  Explore offers <Bookmark size={14} />
                </Link>
              </div>
            )}
          </section>

          <section className="rounded-3xl border border-ink/5 bg-white p-5 sm:p-6">
            <div className="flex items-center gap-2">
              <Heart size={17} className="text-moss" />
              <h2 className="font-display text-xl font-semibold">Shops you follow</h2>
              <span className="ml-auto rounded-full bg-paper px-2.5 py-1 text-xs font-semibold text-ink/55">
                {follows.length}
              </span>
            </div>
            {follows.length ? (
              <ul className="mt-4 divide-y divide-ink/5">
                {follows.map(({ business }) => (
                  <li
                    key={business.id}
                    className="flex items-start justify-between gap-3 py-3"
                  >
                    <div>
                      <p className="font-semibold">{business.name}</p>
                      <p className="mt-1 flex items-center gap-1 text-xs text-ink/50">
                        <MapPin size={12} />
                        {business.category.name}
                        {business.locations[0]?.city
                          ? ` · ${business.locations[0].city}`
                          : ""}
                      </p>
                    </div>
                    <Link href="/#shops" className="text-xs font-semibold text-moss hover:underline">
                      Discover
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="mt-5 rounded-2xl bg-paper p-5 text-center">
                <p className="text-sm text-ink/55">
                  Follow a neighborhood shop to keep up with its latest offers.
                </p>
                <Link
                  href="/#shops"
                  className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-moss"
                >
                  Meet local shops <Heart size={14} />
                </Link>
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}
