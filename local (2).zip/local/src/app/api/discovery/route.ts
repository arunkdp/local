import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

const radiusKm = 10;

type Coordinates = { latitude: number; longitude: number };

function distanceKm(from: Coordinates, to: Coordinates) {
  const radians = Math.PI / 180;
  const dLat = (to.latitude - from.latitude) * radians;
  const dLon = (to.longitude - from.longitude) * radians;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(from.latitude * radians) * Math.cos(to.latitude * radians) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export async function GET(request: Request) {
  if (!process.env.DATABASE_URL) {
    return NextResponse.json({ error: "Database-backed discovery is not configured." }, { status: 503 });
  }

  const params = new URL(request.url).searchParams;
  const city = params.get("city")?.trim() ?? "";
  const latitudeText = params.get("latitude");
  const longitudeText = params.get("longitude");
  const hasCoordinates = latitudeText !== null || longitudeText !== null;
  const latitude = latitudeText === null ? NaN : Number(latitudeText);
  const longitude = longitudeText === null ? NaN : Number(longitudeText);
  if (city.length > 100 || (hasCoordinates && (!Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180))) {
    return NextResponse.json({ error: "Choose a valid city or location." }, { status: 400 });
  }

  const coordinates = hasCoordinates ? { latitude, longitude } : null;
  const latitudeDelta = radiusKm / 111;
  const longitudeDelta = coordinates ? radiusKm / (111 * Math.max(0.2, Math.cos(latitude * Math.PI / 180))) : 0;
  const businessWhere: Prisma.BusinessWhereInput = {
    status: "APPROVED",
    ...(coordinates ? { locations: { some: {
      latitude: { gte: latitude - latitudeDelta, lte: latitude + latitudeDelta },
      longitude: { gte: longitude - longitudeDelta, lte: longitude + longitudeDelta },
    } } } : city ? { locations: { some: { city: { contains: city, mode: "insensitive" } } } } : {}),
  };
  const now = new Date();

  try {
    const [records, businesses] = await Promise.all([
      prisma.offer.findMany({
        where: { status: "PUBLISHED", startsAt: { lte: now }, endsAt: { gt: now }, business: businessWhere },
        include: { product: { include: { images: { orderBy: { position: "asc" }, take: 1 } } }, business: { include: { category: true, locations: { where: { isPrimary: true }, take: 1 } } } },
        orderBy: [{ sponsored: "desc" }, { createdAt: "desc" }],
        take: 100,
      }),
      prisma.business.findMany({
        where: businessWhere,
        include: { category: true, locations: { where: { isPrimary: true }, take: 1 }, _count: { select: { followers: true } } },
        orderBy: [{ featured: "desc" }, { createdAt: "desc" }],
        take: 100,
      }),
    ]);

    const nearby = (location?: { latitude: number; longitude: number }) => !coordinates || (location ? distanceKm(coordinates, location) <= radiusKm : false);
    const distance = (location?: { latitude: number; longitude: number; city: string }) => coordinates && location ? `${distanceKm(coordinates, location).toFixed(1)} km` : location?.city ?? "Local";
    const offers = records.filter((offer) => nearby(offer.business.locations[0]));
    const shops = businesses.filter((business) => nearby(business.locations[0]));

    return NextResponse.json({
      offers: offers.slice(0, 30).map((offer) => ({
        id: offer.id,
        businessId: offer.businessId,
        business: offer.business.name,
        category: offer.business.category.name,
        title: offer.title,
        description: offer.description,
        discount: offer.discountPercent ? `${Number(offer.discountPercent)}% off` : offer.discountMinor ? `$${(offer.discountMinor / 100).toFixed(2)} off` : "Local offer",
        distance: distance(offer.business.locations[0]),
        expires: `Ends ${offer.endsAt.toLocaleDateString("en-US", { month: "short", day: "numeric" })}`,
        image: offer.imageUrl ?? offer.product?.images[0]?.url ?? null,
        color: "#e8efe8",
        sponsored: offer.sponsored,
      })),
      shops: shops.slice(0, 12).map((business) => ({
        id: business.id,
        name: business.name,
        type: business.category.name,
        distance: distance(business.locations[0]),
        image: business.coverUrl ?? business.logoUrl ?? null,
        initials: business.name.slice(0, 1).toUpperCase(),
        tint: "#e8efe8",
        followerCount: business._count.followers,
      })),
    }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    console.error("Public discovery query failed", error);
    return NextResponse.json({ error: "Database-backed discovery is unavailable." }, { status: 503 });
  }
}