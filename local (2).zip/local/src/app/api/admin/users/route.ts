import { NextResponse } from "next/server";
import { z } from "zod";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const admin = await getCurrentUser();
  if (!admin) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (admin.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Administrator access required." }, { status: 403 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "User management requires database configuration." }, { status: 503 });
  try {
    const users = await prisma.user.findMany({ orderBy: { createdAt: "desc" }, take: 100, select: { id: true, name: true, email: true, role: true, disabledAt: true, createdAt: true } });
    return NextResponse.json({ users }, { headers: { "Cache-Control": "private, no-store" } });
  } catch (error) {
    console.error("Admin user list failed", error);
    return NextResponse.json({ error: "User list is unavailable." }, { status: 503 });
  }
}

export async function PATCH(request: Request) {
  const admin = await getCurrentUser();
  if (!admin) return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  if (admin.role !== "SUPER_ADMIN") return NextResponse.json({ error: "Administrator access required." }, { status: 403 });
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "User management requires database configuration." }, { status: 503 });
  const parsed = z.object({
    id: z.string().uuid(),
    disabled: z.boolean().optional(),
    role: z.enum(["CUSTOMER", "ADMIN", "SUPER_ADMIN"]).optional(),
  }).refine((data) => data.disabled !== undefined || data.role !== undefined).safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid user action." }, { status: 400 });
  if (parsed.data.id === admin.id) return NextResponse.json({ error: "You can't disable your own administrator account." }, { status: 409 });
  try {
    const target = await prisma.user.findUnique({ where: { id: parsed.data.id }, select: { id: true, role: true } });
    if (!target) return NextResponse.json({ error: "User not found." }, { status: 404 });
    if (target.role === "SUPER_ADMIN") return NextResponse.json({ error: "Super-admin accounts can't be changed here." }, { status: 403 });
    const data = {
      ...(parsed.data.disabled !== undefined
        ? { disabledAt: parsed.data.disabled ? new Date() : null }
        : {}),
      ...(parsed.data.role !== undefined ? { role: parsed.data.role } : {}),
    };
    const action = parsed.data.role !== undefined
      ? `USER_ROLE_CHANGED_TO_${parsed.data.role}`
      : parsed.data.disabled
        ? "USER_SUSPENDED"
        : "USER_REINSTATED";
    await prisma.$transaction([
      prisma.user.update({ where: { id: target.id }, data }),
      prisma.adminAuditLog.create({
        data: {
          actorId: admin.id,
          action,
          entityType: "User",
          entityId: target.id,
          metadata: {
            previousRole: target.role,
            role: parsed.data.role ?? target.role,
            ...(parsed.data.disabled !== undefined ? { disabled: parsed.data.disabled } : {}),
          },
        },
      }),
    ]);
    return NextResponse.json({ updated: true });
  } catch (error) {
    console.error("Admin user update failed", error);
    return NextResponse.json({ error: "Couldn't update this account." }, { status: 503 });
  }
}
