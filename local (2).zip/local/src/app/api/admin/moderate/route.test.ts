import { beforeEach, describe, expect, it, vi } from "vitest";
import { getCurrentUser } from "@/lib/authorization";
import { POST } from "./route";

const mocks = vi.hoisted(() => ({
  findReport: vi.fn(),
  updateReport: vi.fn(),
  createAudit: vi.fn(),
  transaction: vi.fn(),
}));

vi.mock("@/lib/authorization", () => ({ getCurrentUser: vi.fn() }));
vi.mock("@/lib/prisma", () => ({
  prisma: {
    userReport: { findUnique: mocks.findReport },
    $transaction: mocks.transaction,
  },
}));

const admin = {
  id: "fc10e39d-8753-4b2f-9549-918d36bd27c4",
  name: "Admin",
  email: "admin@example.com",
  role: "SUPER_ADMIN" as const,
};

function request(body: unknown) {
  return new Request("http://localhost/api/admin/moderate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("admin report moderation", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.DATABASE_URL = "postgresql://test:test@localhost/test";
    vi.mocked(getCurrentUser).mockResolvedValue(admin);
    mocks.transaction.mockImplementation(
      async (operation: (tx: unknown) => Promise<unknown>) =>
        operation({
          userReport: { updateMany: mocks.updateReport },
          adminAuditLog: { create: mocks.createAudit },
        }),
    );
  });

  it("requires an administrator", async () => {
    vi.mocked(getCurrentUser).mockResolvedValue(null);
    const response = await POST(
      request({
        target: "report",
        id: "fc10e39d-8753-4b2f-9549-918d36bd27c4",
        decision: "resolve",
      }),
    );

    expect(response.status).toBe(401);
    expect(mocks.findReport).not.toHaveBeenCalled();
  });

  it("records report resolution and its audit event atomically", async () => {
    mocks.findReport.mockResolvedValue({
      id: "4b97695f-3a0d-40cb-ac14-25d40774fbbb",
      status: "REVIEWING",
      targetType: "OFFER",
      targetId: "fc10e39d-8753-4b2f-9549-918d36bd27c4",
    });
    mocks.updateReport.mockResolvedValue({ count: 1 });
    mocks.createAudit.mockResolvedValue({});

    const response = await POST(
      request({
        target: "report",
        id: "4b97695f-3a0d-40cb-ac14-25d40774fbbb",
        decision: "resolve",
        reason: "Reviewed and actioned",
      }),
    );

    expect(response.status).toBe(200);
    expect(mocks.updateReport).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: "4b97695f-3a0d-40cb-ac14-25d40774fbbb", status: { in: ["OPEN", "REVIEWING"] } },
        data: expect.objectContaining({ status: "RESOLVED", resolvedAt: expect.any(Date) }),
      }),
    );
    expect(mocks.createAudit).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          actorId: admin.id,
          action: "REPORT_RESOLVE",
          entityType: "UserReport",
        }),
      }),
    );
  });

  it("does not overwrite a report already closed by another administrator", async () => {
    mocks.findReport.mockResolvedValue({
      id: "4b97695f-3a0d-40cb-ac14-25d40774fbbb",
      status: "OPEN",
      targetType: "OFFER",
      targetId: "fc10e39d-8753-4b2f-9549-918d36bd27c4",
    });
    mocks.updateReport.mockResolvedValue({ count: 0 });

    const response = await POST(
      request({
        target: "report",
        id: "4b97695f-3a0d-40cb-ac14-25d40774fbbb",
        decision: "dismiss",
      }),
    );

    expect(response.status).toBe(409);
    expect(mocks.createAudit).not.toHaveBeenCalled();
  });
});
