﻿import { notFound } from "next/navigation";
import Link from "next/link";
import { BusinessProfile } from "@/components/business-profile";

export const dynamic = "force-dynamic";

export default async function PublicBusinessPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!/^[a-z0-9-]{2,100}$/i.test(slug)) notFound();
  return <main className="min-h-screen bg-paper px-5 py-8 text-ink sm:px-8"><div className="mx-auto mb-7 max-w-5xl"><Link href="/" className="text-sm font-semibold text-moss">LocalLink</Link></div><BusinessProfile slug={slug} /></main>;
}

