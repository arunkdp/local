"use client";

import Image from "next/image";
import Link from "next/link";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { ArrowRight, ArrowUpRight, Bookmark, Check, ChevronDown, Clock3, Compass, MapPin, Search, SlidersHorizontal, Sparkles, Store, X } from "lucide-react";
import type { Offer, Shop } from "@/lib/discovery-types";

export function Marketplace() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [location, setLocation] = useState("All locations");
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("Everything");
  const [offerList, setOfferList] = useState<Offer[]>([]);
  const [shopList, setShopList] = useState<Shop[]>([]);
  const [saved, setSaved] = useState<string[]>([]);
  const [followed, setFollowed] = useState<string[]>([]);
  const [notice, setNotice] = useState("");
  const [discoveryError, setDiscoveryError] = useState(false);
  const [loadingDiscovery, setLoadingDiscovery] = useState(true);
  const [showLocation, setShowLocation] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    const coordinates = location.match(/^(-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)$/);
    const params = new URLSearchParams(coordinates ? { latitude: coordinates[1], longitude: coordinates[2] } : { city: location === "All locations" ? "" : location.split(",")[0].trim() });
    const controller = new AbortController();
    setLoadingDiscovery(true);
    setActiveCategory("Everything");
    fetch(`/api/discovery?${params}`, { signal: controller.signal })
      .then(async (response) => response.ok ? response.json() : null)
      .then((discovery: { offers: Offer[]; shops: Shop[] } | null) => {
        if (!discovery) { setDiscoveryError(true); setOfferList([]); setShopList([]); return; }
        setDiscoveryError(false);
        setOfferList(discovery.offers);
        setShopList(discovery.shops);
      })
      .catch(() => { if (!controller.signal.aborted) { setDiscoveryError(true); setOfferList([]); setShopList([]); } })
      .finally(() => { if (!controller.signal.aborted) setLoadingDiscovery(false); });
    return () => controller.abort();
  }, [location]);

  useEffect(() => {
    if (status !== "authenticated") return;
    fetch("/api/me/library")
      .then((response) => response.ok ? response.json() : null)
      .then((library) => {
        if (!library) return;
        setSaved([...library.savedOfferIds, ...library.savedOfferSlugs]);
        setFollowed([...library.followedBusinessIds, ...library.followedBusinessSlugs]);
      })
      .catch(() => setNotice("Your saved places couldn't be loaded. Please try again."));
  }, [status]);

  const filteredOffers = useMemo(() => offerList.filter((offer) => {
    const matchesQuery = `${offer.business} ${offer.title} ${offer.category}`.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = activeCategory === "Everything" || offer.category.toLowerCase().includes(activeCategory.toLowerCase());
    return matchesQuery && matchesCategory;
  }), [offerList, query, activeCategory]);

  const visibleCategories = useMemo(() => [...new Set(shopList.map((shop) => shop.type))].map((name) => ({ name, count: shopList.filter((shop) => shop.type === name).length, icon: "✦" })), [shopList]);

  async function toggleSave(id: string) {
    if (!session) {
      router.push("/sign-in");
      return;
    }
    const isSaved = saved.includes(id);
    const response = await fetch(`/api/offers/${encodeURIComponent(id)}/save`, { method: isSaved ? "DELETE" : "PUT" });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setNotice(result.error ?? "Couldn't update your saved offers.");
      window.setTimeout(() => setNotice(""), 3000);
      return;
    }
    setSaved((items) => isSaved ? items.filter((item) => item !== id && item !== result.offerId) : [...new Set([...items, id, result.offerId].filter(Boolean))]);
    setNotice(isSaved ? "Removed from your saved offers" : "Offer saved to your collection");
    window.setTimeout(() => setNotice(""), 2600);
  }

  async function toggleFollow(id: string, name: string) {
    if (!session) {
      router.push("/sign-in");
      return;
    }
    const isFollowed = followed.includes(id);
    const response = await fetch(`/api/businesses/${encodeURIComponent(id)}/follow`, { method: isFollowed ? "DELETE" : "PUT" });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      setNotice(result.error ?? "Couldn't update followed businesses.");
      window.setTimeout(() => setNotice(""), 3000);
      return;
    }
    setFollowed((items) => isFollowed ? items.filter((item) => item !== id && item !== result.businessId) : [...new Set([...items, id, result.businessId].filter(Boolean))]);
    setNotice(isFollowed ? `Unfollowed ${name}` : `Following ${name}`);
    window.setTimeout(() => setNotice(""), 2600);
  }

  function useMyLocation() {
    if (!navigator.geolocation) {
      setNotice("Location isn't available in this browser. Choose a neighborhood instead.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        setLocation(`${coords.latitude.toFixed(5)}, ${coords.longitude.toFixed(5)}`);
        setShowLocation(false);
        setNotice("Showing shops and offers near your location");
        window.setTimeout(() => setNotice(""), 2600);
      },
      () => {
        setNotice("Location permission wasn't granted. You can browse by neighborhood.");
        window.setTimeout(() => setNotice(""), 3200);
      },
      { timeout: 8000, maximumAge: 60000 },
    );
  }

  return (
    <main className="min-h-screen bg-paper text-ink">
      <header className="sticky top-0 z-30 border-b border-ink/5 bg-paper/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-[1440px] items-center gap-5 px-5 sm:px-8 lg:px-12">
          <a href="#home" className="flex shrink-0 items-center gap-2.5" aria-label="LocalLink home">
            <span className="grid h-9 w-9 place-items-center rounded-[13px] bg-moss text-lime"><Compass size={20} strokeWidth={2.4} /></span>
            <span className="font-display text-[21px] font-semibold tracking-tight">local<span className="text-moss">link</span></span>
          </a>
          <button onClick={() => setShowLocation(!showLocation)} className="hidden items-center gap-2 rounded-full px-3 py-2 text-left transition hover:bg-white sm:flex" aria-label="Change location">
            <MapPin size={16} className="text-moss" />
            <span className="max-w-32 truncate text-[13px] font-medium">{location}</span><ChevronDown size={14} className="text-ink/45" />
          </button>
          <div className="relative ml-auto hidden w-full max-w-[410px] md:block">
            <Search size={17} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find your next favorite thing..." className="h-11 w-full rounded-full border border-ink/5 bg-white pl-11 pr-4 text-sm outline-none transition placeholder:text-ink/35 focus:border-moss/30 focus:ring-4 focus:ring-moss/5" />
            {query && <button aria-label="Clear search" onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1 text-ink/45 hover:bg-paper"><X size={15} /></button>}
          </div>
          <nav className="ml-auto hidden items-center gap-7 text-[13px] font-medium text-ink/65 lg:flex">
            <a href="#offers" className="transition hover:text-moss">Explore</a><a href="#shops" className="transition hover:text-moss">Local shops</a><Link href="/business" className="transition hover:text-moss">For business</Link>
          </nav>
          <a href={session ? "/dashboard" : "/sign-in"} className="sm:hidden rounded-full border border-ink/10 bg-white px-3 py-2 text-xs font-semibold">{session ? "Account" : "Sign in"}</a>
          {session ? <><a href={session.user.role === "CUSTOMER" ? "/account" : "/dashboard"} className="hidden max-w-28 truncate rounded-full border border-ink/10 bg-white px-4 py-2.5 text-[13px] font-semibold transition hover:border-moss/40 sm:block">{session.user.role === "CUSTOMER" ? (session.user?.name?.split(" ")[0] ?? "My account") : "Workspace"}</a><button onClick={() => signOut({ redirectTo: "/" })} className="hidden rounded-full bg-ink px-4 py-2.5 text-[13px] font-semibold text-white transition hover:bg-moss sm:block">Sign out</button></> : <><a href="/sign-in" className="hidden rounded-full border border-ink/10 bg-white px-4 py-2.5 text-[13px] font-semibold transition hover:border-moss/40 sm:block">Sign in</a><a href="/register" className="rounded-full bg-ink px-4 py-2.5 text-[13px] font-semibold text-white transition hover:bg-moss">Join free</a></>}
          {showLocation && <div className="absolute left-4 top-[68px] z-40 w-[310px] rounded-2xl border border-ink/5 bg-white p-4 shadow-soft sm:left-[210px]"><p className="mb-3 text-sm font-semibold">Where should we explore?</p><button onClick={useMyLocation} className="flex w-full items-center gap-2 rounded-xl bg-moss/5 px-3 py-3 text-left text-sm font-medium text-moss hover:bg-moss/10"><Compass size={17} /> Use my current location <ArrowRight size={15} className="ml-auto" /></button><label className="mt-3 block text-xs text-ink/50">Or enter a city or neighborhood</label><input defaultValue={location} onKeyDown={(event) => { if (event.key === "Enter") { setLocation(event.currentTarget.value); setShowLocation(false); } }} onBlur={(event) => { if (event.target.value.trim()) setLocation(event.target.value); }} className="mt-1.5 h-10 w-full rounded-xl border border-ink/10 px-3 text-sm outline-none focus:border-moss" /></div>}
        </div>
        <div className="px-5 pb-3 sm:hidden"><button onClick={() => setShowLocation(!showLocation)} className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-moss"><MapPin size={13} />{location}<ChevronDown size={12} /></button><div className="relative"><Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/40" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search local finds..." className="h-10 w-full rounded-full border border-ink/5 bg-white pl-10 pr-4 text-sm outline-none" /></div></div>
      </header>

      <section id="home" className="mx-auto max-w-[1440px] px-5 pt-8 sm:px-8 sm:pt-11 lg:px-12">
        <div className="hero-grid relative isolate min-h-[430px] overflow-hidden rounded-[30px] bg-[#273d31] sm:min-h-[470px] lg:min-h-[490px]">
          <div className="hero-photo absolute inset-0 -z-10">{shopList.find((shop) => shop.image)?.image && <Image unoptimized src={shopList.find((shop) => shop.image)!.image!} alt="" fill sizes="100vw" className="object-cover" />}</div>
          <div className="absolute inset-0 -z-10 bg-gradient-to-r from-[#17271f]/95 via-[#1b2b22]/80 to-[#1b2b22]/10" />
          <div className="absolute -left-28 -top-40 -z-10 h-[360px] w-[360px] rounded-full border border-white/10" />
          <div className="absolute -left-12 -top-24 -z-10 h-[260px] w-[260px] rounded-full border border-white/10" />
          <div className="relative max-w-[700px] px-6 py-12 sm:px-11 sm:py-[72px] lg:px-[72px]">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3.5 py-2 text-[11px] font-semibold uppercase tracking-[.13em] text-lime backdrop-blur"><Sparkles size={13} /> Good things are closer than you think</div>
            <h1 className="max-w-[620px] font-display text-[45px] font-medium leading-[1.03] tracking-[-.045em] text-white sm:text-[60px] lg:text-[68px]">Your neighborhood,<br />a little more <span className="font-editorial italic text-lime">rewarding.</span></h1>
            <p className="mt-5 max-w-[420px] text-[15px] leading-7 text-white/75 sm:text-base">Find the little shops, lovely people, and very good deals that make your corner of the world feel like yours.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="#offers" className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-lime px-6 text-sm font-semibold text-ink transition hover:bg-white">Explore nearby <ArrowRight size={16} /></a>
              <button onClick={useMyLocation} className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-white/25 px-5 text-sm font-medium text-white transition hover:bg-white/10"><MapPin size={16} /> Find my location</button>
            </div>
            {!loadingDiscovery && <div className="mt-8 flex items-center gap-2 text-xs text-white/70"><Store size={15} className="text-lime" /><span><strong className="text-white">{shopList.length}</strong> independent shops to explore</span></div>}
          </div>
          <div className="absolute bottom-6 right-7 hidden rounded-2xl border border-white/20 bg-white/10 p-3.5 backdrop-blur sm:block"><div className="flex items-center gap-2 text-xs text-white/70"><span className="h-2 w-2 animate-pulse rounded-full bg-lime" /> Your LocalLink</div><p className="mt-1.5 text-sm font-semibold text-white">{location} </p></div>
        </div>
      </section>

      <section className="mx-auto max-w-[1440px] px-5 pt-12 sm:px-8 sm:pt-[68px] lg:px-12">
        <div className="mb-5 flex items-end justify-between"><div><p className="eyebrow">A good place to start</p><h2 className="section-title mt-1.5">What are you in the mood for?</h2></div><span className="hidden text-sm font-medium text-ink/50 sm:block">{visibleCategories.length} categories nearby</span></div>
        <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-6 sm:gap-3">
          {visibleCategories.map((category, index) => <button key={category.name} onClick={() => setActiveCategory(activeCategory === category.name ? "Everything" : category.name)} className={`group flex min-h-[107px] flex-col items-start justify-between rounded-2xl border p-3.5 text-left transition duration-200 hover:-translate-y-0.5 hover:shadow-soft sm:min-h-[126px] sm:p-4 ${activeCategory === category.name ? "border-moss bg-moss text-white" : "border-ink/5 bg-white hover:border-moss/25"}`}><span className={`grid h-9 w-9 place-items-center rounded-xl text-xl ${activeCategory === category.name ? "bg-white/15" : ["bg-[#f8ece1]", "bg-[#edf0e7]", "bg-[#f2eaf0]", "bg-[#e8efea]", "bg-[#f4eee2]", "bg-[#f1e9e4]"][index]}`}>{category.icon}</span><span><span className="block text-[12px] font-semibold sm:text-[13px]">{category.name}</span><span className={`mt-0.5 block text-[10px] sm:text-[11px] ${activeCategory === category.name ? "text-white/60" : "text-ink/45"}`}>{category.count} places</span></span></button>)}
        </div>
      </section>

      <section id="offers" className="mx-auto max-w-[1440px] px-5 pt-14 sm:px-8 sm:pt-[76px] lg:px-12">
        {discoveryError && <div role="alert" className="mb-5 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">Live offers are unavailable. Check the database connection and refresh this page.</div>}
        <div className="mb-6 flex flex-wrap items-end justify-between gap-4"><div><p className="eyebrow"><span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-[#df876a] align-middle" /> THE GOOD STUFF NEAR YOU</p><h2 className="section-title mt-1.5">Worth stepping out for.</h2><p className="mt-1.5 text-sm text-ink/50">A few lovely things around {location}.</p></div><div className="flex items-center gap-2"><button onClick={() => setShowFilters(!showFilters)} className={`flex h-10 items-center gap-2 rounded-full border px-3.5 text-xs font-semibold transition ${showFilters ? "border-moss bg-moss text-white" : "border-ink/10 bg-white hover:border-moss/30"}`}><SlidersHorizontal size={15} /> Filters</button></div></div>
        {showFilters && <div className="mb-5 flex flex-wrap items-center gap-2 rounded-2xl border border-ink/5 bg-white p-4"><span className="mr-1 text-xs font-semibold text-ink/60">Show:</span>{["Everything", ...visibleCategories.map((category) => category.name)].map((filter) => <button key={filter} onClick={() => setActiveCategory(filter)} className={`rounded-full px-3.5 py-2 text-xs font-medium transition ${activeCategory === filter ? "bg-moss text-white" : "bg-paper text-ink/60 hover:bg-moss/10"}`}>{filter}</button>)}</div>}
        {loadingDiscovery ? <div className="rounded-3xl bg-white px-5 py-14 text-center text-sm text-ink/50">Finding local offers...</div> : filteredOffers.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{filteredOffers.map((offer, index) => <article key={offer.id} className="offer-card group overflow-hidden rounded-[22px] border border-ink/5 bg-white transition duration-300 hover:-translate-y-1 hover:shadow-soft"><div className="relative h-[230px] overflow-hidden sm:h-[250px]">{offer.image ? <Image unoptimized src={offer.image} alt={`${offer.business} offer`} fill sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw" className="object-cover transition duration-700 group-hover:scale-[1.04]" priority={index === 0} /> : <div className="absolute inset-0 grid place-items-center bg-moss/10 font-display text-6xl font-semibold text-moss/30">{offer.business.slice(0, 1)}</div>}<div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-black/10" />{offer.sponsored && <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1.5 text-[10px] font-semibold tracking-wide text-ink/70 backdrop-blur">✦  SPONSORED</span>}<span className="absolute bottom-4 left-4 rounded-full bg-lime px-3 py-1.5 text-xs font-bold text-ink">{offer.discount}</span><button onClick={() => toggleSave(offer.id)} aria-label={saved.includes(offer.id) ? "Remove saved offer" : "Save offer"} className={`absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full backdrop-blur transition ${saved.includes(offer.id) ? "bg-lime text-ink" : "bg-white/90 text-ink hover:bg-white"}`}><Bookmark size={16} fill={saved.includes(offer.id) ? "currentColor" : "none"} /></button></div><div className="p-5"><div className="flex items-center justify-between"><a href={offer.businessId ? `/business/${offer.businessId}` : "#shops"} className="text-[11px] font-semibold uppercase tracking-[.11em] text-moss hover:underline">{offer.business}</a><span className="flex items-center gap-1 text-[11px] text-ink/45"><MapPin size={12} />{offer.distance}</span></div><h3 className="mt-2 font-display text-[21px] font-semibold tracking-tight">{offer.title}</h3><p className="mt-1.5 line-clamp-2 text-[13px] leading-5 text-ink/55">{offer.description}</p><div className="mt-4 flex items-center justify-between border-t border-ink/5 pt-3.5"><span className="flex items-center gap-1.5 text-[11px] text-ink/45"><Clock3 size={13} />{offer.expires}</span><a href={`/offers/${offer.id}`} className="flex items-center gap-1 text-xs font-semibold text-moss transition hover:gap-2">See offer <ArrowUpRight size={14} /></a></div></div></article>)}</div> : <div className="rounded-3xl border border-dashed border-ink/15 bg-white px-5 py-14 text-center"><span className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-moss/5 text-moss"><Search size={21} /></span><h3 className="mt-4 font-display text-xl font-semibold">No local finds just yet</h3><p className="mt-1 text-sm text-ink/50">Try another search or choose a different category.</p><button onClick={() => { setQuery(""); setActiveCategory("Everything"); }} className="mt-4 text-sm font-semibold text-moss">Clear search and filters</button></div>}
        
      </section>

      <section id="shops" className="mx-auto max-w-[1440px] px-5 pb-16 pt-16 sm:px-8 sm:pb-20 sm:pt-[90px] lg:px-12"><div className="mb-6 flex items-end justify-between"><div><p className="eyebrow">GOOD PEOPLE, GOOD PLACES</p><h2 className="section-title mt-1.5">Meet your new regulars.</h2><p className="mt-1.5 text-sm text-ink/50">Independent favorites, right around the corner.</p></div><span className="hidden text-sm font-medium text-ink/50 sm:block">{shopList.length} local shops</span></div><div className="grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">{shopList.map((shop) => <article key={shop.name} className="group overflow-hidden rounded-[20px] border border-ink/5 bg-white transition hover:-translate-y-1 hover:shadow-soft"><div className="relative h-[130px] overflow-hidden sm:h-[170px]">{shop.image ? <Image unoptimized src={shop.image} alt={shop.name} fill sizes="(max-width: 640px) 50vw, 25vw" className="object-cover transition duration-500 group-hover:scale-105" /> : <div className="absolute inset-0 grid place-items-center bg-moss/10 font-display text-5xl font-semibold text-moss/30">{shop.initials}</div>}<span className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-white/90 px-2 py-1 text-[10px] font-semibold"><Sparkles size={11} className="text-[#d69d4e]" />{shop.followerCount} followers</span></div><div className="p-3.5 sm:p-4"><h3 className="truncate text-sm font-semibold"><a href={`/business/${shop.id}`} className="hover:text-moss">{shop.name}</a></h3><p className="mt-1 truncate text-[11px] text-ink/50">{shop.type}</p><div className="mt-3 flex items-center justify-between"><span className="flex items-center gap-1 text-[10px] text-ink/45"><MapPin size={11} />{shop.distance}</span><button onClick={() => toggleFollow(shop.id, shop.name)} aria-pressed={followed.includes(shop.id)} className={`rounded-full px-2.5 py-1.5 text-[10px] font-semibold transition ${followed.includes(shop.id) ? "bg-moss text-white" : "bg-moss/5 text-moss hover:bg-moss hover:text-white"}`}>{followed.includes(shop.id) ? "Following" : "+ Follow"}</button></div></div></article>)}</div></section>

      <section id="how-it-works" className="bg-[#e9eee5] px-5 py-12 sm:px-8 sm:py-16"><div className="mx-auto flex max-w-[1248px] flex-col items-start justify-between gap-7 sm:flex-row sm:items-center"><div className="max-w-[560px]"><p className="eyebrow">MADE FOR THE NEIGHBORHOOD</p><h2 className="section-title mt-2">Small shops make a big place.</h2><p className="mt-3 text-sm leading-6 text-ink/60">Bring your corner of the world a little closer. Meet the people behind the counter and find customers who love shopping local.</p></div><Link href="/business" className="flex shrink-0 items-center gap-2 rounded-full bg-moss px-5 py-3 text-sm font-semibold text-white transition hover:bg-ink"><Store size={16} /> List your shop <ArrowRight size={15} /></Link></div></section>

      <footer className="bg-ink px-5 py-9 text-white sm:px-8"><div className="mx-auto flex max-w-[1440px] flex-col justify-between gap-6 sm:flex-row sm:items-center lg:px-4"><a href="#home" className="flex items-center gap-2.5"><span className="grid h-8 w-8 place-items-center rounded-[11px] bg-lime text-moss"><Compass size={18} /></span><span className="font-display text-lg font-semibold">local<span className="text-lime">link</span></span></a><p className="text-xs text-white/45">Good things grow close to home. © 2026 LocalLink</p><div className="flex gap-5 text-xs text-white/65"><Link href="/business" className="hover:text-lime">For local business</Link></div></div></footer>
      {notice && <div role="status" className="fixed bottom-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 rounded-full bg-ink px-4 py-3 text-sm font-medium text-white shadow-xl"><Check size={16} className="text-lime" />{notice}<button onClick={() => setNotice("")} aria-label="Dismiss message" className="ml-1 rounded-full p-0.5 hover:bg-white/10"><X size={14} /></button></div>}
    </main>
  );
}



