import { BusinessStatus } from "@prisma/client";
import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/authorization";
import { businessRegistrationSchema } from "@/lib/validation";

const schema = businessRegistrationSchema.extend({ categoryId: z.string().min(1).max(100) });
const slugify = (value: string) => value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "").slice(0, 80);

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to submit a business." }, { status: 401 });
  if (user.role !== "ADMIN" && user.role !== "SUPER_ADMIN") {
    return NextResponse.json({ error: "Administrator access is required to register a business." }, { status: 403 });
  }
  if (!process.env.DATABASE_URL) return NextResponse.json({ error: "Business registration requires database configuration." }, { status: 503 });
  if (user.role === "ADMIN") {
    const memberships = await prisma.businessMembership.findMany({ where: { userId: user.id }, select: { role: true } });
    if (memberships.length && memberships.every((member) => member.role === "MANAGER")) return NextResponse.json({ error: "Managers can update assigned shops but cannot register a separate shop." }, { status: 403 });
  }
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Check the business details." }, { status: 400 });

  try {
    const category = await prisma.businessCategory.findUnique({ where: { id: parsed.data.categoryId }, select: { id: true } });
    if (!category) return NextResponse.json({ error: "Choose a valid business category." }, { status: 400 });
    const baseSlug = slugify(parsed.data.name) || "local-business";
    const slug = `${baseSlug}-${crypto.randomUUID().slice(0, 8)}`;
    const business = await prisma.$transaction(async (tx) => {
      const created = await tx.business.create({
        data: {
          name: parsed.data.name,
          slug,
          description: parsed.data.description,
          categoryId: category.id,
          email: parsed.data.email || null,
          phone: parsed.data.phone || null,
          status: BusinessStatus.PENDING,
          locations: { create: { address: parsed.data.address, city: parsed.data.city, postalCode: parsed.data.postalCode || null, latitude: parsed.data.latitude, longitude: parsed.data.longitude, isPrimary: true } },
          memberships: { create: { userId: user.id, role: "OWNER" } },
          verification: { create: { status: BusinessStatus.PENDING } },
        },
        select: { id: true, slug: true, name: true },
      });
      return created;
    });
    return NextResponse.json({ business }, { status: 201 });
  } catch (error) {
    console.error("Business registration failed", error);
    return NextResponse.json({ error: "We couldn't submit the business for review." }, { status: 503 });
  }
}
