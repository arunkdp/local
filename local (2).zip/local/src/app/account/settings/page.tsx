﻿import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { getCurrentUser } from "@/lib/authorization";
import { AccountSettings } from "@/components/account-settings";

export default async function AccountSettingsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/sign-in");
  return <main className="min-h-screen bg-paper px-5 py-8 text-ink sm:px-8"><div className="mx-auto max-w-2xl"><Link href="/account" className="inline-flex items-center gap-2 text-sm text-ink/55"><ArrowLeft size={15} /> My account</Link><h1 className="mt-7 font-display text-3xl font-semibold">Preferences</h1><p className="mb-6 mt-2 text-sm text-ink/55">Choose your neighborhood and what you’d like LocalLink to remember.</p><AccountSettings /></div></main>;
}

