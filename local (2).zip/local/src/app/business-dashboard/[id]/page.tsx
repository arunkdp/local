import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { ArrowLeft, ArrowUpRight, Heart, Bookmark, CalendarDays, Users } from "lucide-react";
import { getCurrentUser, canManageBusiness } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";
import { BusinessWorkspace } from "@/components/business-workspace";
import { BusinessSettings } from "@/components/business-settings";
import { ShopStaff } from "@/components/shop-staff";

export const dynamic = "force-dynamic";

export default async function BusinessDashboardPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/sign-in");
  const { id } = await params;
  if (!process.env.DATABASE_URL || !(await canManageBusiness(user.id, id))) notFound();

  const [business, categories, followerCount, products, offers] = await Promise.all([
    prisma.business.findUnique({ where: { id }, select: {
      id: true, slug: true, name: true, description: true, categoryId: true, coverUrl: true,
      email: true, phone: true, website: true, status: true,
      locations: { where: { isPrimary: true }, take: 1, select: { address: true, city: true, postalCode: true, latitude: true, longitude: true } },
    } }),
    prisma.businessCategory.findMany({ select: { id: true, name: true }, orderBy: { name: "asc" } }),
    prisma.businessFollow.count({ where: { businessId: id } }),
    prisma.product.findMany({ where: { businessId: id }, select: { id: true, name: true, available: true, _count: { select: { favorites: true } } }, orderBy: { createdAt: "desc" }, take: 100 }),
    prisma.offer.findMany({ where: { businessId: id }, select: { id: true, title: true, status: true, startsAt: true, endsAt: true, productId: true, _count: { select: { savedBy: true } } }, orderBy: { createdAt: "desc" }, take: 100 }),
  ]);
  if (!business) notFound();

  const totalSaves = offers.reduce((total, offer) => total + offer._count.savedBy, 0);
  const totalLikes = products.reduce((total, product) => total + product._count.favorites, 0);
  const now = new Date();
  const activeOffers = offers.filter((offer) => offer.status === "PUBLISHED" && offer.startsAt <= now && offer.endsAt > now).length;
  const topProducts = [...products].sort((a, b) => b._count.favorites - a._count.favorites || a.name.localeCompare(b.name)).slice(0, 5);
  const rankedOffers = [...offers].sort((a, b) => b._count.savedBy - a._count.savedBy || a.title.localeCompare(b.title)).slice(0, 6);

  return <main className="min-h-screen bg-paper px-5 py-8 text-ink sm:px-8"><div className="mx-auto max-w-6xl">
    <Link href="/business-dashboard" className="inline-flex items-center gap-2 text-sm text-ink/55 hover:text-moss"><ArrowLeft size={15} /> Your businesses</Link>
    <header className="mb-7 mt-7 flex flex-wrap items-end justify-between gap-4"><div><p className="eyebrow">YOUR SHOP AT A GLANCE</p><h1 className="mt-2 font-display text-3xl font-semibold">{business.name}</h1><p className="mt-1 text-sm text-ink/50">See how customers follow your shop and engage with your products and offers.</p></div>{business.status === "APPROVED" && <Link href={`/business/${business.slug}`} className="inline-flex items-center gap-1.5 text-sm font-semibold text-moss">View public page <ArrowUpRight size={15} /></Link>}</header>

    <section aria-label="Shop overview" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {[
        { label: "Shop followers", value: followerCount.toLocaleString(), icon: Users, detail: "People following your shop" },
        { label: "Saved offers", value: totalSaves.toLocaleString(), icon: Bookmark, detail: "Current customer saves" },
        { label: "Product likes", value: totalLikes.toLocaleString(), icon: Heart, detail: "Likes across your products" },
        { label: "Active offers", value: activeOffers.toLocaleString(), icon: CalendarDays, detail: "Published and currently running" },
      ].map(({ label, value, icon: Icon, detail }) => <div key={label} className="rounded-3xl border border-ink/5 bg-white p-4 shadow-sm sm:p-5"><span className="grid h-10 w-10 place-items-center rounded-2xl bg-moss/10 text-moss"><Icon size={19} /></span><p className="mt-4 text-[11px] font-semibold uppercase tracking-wide text-ink/45 sm:mt-5">{label}</p><p className="mt-1 font-display text-2xl sm:text-3xl font-semibold tracking-tight">{value}</p><p className="mt-1 text-xs text-ink/45">{detail}</p></div>)}
    </section>

    <div className="my-6 grid gap-6 lg:grid-cols-2">
      <section className="rounded-3xl border border-ink/5 bg-white p-5 shadow-sm sm:p-7"><div className="flex items-center justify-between"><div><p className="eyebrow">CUSTOMER INTEREST</p><h2 className="mt-1 font-display text-xl font-semibold">Most liked products</h2></div><Heart size={19} className="text-moss" /></div><p className="mt-2 text-xs text-ink/45">Ranked by the number of customers who liked each product.</p><div className="mt-5 space-y-2">{topProducts.map((product, index) => <div key={product.id} className="flex items-center justify-between gap-3 rounded-2xl bg-paper p-3"><div className="flex min-w-0 items-center gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-moss/10 text-xs font-bold text-moss">{String(index + 1).padStart(2, "0")}</span><div className="min-w-0"><p className="truncate text-sm font-semibold">{product.name}</p><p className="text-xs text-ink/45">{product.available ? "Available" : "Unavailable"}</p></div></div><span className="shrink-0 text-sm font-semibold text-moss">{product._count.favorites} {product._count.favorites === 1 ? "like" : "likes"}</span></div>)}{!topProducts.length && <p className="text-sm text-ink/50">Add products to start tracking interest.</p>}</div></section>
      <section className="rounded-3xl border border-ink/5 bg-white p-5 shadow-sm sm:p-7"><div className="flex items-center justify-between"><div><p className="eyebrow">OFFER INTEREST</p><h2 className="mt-1 font-display text-xl font-semibold">Most saved offers</h2></div><Bookmark size={19} className="text-moss" /></div><p className="mt-2 text-xs text-ink/45">See which offers customers have saved for later.</p><div className="mt-5 space-y-2">{rankedOffers.map((offer) => <div key={offer.id} className="flex items-center justify-between gap-3 rounded-2xl bg-paper p-3"><div className="min-w-0"><p className="truncate text-sm font-semibold">{offer.title}</p><p className="text-xs text-ink/45">{offer.status.toLowerCase()} · {offer.startsAt.toLocaleDateString()}–{offer.endsAt.toLocaleDateString()}</p></div><span className="shrink-0 text-sm font-semibold text-moss">{offer._count.savedBy} {offer._count.savedBy === 1 ? "save" : "saves"}</span></div>)}{!rankedOffers.length && <p className="text-sm text-ink/50">Create offers to see customer interest here.</p>}</div></section>
    </div>

    <div className="mb-6"><ShopStaff businessId={id} />
    </div>
    <BusinessSettings business={{ ...business, location: business.locations[0] ?? null }} categories={categories} />
    <BusinessWorkspace businessId={business.id} status={business.status} />
  </div></main>;
}
