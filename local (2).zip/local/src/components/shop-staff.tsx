﻿"use client";

import Link from "next/link";
import { useCallback, useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, UserPlus, Users } from "lucide-react";

type Member = { userId: string; role: string; user: { name: string | null; email: string } };

export function ShopStaff({ businessId }: { businessId: string }) {
  const router = useRouter();
  const [members, setMembers] = useState<Member[]>([]);
  const [canManage, setCanManage] = useState(false);
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    try {
      const response = await fetch(`/api/businesses/${businessId}/staff`, { cache: "no-store" });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error ?? "Staff list unavailable.");
      setMembers(body.members);
      setCanManage(body.canManageStaff);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Staff list unavailable.");
    }
  }, [businessId]);

  useEffect(() => { void load(); }, [load]);

  async function add(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const email = String(new FormData(form).get("email") ?? "");
    setPending(true); setError(""); setMessage("");
    try {
      const response = await fetch(`/api/businesses/${businessId}/staff`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Couldn't add manager.");
      form.reset();
      setMessage("Manager added. They can sign in with their own account.");
      await load();
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Couldn't add manager.");
    } finally { setPending(false); }
  }

  async function remove(userId: string) {
    if (!window.confirm("Remove this manager's access to the shop?")) return;
    setPending(true); setError(""); setMessage("");
    try {
      const response = await fetch(`/api/businesses/${businessId}/staff`, { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId }) });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Couldn't remove manager.");
      setMessage("Manager access removed.");
      await load();
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Couldn't remove manager.");
    } finally { setPending(false); }
  }

  return <section className="rounded-3xl border border-ink/5 bg-white p-5 shadow-sm sm:p-7">
    <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-2xl bg-moss/10 text-moss"><Users size={19} /></span><div><h2 className="font-display text-xl font-semibold">Shop team</h2><p className="text-xs text-ink/50">Each person signs in with their own account.</p></div></div>
    <div className="mt-5 space-y-2">{members.map((member) => <div key={member.userId} className="flex items-center justify-between gap-3 rounded-2xl bg-paper px-4 py-3 text-sm"><div className="min-w-0"><p className="truncate font-semibold">{member.user.name ?? member.user.email}</p><p className="truncate text-xs text-ink/50">{member.user.email}</p></div><div className="flex shrink-0 items-center gap-3"><span className="rounded-full bg-white px-3 py-1 text-[11px] font-bold uppercase text-moss">{member.role.toLowerCase()}</span>{canManage && member.role === "MANAGER" && <button type="button" disabled={pending} onClick={() => void remove(member.userId)} className="text-xs font-semibold text-red-700 disabled:opacity-50">Remove</button>}</div></div>)}</div>
    {canManage && <><p className="mt-5 text-xs leading-5 text-ink/55">To add a manager, ask them to <Link href="/register" className="font-semibold text-moss underline">create an account</Link>. A platform super admin approves it as a shop admin. Then add their email here.</p><form onSubmit={add} className="mt-3 flex flex-col gap-2 sm:flex-row"><input name="email" type="email" required placeholder="manager@example.com" aria-label="Manager account email" className="h-11 min-w-0 flex-1 rounded-xl border border-ink/10 px-3 text-sm" /><button disabled={pending} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-moss px-4 text-sm font-semibold text-white disabled:opacity-50">{pending ? <LoaderCircle size={15} className="animate-spin" /> : <UserPlus size={15} />}Add manager</button></form></>}
    {message && <p role="status" className="mt-3 text-sm text-moss">{message}</p>}
    {error && <p role="alert" className="mt-3 text-sm text-red-700">{error}</p>}
  </section>;
}
