import { beforeEach, describe, expect, it, vi } from "vitest";
import { getCurrentUser } from "@/lib/authorization";
import { PATCH } from "./route";

const mocks = vi.hoisted(() => ({
  findUser: vi.fn(),
  updateUser: vi.fn(),
  createAudit: vi.fn(),
  transaction: vi.fn(),
}));

vi.mock("@/lib/authorization", () => ({ getCurrentUser: vi.fn() }));
vi.mock("@/lib/prisma", () => ({
  prisma: {
    user: { findUnique: mocks.findUser, update: mocks.updateUser },
    adminAuditLog: { create: mocks.createAudit },
    $transaction: mocks.transaction,
  },
}));

const superAdmin = {
  id: "fc10e39d-8753-4b2f-9549-918d36bd27c4",
  name: "Admin",
  email: "admin@example.com",
  role: "SUPER_ADMIN" as const,
};
const targetId = "4b97695f-3a0d-40cb-ac14-25d40774fbbb";

function request(body: unknown) {
  return new Request("http://localhost/api/admin/users", {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("super-admin user role management", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.DATABASE_URL = "postgresql://test:test@localhost/test";
    vi.mocked(getCurrentUser).mockResolvedValue(superAdmin);
    mocks.transaction.mockResolvedValue([]);
  });

  it("promotes an account to ADMIN and writes an audit record", async () => {
    mocks.findUser.mockResolvedValue({ id: targetId, role: "CUSTOMER" });

    const response = await PATCH(request({ id: targetId, role: "ADMIN" }));

    expect(response.status).toBe(200);
    expect(mocks.updateUser).toHaveBeenCalledWith({
      where: { id: targetId },
      data: { role: "ADMIN" },
    });
    expect(mocks.createAudit).toHaveBeenCalledWith({
      data: expect.objectContaining({
        actorId: superAdmin.id,
        action: "USER_ROLE_CHANGED_TO_ADMIN",
        entityType: "User",
        entityId: targetId,
      }),
    });
  });

  it("allows a super administrator to promote another trusted account", async () => {
    mocks.findUser.mockResolvedValue({ id: targetId, role: "CUSTOMER" });

    const response = await PATCH(request({ id: targetId, role: "SUPER_ADMIN" }));

    expect(response.status).toBe(200);
    expect(mocks.updateUser).toHaveBeenCalledWith({
      where: { id: targetId },
      data: { role: "SUPER_ADMIN" },
    });
    expect(mocks.createAudit).toHaveBeenCalledWith({
      data: expect.objectContaining({
        action: "USER_ROLE_CHANGED_TO_SUPER_ADMIN",
        entityId: targetId,
      }),
    });
  });

  it("does not allow an administrator to change roles", async () => {
    vi.mocked(getCurrentUser).mockResolvedValue({
      ...superAdmin,
      role: "ADMIN",
    });

    const response = await PATCH(request({ id: targetId, role: "CUSTOMER" }));

    expect(response.status).toBe(403);
    expect(mocks.findUser).not.toHaveBeenCalled();
  });
});
