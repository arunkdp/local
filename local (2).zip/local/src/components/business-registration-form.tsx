"use client";

import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { LoaderCircle, MapPin } from "lucide-react";

type Category = { id: string; name: string };

export function BusinessRegistrationForm() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    fetch("/api/categories").then((response) => response.ok ? response.json() : null).then((data) => setCategories(data?.categories ?? [])).catch(() => setError("Business categories are unavailable."));
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setPending(true);
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/businesses/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: form.get("name"), description: form.get("description"), categoryId: form.get("categoryId"),
        email: form.get("email") || undefined, phone: form.get("phone") || undefined,
        address: form.get("address"), city: form.get("city"), postalCode: form.get("postalCode") || undefined,
        latitude: Number(form.get("latitude")), longitude: Number(form.get("longitude")),
      }),
    });
    const result = await response.json().catch(() => ({}));
    setPending(false);
    if (!response.ok) { setError(result.error ?? "We couldn't submit your business."); return; }
    router.push("/business-dashboard");
    router.refresh();
  }

  return <form onSubmit={submit} className="space-y-4 rounded-3xl border border-ink/5 bg-white p-6 sm:p-8"><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">Business name<input name="name" required minLength={2} maxLength={100} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="block text-sm font-medium">Category<select name="categoryId" required className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 bg-white px-3"><option value="">Choose one</option>{categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}</select></label></div><label className="block text-sm font-medium">Description<textarea name="description" required minLength={20} maxLength={5000} className="mt-1.5 min-h-28 w-full rounded-xl border border-ink/10 p-3" /></label><div className="grid gap-4 sm:grid-cols-2"><label className="block text-sm font-medium">Business email<input name="email" type="email" className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="block text-sm font-medium">Phone<input name="phone" type="tel" maxLength={30} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label></div><label className="block text-sm font-medium">Street address<input name="address" required minLength={3} maxLength={200} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><div className="grid gap-4 sm:grid-cols-3"><label className="block text-sm font-medium">City<input name="city" required minLength={2} maxLength={100} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><label className="block text-sm font-medium">Postal code<input name="postalCode" maxLength={20} className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-3" /></label><div className="grid grid-cols-2 gap-2"><label className="block text-xs font-medium">Latitude<input name="latitude" type="number" step="any" min="-90" max="90" required className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-2" /></label><label className="block text-xs font-medium">Longitude<input name="longitude" type="number" step="any" min="-180" max="180" required className="mt-1.5 h-11 w-full rounded-xl border border-ink/10 px-2" /></label></div></div><p className="flex items-center gap-1.5 text-xs text-ink/45"><MapPin size={13} /> Coordinates are used for nearby discovery. Enter the location manually for now.</p>{error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}<button disabled={pending} className="inline-flex h-12 items-center gap-2 rounded-full bg-moss px-6 text-sm font-semibold text-white disabled:opacity-60">{pending && <LoaderCircle size={15} className="animate-spin" />}Submit for verification</button></form>;
}
