import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/pages/**/*.{js,ts,jsx,tsx,mdx}", "./src/components/**/*.{js,ts,jsx,tsx,mdx}", "./src/app/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#17221d",
        moss: "#315c45",
        lime: "#d7f36a",
        paper: "#f7f8f4",
      },
      fontFamily: { sans: ["var(--font-inter)", "Arial", "sans-serif"] },
      boxShadow: { soft: "0 14px 50px rgba(25, 45, 34, .08)" },
    },
  },
  plugins: [],
};

export default config;
