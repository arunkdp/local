import { describe, expect, it } from "vitest";
import { offerInputSchema } from "@/lib/validation";

const validOffer = {
  businessId: "00000000-0000-4000-8000-000000000001",
  title: "Neighborhood special",
  description: "A limited-time discount for our local community.",
  type: "PERCENTAGE" as const,
  discountPercent: 25,
  startsAt: "2026-10-24T09:00:00.000Z",
  endsAt: "2026-10-30T09:00:00.000Z",
};

describe("offerInputSchema", () => {
  it("accepts a valid percentage offer", () => {
    expect(offerInputSchema.safeParse(validOffer).success).toBe(true);
  });

  it("rejects offers that end before they start", () => {
    const result = offerInputSchema.safeParse({ ...validOffer, endsAt: "2026-10-23T09:00:00.000Z" });
    expect(result.success).toBe(false);
  });

  it("requires promotional prices below the original price", () => {
    const result = offerInputSchema.safeParse({ ...validOffer, type: "PROMOTIONAL_PRICE", originalMinor: 1000, promotionalMinor: 1000 });
    expect(result.success).toBe(false);
  });
});
