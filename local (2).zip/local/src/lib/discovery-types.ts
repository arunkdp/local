export type Offer = {
  id: string;
  business: string;
  category: string;
  title: string;
  description: string;
  discount: string;
  distance: string;
  expires: string;
  image: string | null;
  color: string;
  sponsored?: boolean;
  businessId?: string;
};

export type Shop = {
  id: string;
  name: string;
  type: string;
  distance: string;
  image: string | null;
  initials: string;
  tint: string;
  followerCount: number;
};