DROP TABLE "SaleRecord";
