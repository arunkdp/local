import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/authorization";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function RoleDashboard() {
  const user = await getCurrentUser();
  if (!user) redirect("/sign-in");

  if (user.role === "SUPER_ADMIN") redirect("/admin");
  if (user.role === "ADMIN") {
    const membership = await prisma.businessMembership.findFirst({
      where: { userId: user.id },
      select: { id: true },
    });
    redirect(membership ? "/business-dashboard" : "/business");
  }

  redirect("/account");
}
