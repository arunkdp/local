import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const categories = [
  { name: "Food & drink", slug: "food-drink" },
  { name: "Fashion", slug: "fashion" },
  { name: "Wellness", slug: "wellness" },
  { name: "Home & living", slug: "home-living" },
  { name: "Things to do", slug: "things-to-do" },
  { name: "Beauty", slug: "beauty" },
];

async function main() {
  for (const category of categories) {
    await prisma.businessCategory.upsert({
      where: { slug: category.slug },
      update: {},
      create: category,
    });
  }
  console.log("Business categories are ready.");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
}).finally(() => prisma.$disconnect());