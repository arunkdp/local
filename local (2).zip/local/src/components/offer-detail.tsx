"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Bookmark, Clock3, MapPin, Share2 } from "lucide-react";
import { ReportOfferForm } from "@/components/report-offer-form";

type Offer = { id: string; title: string; description: string; imageUrl?: string | null; image?: string; discountPercent?: number | string | null; discountMinor?: number | null; terms?: string | null; eligibility?: string | null; redemption?: string | null; endsAt?: string; expires?: string; sponsored?: boolean; business?: { name: string; slug: string; description: string; locations: Array<{ city: string; address: string; latitude: number; longitude: number }> } };

export function OfferDetail({ id }: { id: string }) {
  const [offer, setOffer] = useState<Offer | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  useEffect(() => { fetch(`/api/offers/${encodeURIComponent(id)}`).then(async (response) => { const body = await response.json(); if (!response.ok) throw new Error(body.error); setOffer(body.offer); }).catch((reason: Error) => setError(reason.message)); }, [id]);
  async function save() {
    const response = await fetch(`/api/offers/${encodeURIComponent(id)}/save`, { method: "PUT" });
    const result = await response.json().catch(() => ({}));
    setNotice(response.ok ? "Offer saved to your account." : result.error ?? "Sign in to save this offer.");
  }
  if (error) return <div role="alert" className="rounded-3xl bg-white p-8 text-center text-sm text-ink/60">{error}</div>;
  if (!offer) return <div className="rounded-3xl bg-white p-8 text-center text-sm text-ink/60">Loading offer…</div>;
  const image = offer.imageUrl ?? offer.image;
  const location = offer.business?.locations?.[0];
  return <article className="overflow-hidden rounded-[28px] border border-ink/5 bg-white shadow-soft"><div className="relative h-64 bg-moss sm:h-96">{image && <Image unoptimized src={image} alt={offer.title} fill sizes="(max-width: 768px) 100vw, 960px" className="object-cover" priority />}<div className="absolute inset-0 bg-gradient-to-t from-black/45 to-transparent" />{offer.sponsored && <span className="absolute left-5 top-5 rounded-full bg-white/90 px-3 py-1.5 text-xs font-semibold">SPONSORED</span>}<span className="absolute bottom-5 left-5 rounded-full bg-lime px-3 py-1.5 text-sm font-bold">{offer.discountPercent ? `${offer.discountPercent}% off` : offer.discountMinor ? `$${(offer.discountMinor / 100).toFixed(2)} off` : "Local offer"}</span></div><div className="p-6 sm:p-9"><p className="text-xs font-bold uppercase tracking-wider text-moss">{offer.business ? <Link href={`/business/${offer.business.slug}`} className="hover:underline">{offer.business.name}</Link> : "Local find"}</p><h1 className="mt-2 font-display text-3xl font-semibold tracking-tight sm:text-4xl">{offer.title}</h1><p className="mt-4 max-w-3xl text-base leading-7 text-ink/65">{offer.description}</p><div className="mt-5 flex flex-wrap gap-4 text-xs text-ink/50">{location && <span className="flex items-center gap-1"><MapPin size={14} />{location.address}, {location.city}</span>}{offer.endsAt && <span className="flex items-center gap-1"><Clock3 size={14} />Ends {new Date(offer.endsAt).toLocaleDateString()}</span>}{offer.expires && <span className="flex items-center gap-1"><Clock3 size={14} />{offer.expires}</span>}</div><div className="mt-7 flex flex-wrap gap-3"><button onClick={save} className="inline-flex h-11 items-center gap-2 rounded-full bg-moss px-5 text-sm font-semibold text-white"><Bookmark size={15} />Save offer</button><button onClick={async () => { await navigator.clipboard?.writeText(window.location.href); setNotice("Offer link copied."); }} className="inline-flex h-11 items-center gap-2 rounded-full border border-ink/10 px-5 text-sm font-semibold"><Share2 size={15} />Share</button></div>{notice && <p role="status" className="mt-3 text-sm text-moss">{notice}</p>}<ReportOfferForm offerId={offer.id} />{(offer.terms || offer.eligibility || offer.redemption) && <section className="mt-8 border-t border-ink/5 pt-6"><h2 className="font-display text-lg font-semibold">The details</h2>{offer.terms && <p className="mt-2 text-sm leading-6 text-ink/60">{offer.terms}</p>}{offer.eligibility && <p className="mt-2 text-sm leading-6 text-ink/60"><strong>Eligibility:</strong> {offer.eligibility}</p>}{offer.redemption && <p className="mt-2 text-sm leading-6 text-ink/60"><strong>How to redeem:</strong> {offer.redemption}</p>}</section>}</div></article>;
}
