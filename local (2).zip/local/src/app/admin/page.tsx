import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { getCurrentUser } from "@/lib/authorization";
import { AdminConsole } from "@/components/admin-console";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/sign-in?type=admin");
  if (user.role !== "SUPER_ADMIN") redirect("/dashboard");
  return <main className="min-h-screen bg-paper px-5 py-8 text-ink sm:px-8"><div className="mx-auto max-w-6xl"><Link href="/" className="inline-flex items-center gap-2 text-sm text-ink/55 hover:text-moss"><ArrowLeft size={15} /> Marketplace</Link><header className="mb-7 mt-7"><p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[.14em] text-moss"><ShieldCheck size={15} /> PLATFORM OPERATIONS</p><h1 className="mt-2 font-display text-3xl font-semibold tracking-tight">Admin dashboard</h1><p className="mt-1 text-sm text-ink/55">Approve new shops under Business verification. Approved shops publish their own offers.</p></header><AdminConsole /></div></main>;
}
