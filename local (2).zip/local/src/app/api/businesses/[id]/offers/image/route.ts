﻿import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { z } from "zod";
import { canManageBusiness, getCurrentUser } from "@/lib/authorization";

export const runtime = "nodejs";
const maxImageBytes = 5 * 1024 * 1024;

function imageExtension(bytes: Uint8Array) {
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "jpg";
  if (bytes.length >= 8 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 && bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a) return "png";
  if (bytes.length >= 12 && String.fromCharCode(...bytes.slice(0, 4)) === "RIFF" && String.fromCharCode(...bytes.slice(8, 12)) === "WEBP") return "webp";
  return null;
}

export async function POST(request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in to upload an image." }, { status: 401 });
  const { id } = await context.params;
  if (!z.string().uuid().safeParse(id).success || !(await canManageBusiness(user.id, id))) return NextResponse.json({ error: "You don't have access to this business." }, { status: 403 });
  const contentLength = Number(request.headers.get("content-length"));
  if (contentLength > maxImageBytes + 64 * 1024) return NextResponse.json({ error: "Image must be 5 MB or smaller." }, { status: 413 });

  try {
    const form = await request.formData();
    const file = form.get("image");
    if (!(file instanceof File) || file.size === 0 || file.size > maxImageBytes) return NextResponse.json({ error: "Choose an image up to 5 MB." }, { status: 400 });
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) return NextResponse.json({ error: "Use a JPG, PNG, or WebP image." }, { status: 400 });
    const bytes = new Uint8Array(await file.arrayBuffer());
    const extension = imageExtension(bytes);
    if (!extension || (extension === "jpg" && file.type !== "image/jpeg") || (extension === "png" && file.type !== "image/png") || (extension === "webp" && file.type !== "image/webp")) return NextResponse.json({ error: "The selected file is not a valid image." }, { status: 400 });
    const directory = path.join(process.cwd(), "public", "uploads", "offers");
    await mkdir(directory, { recursive: true });
    const filename = `${id}-${crypto.randomUUID()}.${extension}`;
    await writeFile(path.join(directory, filename), bytes, { flag: "wx" });
    return NextResponse.json({ imageUrl: `/uploads/offers/${filename}` }, { status: 201 });
  } catch (error) {
    console.error("Offer image upload failed", error);
    return NextResponse.json({ error: "Couldn't upload the image." }, { status: 500 });
  }
}
