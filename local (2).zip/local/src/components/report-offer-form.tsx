"use client";

import { useState } from "react";

export function ReportOfferForm({ offerId }: { offerId: string }) {
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);
  const [notice, setNotice] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setNotice("");
    try {
      const form = new FormData(event.currentTarget);
      const response = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetType: "OFFER",
          targetId: offerId,
          reason: form.get("reason"),
          details: form.get("details"),
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        setNotice(body.error ?? "Couldn't submit your report.");
        return;
      }
      setNotice("Thanks. Your report was sent to the moderation team.");
      setOpen(false);
    } catch {
      setNotice("Couldn't reach the reporting service. Check your connection and retry.");
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="mt-5">
      {!open ? (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="text-sm font-semibold text-ink/55 underline decoration-ink/20 underline-offset-4 hover:text-moss"
        >
          Report this offer
        </button>
      ) : (
        <form onSubmit={submit} className="max-w-xl rounded-2xl bg-paper p-4">
          <label htmlFor="report-reason" className="block text-sm font-semibold">
            Why are you reporting this offer?
          </label>
          <input
            id="report-reason"
            name="reason"
            required
            minLength={3}
            maxLength={120}
            className="mt-2 w-full rounded-xl border border-ink/10 bg-white px-3 py-2 text-sm"
          />
          <label htmlFor="report-details" className="mt-3 block text-sm font-semibold">
            Additional details (optional)
          </label>
          <textarea
            id="report-details"
            name="details"
            maxLength={2000}
            rows={3}
            className="mt-2 w-full resize-y rounded-xl border border-ink/10 bg-white px-3 py-2 text-sm"
          />
          <div className="mt-3 flex gap-2">
            <button
              type="submit"
              disabled={pending}
              className="rounded-full bg-moss px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
            >
              {pending ? "Sending…" : "Submit report"}
            </button>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="rounded-full border border-ink/10 px-4 py-2 text-sm font-semibold"
            >
              Cancel
            </button>
          </div>
        </form>
      )}
      {notice && (
        <p role="status" className="mt-2 text-sm text-ink/60">
          {notice}
        </p>
      )}
    </div>
  );
}
