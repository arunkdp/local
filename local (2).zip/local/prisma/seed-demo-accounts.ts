import { hash } from "bcryptjs";
import { PrismaClient, UserRole } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  if (process.env.NODE_ENV === "production") throw new Error("Demo accounts are local-only.");
  const databaseHost = new URL(process.env.DATABASE_URL ?? "").hostname;
  if (!["localhost", "127.0.0.1", "[::1]"].includes(databaseHost)) throw new Error("Demo accounts require a loopback PostgreSQL database.");
  const password = process.env.DEMO_ACCOUNT_PASSWORD;
  if (!password || password.length < 16) throw new Error("Set DEMO_ACCOUNT_PASSWORD to at least 16 characters in .env.");

  const passwordHash = await hash(password, 12);
  const accounts: Array<{ email: string; name: string; role: UserRole; shopSlug?: string }> = [
    { email: "super@locallink.test", name: "Platform Admin", role: "SUPER_ADMIN" },
    { email: "coffee@locallink.test", name: "Daybreak Manager", role: "ADMIN", shopSlug: "daybreak-coffee" },
    { email: "fashion@locallink.test", name: "Form & Fold Manager", role: "ADMIN", shopSlug: "form-and-fold" },
    { email: "customer@locallink.test", name: "Local Customer", role: "CUSTOMER" },
  ];

  for (const account of accounts) {
    const user = await prisma.user.upsert({
      where: { email: account.email },
      create: { email: account.email, name: account.name, passwordHash, role: account.role, profile: { create: {} } },
      update: { name: account.name, passwordHash, role: account.role, disabledAt: null },
      select: { id: true },
    });
    if (account.shopSlug) {
      const shop = await prisma.business.findUnique({ where: { slug: account.shopSlug }, select: { id: true } });
      if (!shop) throw new Error(`Seed the sample shops before assigning ${account.email}.`);
      await prisma.businessMembership.upsert({
        where: { userId_businessId: { userId: user.id, businessId: shop.id } },
        create: { userId: user.id, businessId: shop.id, role: "OWNER" },
        update: {},
      });
    }
  }

  const customer = await prisma.user.findUniqueOrThrow({ where: { email: "customer@locallink.test" } });
  const offer = await prisma.offer.findFirst({ where: { business: { slug: "daybreak-coffee" } }, select: { id: true, businessId: true } });
  if (offer) {
    await prisma.savedOffer.upsert({ where: { userId_offerId: { userId: customer.id, offerId: offer.id } }, create: { userId: customer.id, offerId: offer.id }, update: {} });
    await prisma.businessFollow.upsert({ where: { userId_businessId: { userId: customer.id, businessId: offer.businessId } }, create: { userId: customer.id, businessId: offer.businessId }, update: {} });
  }
  const favoriteProduct = offer ? await prisma.product.findFirst({ where: { businessId: offer.businessId, slug: "house-blend" }, select: { id: true } }) : null;
  if (favoriteProduct) await prisma.favoriteProduct.upsert({ where: { userId_productId: { userId: customer.id, productId: favoriteProduct.id } }, create: { userId: customer.id, productId: favoriteProduct.id }, update: {} });
  console.log("Seeded four local demo accounts and customer activity.");
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(() => prisma.$disconnect());
