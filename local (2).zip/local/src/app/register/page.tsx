"use client";

import Link from "next/link";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { ArrowLeft, Compass, LoaderCircle, Store, UserRound } from "lucide-react";

type AccountType = "CUSTOMER" | "SHOP_OWNER";

export default function RegisterPage() {
  const router = useRouter();
  const [accountType, setAccountType] = useState<AccountType>("CUSTOMER");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("type") === "shop") setAccountType("SHOP_OWNER");
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setPending(true);
    try {
      const form = new FormData(event.currentTarget);
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.get("name"),
          email: form.get("email"),
          password: form.get("password"),
          accountType,
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        setError(body.error ?? "We couldn't create your account. Please try again.");
        return;
      }
      const result = await signIn("credentials", {
        email: form.get("email"),
        password: form.get("password"),
        redirect: false,
      });
      if (result?.error) {
        setError("Your account is ready. Please sign in to continue.");
        router.push(accountType === "SHOP_OWNER" ? "/sign-in?type=shop" : "/sign-in");
        return;
      }
      router.push(accountType === "SHOP_OWNER" ? "/business" : "/dashboard");
      router.refresh();
    } catch {
      setError("We couldn't reach account services. Check your connection and try again.");
    } finally {
      setPending(false);
    }
  }

  const shop = accountType === "SHOP_OWNER";

  return <main className="grid min-h-screen place-items-center bg-paper px-5 py-10"><div className="w-full max-w-[460px]">
    <Link href="/" className="mb-8 inline-flex items-center gap-2 text-sm text-ink/55 hover:text-moss"><ArrowLeft size={16} /> Back to discovery</Link>
    <div className="rounded-[28px] border border-ink/5 bg-white p-7 shadow-soft sm:p-9">
      <Link href="/" className="mb-7 flex items-center gap-2.5"><span className="grid h-9 w-9 place-items-center rounded-[13px] bg-moss text-lime"><Compass size={20} /></span><span className="font-display text-xl font-semibold">local<span className="text-moss">link</span></span></Link>
      <div className="grid grid-cols-2 gap-1 rounded-2xl bg-paper p-1" aria-label="Create account as">
        <button type="button" aria-pressed={!shop} onClick={() => { setAccountType("CUSTOMER"); setError(""); }} className={`flex min-h-11 items-center justify-center gap-2 rounded-xl px-2 text-sm font-semibold transition ${!shop ? "bg-white text-moss shadow-sm" : "text-ink/55 hover:text-ink"}`}><UserRound size={16} /> Customer</button>
        <button type="button" aria-pressed={shop} onClick={() => { setAccountType("SHOP_OWNER"); setError(""); }} className={`flex min-h-11 items-center justify-center gap-2 rounded-xl px-2 text-sm font-semibold transition ${shop ? "bg-white text-moss shadow-sm" : "text-ink/55 hover:text-ink"}`}><Store size={16} /> Shop owner</button>
      </div>
      <p className="eyebrow mt-7">{shop ? "BRING YOUR SHOP TO LOCALLINK" : "YOUR NEIGHBORHOOD, IN YOUR POCKET"}</p>
      <h1 className="mt-2 font-display text-3xl font-semibold tracking-tight">{shop ? "Create your shop account." : "Find your local."}</h1>
      <p className="mt-2 text-sm leading-6 text-ink/55">{shop ? "Create an owner account, submit your shop for review, then add products, discounts, and offer images from your dashboard." : "Create an account to save offers and follow favorite shops."}</p>
      <form onSubmit={submit} className="mt-7 space-y-4">
        <label className="block text-sm font-medium">Your name<input name="name" type="text" autoComplete="name" required minLength={2} maxLength={80} className="mt-1.5 h-12 w-full rounded-xl border border-ink/10 px-4 text-sm outline-none focus:border-moss" placeholder="Jamie Parker" /></label>
        <label className="block text-sm font-medium">Email address<input name="email" type="email" autoComplete="email" required maxLength={254} className="mt-1.5 h-12 w-full rounded-xl border border-ink/10 px-4 text-sm outline-none focus:border-moss" placeholder="you@example.com" /></label>
        <label className="block text-sm font-medium">Create a password<input name="password" type="password" autoComplete="new-password" required minLength={12} maxLength={64} className="mt-1.5 h-12 w-full rounded-xl border border-ink/10 px-4 text-sm outline-none focus:border-moss" placeholder="12+ characters" /><span className="mt-1.5 block text-xs text-ink/45">At least 12 characters, including uppercase, lowercase, and a number.</span></label>
        {error && <p role="alert" className="rounded-xl bg-red-50 px-3.5 py-3 text-sm text-red-700">{error}</p>}
        <button disabled={pending} className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-moss text-sm font-semibold text-white transition hover:bg-ink disabled:opacity-60">{pending && <LoaderCircle size={16} className="animate-spin" />}{shop ? "Create shop account" : "Create my account"}</button>
      </form>
      {shop && <p className="mt-4 rounded-2xl bg-moss/5 p-3 text-xs leading-5 text-ink/60">Your shop appears publicly after its initial approval. You can then publish offers directly. Your account can manage only shops you own or are assigned to.</p>}
      <p className="mt-6 text-center text-sm text-ink/55">Already a member? <Link href={shop ? "/sign-in?type=shop" : "/sign-in"} className="font-semibold text-moss hover:underline">Sign in</Link></p>
      <p className="mt-5 text-xs leading-5 text-ink/40">Email verification will be required after an email delivery provider is configured.</p>
    </div>
  </div></main>;
}