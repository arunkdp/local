# LocalLink

LocalLink connects customers with independent shops and their current offers. Visitors can browse without signing in. Customer accounts can save offers, follow shops, report content, and manage preferences. Shop admins manage only their assigned businesses. Super admins review businesses and offers, handle reports, manage users, and inspect audit activity.

## Stack

Next.js 15 App Router, React 19, TypeScript, Tailwind CSS, Auth.js credentials, Prisma 6, PostgreSQL, Zod, Vitest, and Playwright.

## Local setup

1. Install Node.js 20.9+ and PostgreSQL. Run `npm install`.
2. Copy `.env.example` to `.env`. Set `DATABASE_URL` to an empty PostgreSQL database and set a random `AUTH_SECRET`.
3. Run `npm run db:generate`, `npm run db:migrate`, and `npm run db:seed`. The seed creates only business categories; shops and offers are created by users.
4. Run `npm run dev` and open `http://localhost:3000`.

This checkout uses the local PostgreSQL server at `localhost:5432/local_link`. Put its working credentials in the ignored `.env` file. The database starts empty; the normal seed adds only business categories.

## Demo accounts

For local testing only, `npm run db:seed-sample-content` adds sample shops and offers, and `npm run db:seed-demo` creates these accounts if `DEMO_ACCOUNT_PASSWORD` is set in `.env` to at least 16 characters. All four use that password.

| Email | Role | Access |
| --- | --- | --- |
| `super@locallink.test` | Super admin | Platform dashboard and all shops |
| `coffee@locallink.test` | Shop admin | Daybreak Coffee |
| `fashion@locallink.test` | Shop admin | Form & Fold |
| `customer@locallink.test` | Customer | Saved offer and followed shop |

The demo seed refuses to run with `NODE_ENV=production`. Remove demo accounts before using a shared or production database.

Registration offers Customer and Shop owner account types. Shop owner accounts receive the shop-scoped `ADMIN` role; they can manage only businesses they own or are assigned to. To set up a real super admin, register a customer account, set `BOOTSTRAP_SUPER_ADMIN_EMAIL` in `.env`, and run `npm run db:bootstrap-super-admin`. Submitted businesses and offers require super admin approval before visitors can see them. Material edits to an approved shop profile return it to the review queue; contact details update immediately.

## Platform admin approval

1. Create a separate Customer account at `/register` using your own email and password.
2. Set `BOOTSTRAP_SUPER_ADMIN_EMAIL` in `.env` to that email. Run `npm run db:bootstrap-super-admin` once from the project folder.
3. Open `/sign-in?type=admin`, choose **Platform admin**, and sign in. The admin dashboard is at `/admin`.
4. Under **Business verification**, review the pending shop and select **Approve** or **Reject**. Approval makes the shop public. Owners can then publish offers directly. Offers created before shop approval stay as drafts until the owner publishes them.

Shop owners cannot approve their own shops. There are no default platform admin credentials.

## Shop owner and manager sign in

1. Open `/register?type=shop`, choose **Shop owner**, and create an account. Existing shop managers should create their own shop account too.
2. Sign in at `/sign-in?type=shop` with that email and password. The shop owner sign-in switch uses the same secure login as the customer switch.
3. Open `/business` and submit the shop. The owner is attached automatically. Use the business dashboard to add products, offers, discounts, descriptions, images, and offer dates.
4. To add a manager, that person creates a shop account first. The owner then opens the shop dashboard and adds the manager by email in **Shop team**. Managers can update assigned shops, but they cannot add or remove managers or register another shop unless they also own one. The shop team assignment does not give access to other shops.

Shop staff use the same `/sign-in` page as customers. After sign-in, they are routed to their assigned business dashboard. The dashboard shows follower counts, offer saves, product likes, and active offers.

## Check the app

Run `npm run typecheck`, `npm test`, and `npm run test:e2e`. Playwright needs its Chromium browser installed once with `npx playwright install chromium`. The public discovery API is `/api/discovery`; it returns only approved shops and currently active offers from PostgreSQL.

## Known work before production

The shop dashboard can create, edit, hide, pause, resubmit, and archive content, and upload offer images. Offer images are stored in the local public directory for development; production deployment needs persistent object storage. Email verification, password recovery, notification delivery, address geocoding and a configurable distance radius, redemption, and a customer-facing privacy/terms page are still needed. The optional sample-content seed is for local testing and uses temporary Unsplash imagery. The initial Prisma migration is checked in. Review future schema migrations before applying them to a persistent database.
# locallink
# local
